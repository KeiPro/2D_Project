#include "Camera.h"
#include "Player.h"

void Camera::Init(int _addValue)
{
	addValue = _addValue;
	disBaseLineToPlayer = 0;
	speed = 7;

	baseLineTop = { GAME_SIZE_X / 3, 0 };
	baseLineBottom = { GAME_SIZE_X / 3, GAME_SIZE_Y };

	color = RGB(255, 0, 0);
	hPen = CreatePen(PS_SOLID, 2, color);
}

void Camera::Render(HDC hdc)
{
	hOldPen = (HPEN)SelectObject(hdc, hPen);
	MoveToEx(hdc, baseLineTop.x + addValue, baseLineTop.y, NULL);
	LineTo(hdc, baseLineBottom.x + addValue, baseLineBottom.y);
	SelectObject(hdc, hOldPen);
}

HRESULT Camera::Init()
{
	return S_OK;
}

void Camera::Release()
{
	DeleteObject(hPen);
}

void Camera::Update()
{
	if (player->GetPlayerPos().x > baseLineTop.x)
	{
		disBaseLineToPlayer = player->GetPlayerPos().x - baseLineTop.x;
		cameraSpeed = (disBaseLineToPlayer * speed * TimeManager::GetSingleton()->GetDeltaTime());
		player->SetPlayerPosX((player->GetPlayerPos().x) - (int)cameraSpeed);
	}
	else
	{
		cameraSpeed = 0;
	}
}

Camera::Camera()
{
}


Camera::~Camera()
{
}

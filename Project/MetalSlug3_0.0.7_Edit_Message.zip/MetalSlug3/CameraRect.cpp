#include "CameraRect.h"


void CameraRect::Init()
{
	cameraYRectVec.reserve(10);
	cameraYRectVec.clear();
}

void CameraRect::Release()
{
	cameraYRectVec.clear();
	cameraYRectVec.capacity();

	vector<RECT>().swap(cameraYRectVec);
	cameraYRectVec.capacity();
}

CameraRect::CameraRect()
{
}


CameraRect::~CameraRect()
{
}

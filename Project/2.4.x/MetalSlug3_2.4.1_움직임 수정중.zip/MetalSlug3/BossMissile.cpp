#include "BossMissile.h"
#include "Animation.h"
#include "Image.h"
#include "Player.h"

HRESULT BossMissile::Init()
{
	missile1Img = ImageManager::GetSingleton()->FindImage("B_Missile1");

	pos = { 0, 0 };
	speed = 500.0f;
	angle = 0.0f;
	damage = 1;
	rc = { 0, 0, 0, 0 };
	isFire = false;

	return S_OK;
}

void BossMissile::Release()
{

}

void BossMissile::Update()
{
	if (isFire == true)
	{
		pos.x += speed * cosf((angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf((angle)) * TimeManager::GetSingleton()->GetDeltaTime();
	}

	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	rc = GetRectToCenter(relativePos.x, relativePos.y, 40, 40);

	if (relativePos.x < -100 || relativePos.x > GAME_SIZE_X + 100 || relativePos.y < -50 || relativePos.y > GAME_SIZE_Y + 50)
	{
		isFire = false;
	}

	if (CheckRectCollision(DataCollector::GetSingleton()->GetPlayer()->GetPlayerCollRC(), rc))
	{
		isFire = false; 
		DataCollector::GetSingleton()->GetPlayer()->SetLife(DataCollector::GetSingleton()->GetPlayer()->GetLife() - 1);
	}
}

void BossMissile::Render(HDC hdc)
{
	if (missile1Img)
		missile1Img->FrameRender(hdc, relativePos.x, relativePos.y, 3, 0, 3.0f);
}

BossMissile::BossMissile()
{

}


BossMissile::~BossMissile()
{
}

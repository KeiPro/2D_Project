#include "LoadingScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT LoadingScene::Init()
{
	bg = ImageManager::GetSingleton()->AddImage("�ε����", "Image/LoadingBackground.bmp", WINSIZE_X, WINSIZE_Y);
	stageNum = ImageManager::GetSingleton()->AddImage("���������ѹ�", "Image/UIStageNum.bmp", 0, 0, 40, 16, 5, 2 ,true ,RGB(255,255,255));
	stage = ImageManager::GetSingleton()->AddImage("��������", "Image/UIStage.bmp", 40, 7,true);
	return S_OK;
}

void LoadingScene::Release()
{

}

void LoadingScene::Update()
{

	
}

void LoadingScene::Render(HDC hdc)
{
	if(bg)
		bg->Render(hdc,0,0);
	if (stage)
		stage->Render(hdc, WINSIZE_X / 2 - 100, WINSIZE_Y / 2,2.0f);
	if (stageNum)
		stageNum->FrameRender(hdc, WINSIZE_X / 2 -10,  WINSIZE_Y / 2 + 1  , 1, 0, 2.2f);
}

LoadingScene::LoadingScene()
{
}

LoadingScene::~LoadingScene()
{
}

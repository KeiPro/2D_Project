#include "Player.h"
#include "Animation.h"
#include "Image.h"

HRESULT Player::Init(float _editorPosition)
{
	editorPosition = _editorPosition;

	playerImg.playerIdleBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Body", "Image/Player/Body/Player_Idle_Body.bmp", 0, 0, 320, 80, 4, 1, true, RGB(86, 177, 222));
	playerImg.playerWalkBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Walk_Body", "Image/Player/Body/Player_Walk_Body.bmp", 0, 0, 960, 80, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerShootingBodyImg  = ImageManager::GetSingleton()->AddImage("Player_Shooting_Body", "Image/Player/Body/Player_Shooting_Body.bmp", 0, 0, 900, 80, 10, 1, true, RGB(86, 177, 222));
	
	playerImg.playerWalkLegImg		 = ImageManager::GetSingleton()->AddImage("Player_Walk_Leg", "Image/Player/Leg/Player_Walk_Leg.bmp", 0, 0, 540, 25, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerIdleLegImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Leg", "Image/Player/Leg/Player_Idle_Leg.bmp", 0, 0, 45, 25, 1, 1, true, RGB(86, 177, 222));

	PlayerAnimationSetting(&playerAni);

	//�÷��̾� �����ϰ�
	scale = 2.5f;


	//ĳ���� �⺻ ����
	pos = { 200 , 100};
	speed = 200.0f;

	//�÷��̾��� ��, ��ü ����
	playerBodyState = PlayerState::Idle;
	playerLegState = PlayerState::Idle;

	//����Ű�� ���ȴ����� üũ�ϴ� ����
	isHorizontal = false;
	isVertical = false;
	isReverse = false;

	//�ȼ� �浹�� ���� ����
	probeY = 50;
	isRanding = false;

	return S_OK;
}

void Player::Release()
{
	SAFE_DELETE(playerAni.playerIdleBodyAni);
	SAFE_DELETE(playerAni.playerShootingBodyAni);
	SAFE_DELETE(playerAni.playerWalkBodyAni);
	SAFE_DELETE(playerAni.playerWalkLegAni);
}

void Player::Update()
{


	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
	{
		isHorizontal = true;
		isReverse = true;

		if (playerBodyState != PlayerState::Shooting)
			playerBodyState = PlayerState::Walk;
			
		playerLegState = PlayerState::Walk;

		pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
	{
		isHorizontal = true;
		isReverse = false;

		//�ٵ� ����
		if (playerBodyState != PlayerState::Shooting)
			playerBodyState = PlayerState::Walk;

		//�ٸ� ����
		playerLegState = PlayerState::Walk;

		pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else
	{
		isHorizontal = false;
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
	{
		isVertical = true;
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
	{
		isVertical = true;
	}
	else
	{
		isVertical = false;
	}

	// ��, �� Ű�� ��, �� Ű�� ������ �ʾ��� ��쿡��
	if ((!isHorizontal) && (!isVertical))
	{
		if((playerBodyState != PlayerState::Shooting))
			playerBodyState = PlayerState::Idle;

		playerLegState = PlayerState::Idle;
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown('Z'))
	{
		playerAni.playerShootingBodyAni->Start();
		playerBodyState = PlayerState::Shooting;
	}


	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerLegState)
	{
	case PlayerState::Idle:

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkLegAni)
		{
			playerAni.playerWalkLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 5.0f);
		}
	
		break;

	case PlayerState::Shooting:

		break;

	default:

		break;
	}

	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerAni.playerIdleBodyAni)
		{
			playerAni.playerIdleBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkBodyAni)
		{
			//playerAni.playerWalkLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
			playerAni.playerWalkBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Shooting:

		if (playerAni.playerShootingBodyAni)
		{
			playerAni.playerShootingBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		if (playerAni.playerShootingBodyAni->GetNowPlayIdx() == playerAni.playerShootingBodyAni->GetFrameCount() - 1)
		{
			playerBodyState = PlayerState::Idle;
		}

		break;

	default:

		break;
	}

	if (isRanding == false && pos.y < GAME_SIZE_Y)
	{
		pos.y += 9.81f;
	}

	// �ȼ� �浹
	rc = GetRectToCenter(pos.x + editorPosition - 5, pos.y - 10, probeY, probeY);
}

void Player::Render(HDC hdc)
{
	//Rectangle(hdc, pos.x - 45 + editorPosition, pos.y - 80, pos.x + 45 + editorPosition, pos.y + 60);
	
	

	//�ٸ��� ���¿� ���� ����
	switch (playerLegState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleLegImg)
		{
			if(isReverse == false)
				playerImg.playerIdleLegImg->FrameRender(hdc, pos.x - 10 + editorPosition, pos.y - 2, 0, 0, scale, false);
			else
				playerImg.playerIdleLegImg->FrameRender(hdc, pos.x + 10 + editorPosition, pos.y- 2, 0, 0, scale, true);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkLegImg)
		{
			if(isReverse == false)
				playerImg.playerWalkLegImg->AnimationRender(hdc, pos.x - 10 + editorPosition, pos.y-4, playerAni.playerWalkLegAni, scale);
			else
				playerImg.playerWalkLegImg->AnimationReverseRender(hdc, pos.x + 10 + editorPosition, pos.y - 4, playerAni.playerWalkLegAni, scale);
		}

		break;

	default:

		break;
	}


	//��ü�� ���¿� ���� ����
	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleBodyImg)
		{
			if (isReverse == false)
				playerImg.playerIdleBodyImg->AnimationRender(hdc, pos.x + editorPosition, pos.y - 50, playerAni.playerIdleBodyAni, scale);
			else
				playerImg.playerIdleBodyImg->AnimationReverseRender(hdc, pos.x + editorPosition, pos.y - 50, playerAni.playerIdleBodyAni, scale);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkBodyImg)
		{
			if (isReverse == false)
				playerImg.playerWalkBodyImg->AnimationRender(hdc, pos.x + editorPosition, pos.y - 50, playerAni.playerWalkBodyAni, scale);
			else
				playerImg.playerWalkBodyImg->AnimationReverseRender(hdc, pos.x + editorPosition, pos.y - 50, playerAni.playerWalkBodyAni, scale);
		}

		break;

	case PlayerState::Shooting:

		if (playerImg.playerShootingBodyImg)
		{
			if(isReverse == false)
				playerImg.playerShootingBodyImg->AnimationRender(hdc, pos.x + editorPosition, pos.y - 53, playerAni.playerShootingBodyAni, scale);
			else
				playerImg.playerShootingBodyImg->AnimationReverseRender(hdc, pos.x + editorPosition, pos.y - 53, playerAni.playerShootingBodyAni, scale);
		}

		break;

	default:

		break;
	}

	Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
}

void Player::PlayerAnimationSetting(PlayerAni * playerAni)
{
	(*playerAni).playerIdleBodyAni = new Animation();
	(*playerAni).playerIdleBodyAni->Init(playerImg.playerIdleBodyImg->GetWidth(), playerImg.playerIdleBodyImg->GetHeight(), 
		playerImg.playerIdleBodyImg->GetFrameWidth(), playerImg.playerIdleBodyImg->GetFrameHeight());
	(*playerAni).playerIdleBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerIdleBodyAni->SetUpdateTime(FPS / 5);
	(*playerAni).playerIdleBodyAni->Start();

	(*playerAni).playerWalkBodyAni = new Animation();
	(*playerAni).playerWalkBodyAni->Init(playerImg.playerWalkBodyImg->GetWidth(), playerImg.playerWalkBodyImg->GetHeight(),
		playerImg.playerWalkBodyImg->GetFrameWidth(), playerImg.playerWalkBodyImg->GetFrameHeight());
	(*playerAni).playerWalkBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkBodyAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkBodyAni->Start();

	(*playerAni).playerShootingBodyAni = new Animation();
	(*playerAni).playerShootingBodyAni->Init(playerImg.playerShootingBodyImg->GetWidth(), playerImg.playerShootingBodyImg->GetHeight(),
		playerImg.playerShootingBodyImg->GetFrameWidth(), playerImg.playerShootingBodyImg->GetFrameHeight());
	(*playerAni).playerShootingBodyAni->SetPlayFrame(false, false);
	(*playerAni).playerShootingBodyAni->SetUpdateTime(FPS * 2);
	(*playerAni).playerShootingBodyAni->Start();

	(*playerAni).playerWalkLegAni = new Animation();
	(*playerAni).playerWalkLegAni->Init(playerImg.playerWalkLegImg->GetWidth(), playerImg.playerWalkLegImg->GetHeight(),
		playerImg.playerWalkLegImg->GetFrameWidth(), playerImg.playerWalkLegImg->GetFrameHeight());
	(*playerAni).playerWalkLegAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkLegAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkLegAni->Start();
}

Player::Player()
{
}


Player::~Player()
{
}

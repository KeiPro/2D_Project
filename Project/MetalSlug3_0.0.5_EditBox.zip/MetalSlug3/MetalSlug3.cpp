﻿// main.cpp

/*
	Win32 API
	: Application Programing Interface
	운영체제가 응용프로그램을 위해 제공하는 함수의 집합

	하드웨어 ----------운영체제(Windows)-------- 응용프로그램
						(API 함수)

	핸들(Handle)
	메시지(Message)
*/

#include "pch.h"
#include <Windows.h>
#include "MainGame.h"

// 전역변수
HINSTANCE	g_hInstance;	// 프로그램 인스턴스 핸들
HWND		g_hWnd;			// 윈도우 핸들
HWND		g_hNewWnd;
HWND		g_hEdit;
HWND		g_button_ok, g_button_cancle;

TCHAR str[1024];

LPSTR		g_lpszClass = (LPSTR)TEXT("Metal Slug3");
LPSTR		g_lpszClass2 = (LPSTR)TEXT("값을 입력하세요.");

POINT		g_ptMouse;
float		g_wheelMouse;

MainGame mainGame;

//void SetWindowSize(int x, int y, int width, int height);

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage,
	WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK WndProcNew(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

// 윈도우를 생성하기 위한 함수
int APIENTRY WinMain(HINSTANCE _hInstance, HINSTANCE _hPrevInstance,
	LPSTR _lpszCmdParam, int nCmdShow)
{
	// 윈도우 생성을 위한 기본셋팅
	g_hInstance = _hInstance;
	WNDCLASS wndClass;
	wndClass.cbClsExtra = 0;	// 클래스 여분 메모리
	wndClass.cbWndExtra = 0;	// 윈도우 여분 메모리
	wndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndClass.hInstance = g_hInstance;
	wndClass.lpfnWndProc = WndProc;
	wndClass.lpszClassName = g_lpszClass;
	wndClass.lpszMenuName = NULL;
	wndClass.style = CS_HREDRAW | CS_VREDRAW;

	// 윈도우 클래스 등록
	RegisterClass(&wndClass);

	// 윈도우 생성
	g_hWnd = CreateWindow(g_lpszClass, g_lpszClass,
		WS_OVERLAPPEDWINDOW,
		WINSTART_X, WINSTART_Y,
		WINSIZE_X, WINSIZE_Y,
		NULL,
		NULL,
		g_hInstance,
		NULL);

	WNDCLASS wndClass2;

	wndClass2.cbClsExtra = 0;	// 클래스 여분 메모리
	wndClass2.cbWndExtra = 0;	// 윈도우 여분 메모리
	wndClass2.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndClass2.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndClass2.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndClass2.hInstance = g_hInstance;
	wndClass2.lpfnWndProc = WndProcNew;
	wndClass2.lpszClassName = g_lpszClass2;
	wndClass2.lpszMenuName = NULL;
	wndClass2.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&wndClass2);

	g_hNewWnd = CreateWindow(g_lpszClass2, TEXT("값을 입력하세요."),
		WS_POPUP | WS_BORDER | WS_CAPTION | WS_SYSMENU,
		WINSIZE_X / 2 - 100, WINSIZE_Y/2 - 100, 200, 150, NULL, (HMENU)0, g_hInstance, NULL);

	g_hEdit = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
		45, 30, 100, 20, g_hNewWnd, (HMENU)IDC_EDITBOX_TEXT, g_hInstance, NULL);

	g_button_ok = CreateWindow("button", "확인", WS_CHILD | WS_VISIBLE | WS_BORDER,
		30, 80, 50, 25, g_hNewWnd, (HMENU)IDC_EDITBOX_OK, g_hInstance, NULL);

	g_button_cancle = CreateWindow("button", "취소", WS_CHILD | WS_VISIBLE | WS_BORDER,
		110, 80, 50, 25, g_hNewWnd, (HMENU)IDC_EDITBOX_CANCLE, g_hInstance, NULL);


	// 윈도우 출력
	ShowWindow(g_hWnd, SW_NORMAL);
	
	// 윈도우 작업영역 설정
	SetWindowSize(WINSTART_X, WINSTART_Y, WINSIZE_X, WINSIZE_Y);

	// 메인게임 초기화
	if (mainGame.Init())
	{
		return 0;
	}

	// 메시지 큐에 있는 메시지 처리
	MSG message;

	while (true)
	{
		if (PeekMessage(&message, 0, 0, 0, PM_REMOVE))
		{
			if (message.message == WM_QUIT)	break;
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
		else
		{
			TimeManager::GetSingleton()->Update(FPS);

			mainGame.Update();
			mainGame.Render();
		}
	}

	// 해제
	mainGame.Release();

	return message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage,
	WPARAM wParam, LPARAM lParam)
{
	return mainGame.MainProc(hWnd, iMessage, wParam, lParam);
}

LRESULT CALLBACK WndProcNew(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;

	PAINTSTRUCT ps;

	RECT rt = { 0, 0, 400, 300 };

	switch (iMessage)
	{

	case WM_COMMAND:

		switch (LOWORD(wParam))
		{
		case WM_PAINT:

			hdc = BeginPaint(hWnd, &ps);

			DrawText(hdc, str, -1, &rt, DT_EXPANDTABS);

			EndPaint(hWnd, &ps);

			return 0;
			
		case  IDC_EDITBOX_OK:
		
			break;

		case IDC_EDITBOX_CANCLE:
			DestroyWindow(g_hNewWnd);
			break;

		default:


			break;
		}

		return 0;

	break;

	default:

		break;
	}

	return (DefWindowProc(hWnd, iMessage, wParam, lParam));
}
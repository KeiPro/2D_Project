#include "Player.h"
#include "Animation.h"
#include "Image.h"

HRESULT Player::Init(float _editorPosition)
{
	editorPosition = _editorPosition;

	playerImg.playerIdleBodyImg			 = ImageManager::GetSingleton()->AddImage("Player_Idle_Body", "Image/Player/Body/Player_Idle_Body.bmp", 0, 0, 320, 80, 4, 1, true, RGB(86, 177, 222));
	playerImg.playerWalkBodyImg			 = ImageManager::GetSingleton()->AddImage("Player_Walk_Body", "Image/Player/Body/Player_Walk_Body.bmp", 0, 0, 960, 80, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerShootingBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Shooting_Body", "Image/Player/Body/Player_Shooting_Body.bmp", 0, 0, 900, 80, 10, 1, true, RGB(86, 177, 222));
	playerImg.playerIdleJumpBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Jump_Body", "Image/Player/Body/Player_IdleJump_Body.bmp", 0, 0, 480, 80, 6, 1, true, RGB(86, 177, 222));

	playerImg.playerWalkLegImg			 = ImageManager::GetSingleton()->AddImage("Player_Walk_Leg", "Image/Player/Leg/Player_Walk_Leg.bmp", 0, 0, 540, 25, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerIdleLegImg			 = ImageManager::GetSingleton()->AddImage("Player_Idle_Leg", "Image/Player/Leg/Player_Idle_Leg.bmp", 0, 0, 45, 25, 1, 1, true, RGB(86, 177, 222));
	playerImg.playerIdleJumpLegImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Jump_Leg", "Image/Player/Leg/Player_IdleJump_Leg.bmp", 0, 0, 270, 25, 6, 1, true, RGB(86, 177, 222));

	PlayerAnimationSetting(&playerAni);

	//ĳ���� �⺻ ����
	pos = { 200 , 100};
	relativePos = { 50, 0 };
	scale = 2.5f;
	speed = 230.0f;
	playerRect = {0, 0, 0, 0};
	

	//���� ���� ����
	yAxisV = 0;
	gAcceleration = 0;
	jumpAniCheck = false;


	//�÷��̾��� ��, ��ü ����
	playerBodyState = PlayerState::Idle;
	playerLegState = PlayerState::Idle;

	//����Ű�� ���ȴ����� üũ�ϴ� ����
	isHorizontal = false;
	isVertical = false;
	isReverse = false;


	//�ȼ� �浹�� ���� ����
	probeY = 50;
	isLanding = false;

	//ȭ�� �浹�� ���� ����
	leftCollision = false;
	rightCollision = false;

	return S_OK;
}

void Player::Release()
{
	SAFE_DELETE(playerAni.playerIdleBodyAni);
	SAFE_DELETE(playerAni.playerShootingBodyAni);
	SAFE_DELETE(playerAni.playerWalkBodyAni);
	SAFE_DELETE(playerAni.playerWalkLegAni);
	SAFE_DELETE(playerAni.playerIdleJumpBodyAni);
	SAFE_DELETE(playerAni.playerIdleJumpLegAni);
}

void Player::Update()
{
	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
	{
		isHorizontal = true;
		isReverse = true;
		rightCollision = false;

		if (isLanding == true)
		{
			//�ٵ� ����
			if (playerBodyState != PlayerState::Shooting)
				playerBodyState = PlayerState::Walk;

			//�ٸ� ����
			playerLegState = PlayerState::Walk;
		}
		else
		{
			//�ٵ� ����
			if (playerBodyState != PlayerState::Shooting)
				playerBodyState = PlayerState::Idle_Jump;

			//�ٸ� ����
			playerLegState = PlayerState::Idle_Jump;
		}

		if(leftCollision == false)
			pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
	{
		isHorizontal = true;
		isReverse = false;
		leftCollision = false;

		if (isLanding == true)
		{
			//�ٵ� ����
			if (playerBodyState != PlayerState::Shooting)
				playerBodyState = PlayerState::Walk;

			//�ٸ� ����
			playerLegState = PlayerState::Walk;
		}
		else
		{
			//�ٵ� ����
			if (playerBodyState != PlayerState::Shooting)
				playerBodyState = PlayerState::Idle_Jump;

			//�ٸ� ����
			playerLegState = PlayerState::Idle_Jump;
		}
		
		if(rightCollision == false)
			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else
	{
		isHorizontal = false;
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
	{
		isVertical = true;
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
	{
		isVertical = true;
	}
	else
	{
		isVertical = false;
	}
	
	// ��, �� Ű�� ��, �� Ű�� ������ �ʾ��� ��쿡��
	if ((!isHorizontal) && (!isVertical))
	{
		if (isLanding == true)
		{
			if (playerBodyState != PlayerState::Shooting)
				playerBodyState = PlayerState::Idle;

				playerLegState = PlayerState::Idle;
		}
		else
		{
			playerLegState = PlayerState::Idle_Jump;
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown('Z'))
	{
		playerAni.playerShootingBodyAni->Start();
		playerBodyState = PlayerState::Shooting;
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown('X'))
	{
		//���̸� ������ �����Ѵ�.
		if (isLanding == true)
		{
			if (jumpAniCheck == false)
			{
				jumpAniCheck = true;
				isLanding = false;
				gAcceleration = 0;
				yAxisV = -13.5f;
				playerBodyState = PlayerState::Idle_Jump;
				playerLegState = PlayerState::Idle_Jump;
				playerAni.playerIdleJumpBodyAni->Start();
				playerAni.playerIdleJumpLegAni->Start();
			}
		}
	}

	if ( isLanding == false )
	{
		//playerLegState = PlayerState::Idle_Jump;
		gAcceleration += 0.1f;
		yAxisV += gAcceleration * 1.1f;
		pos.y += yAxisV;
	}

	LegUpdate();

	BodyUpdate();
	
	relativePos = { pos.x + editorPosition - currPrintPos.x, pos.y - currPrintPos.y }; //ī�޶� ��ǥ�迡 ���� �����ǥ
	
	if (relativePos.x <= editorPosition + 20)
	{
		leftCollision = true;
		relativePos.x = editorPosition + 30;
	}
	else if (relativePos.x >= editorPosition + 780)
	{
		rightCollision = true;
		relativePos.x = editorPosition + 770;
	}

	//if (isLanding == false && pos.y < GAME_SIZE_Y && isStart == true)
	//{
	//	pos.y += 9.81f;
	//}

	//if (isLanding == true)
	//{
	//	isStart = false;
	//}

	// �ȼ� �浹
	pixelRect = GetRectToCenter( relativePos.x - 5, relativePos.y - 10, probeY, probeY);

	// �÷��̾� �浹���� ����
	playerRect = GetRectToCenter( relativePos.x -5, relativePos.y - 30, 50, 90);
}

void Player::Render(HDC hdc, POINT _currPrintPos)
{
	currPrintPos = _currPrintPos;
	

	//�ȼ� �浹 ��Ʈ
	Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);

	//�浹 ���� ��Ʈ
	//Rectangle(hdc, playerRect.left, playerRect.top, playerRect.right, playerRect.bottom);

	//Rectangle(hdc, pos.x - 45 + editorPosition, pos.y - 80, pos.x + 45 + editorPosition, pos.y + 60);
	
	//�ٸ��� ���¿� ���� ����
	LegRender(hdc);

	//��ü�� ���¿� ���� ����
	BodyRender(hdc);

}

void Player::Jump()
{
	
}

void Player::LegUpdate()
{
	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerLegState)
	{
	case PlayerState::Idle:

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkLegAni)
			playerAni.playerWalkLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 5.0f);


		break;

	case PlayerState::Shooting:

		break;

	case PlayerState::Idle_Jump:

		if (playerAni.playerIdleJumpLegAni)
			playerAni.playerIdleJumpLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 2.0f);

		break;

	default:

		break;
	}


}

void Player::BodyUpdate()
{
	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerAni.playerIdleBodyAni)
		{
			playerAni.playerIdleBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkBodyAni)
		{
			playerAni.playerWalkBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Shooting:

		if (playerAni.playerShootingBodyAni)
		{
			playerAni.playerShootingBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		if (playerAni.playerShootingBodyAni->GetNowPlayIdx() == playerAni.playerShootingBodyAni->GetFrameCount() - 1)
		{
			playerBodyState = PlayerState::Idle;
		}

		break;

	case PlayerState::Idle_Jump:

		if (playerAni.playerIdleJumpBodyAni)
			playerAni.playerIdleJumpBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 2.0f);

		break;

	default:

		break;
	}
}

void Player::LegRender(HDC hdc)
{
	switch (playerLegState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleLegImg)
		{
			if (isReverse == false)
				playerImg.playerIdleLegImg->FrameRender(hdc, relativePos.x, relativePos.y - 2, 0, 0, scale, false);
			else
				playerImg.playerIdleLegImg->FrameRender(hdc, relativePos.x, relativePos.y - 2, 0, 0, scale, true);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkLegImg)
		{
			if (isReverse == false)
				playerImg.playerWalkLegImg->AnimationRender(hdc, relativePos.x - 10, relativePos.y - 4, playerAni.playerWalkLegAni, scale);
			else
				playerImg.playerWalkLegImg->AnimationReverseRender(hdc, relativePos.x + 10, relativePos.y - 4, playerAni.playerWalkLegAni, scale);
		}

		break;

	case PlayerState::Idle_Jump:

		if (playerImg.playerIdleJumpLegImg)
		{
			if (isReverse == false)
				playerImg.playerIdleJumpLegImg->AnimationRender(hdc, relativePos.x, relativePos.y - 10, playerAni.playerIdleJumpLegAni, scale);
			else	
				playerImg.playerIdleJumpLegImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 10, playerAni.playerIdleJumpLegAni, scale);
		}

		break;

	default:

		break;
	}

}

void Player::BodyRender(HDC hdc)
{

	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleBodyImg)
		{
			if (isReverse == false)
				playerImg.playerIdleBodyImg->AnimationRender(hdc, relativePos.x, relativePos.y - 27, playerAni.playerIdleBodyAni, scale);
			else
				playerImg.playerIdleBodyImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 27, playerAni.playerIdleBodyAni, scale);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkBodyImg)
		{
			if (isReverse == false)
				playerImg.playerWalkBodyImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerWalkBodyAni, scale);
			else
				playerImg.playerWalkBodyImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerWalkBodyAni, scale);
		}

		break;

	case PlayerState::Shooting:

		if (playerImg.playerShootingBodyImg)
		{
			if (isReverse == false)
				playerImg.playerShootingBodyImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerShootingBodyAni, scale);
			else
				playerImg.playerShootingBodyImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerShootingBodyAni, scale);
		}

		break;

	case PlayerState::Idle_Jump:
		
		if (playerImg.playerIdleJumpBodyImg)
		{
			if (isReverse == false)
				playerImg.playerIdleJumpBodyImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerIdleJumpBodyAni, scale);
			else	
				playerImg.playerIdleJumpBodyImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 30, playerAni.playerIdleJumpBodyAni, scale);
		}
		
		break;

	default:

		break;
	}

}





void Player::PlayerAnimationSetting(PlayerAni* playerAni)
{
	//Body Animationó��.
	(*playerAni).playerIdleBodyAni = new Animation();
	(*playerAni).playerIdleBodyAni->Init(playerImg.playerIdleBodyImg->GetWidth(), playerImg.playerIdleBodyImg->GetHeight(),
		playerImg.playerIdleBodyImg->GetFrameWidth(), playerImg.playerIdleBodyImg->GetFrameHeight());
	(*playerAni).playerIdleBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerIdleBodyAni->SetUpdateTime(FPS / 5);
	(*playerAni).playerIdleBodyAni->Start();

	(*playerAni).playerWalkBodyAni = new Animation();
	(*playerAni).playerWalkBodyAni->Init(playerImg.playerWalkBodyImg->GetWidth(), playerImg.playerWalkBodyImg->GetHeight(),
		playerImg.playerWalkBodyImg->GetFrameWidth(), playerImg.playerWalkBodyImg->GetFrameHeight());
	(*playerAni).playerWalkBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkBodyAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkBodyAni->Start();

	(*playerAni).playerShootingBodyAni = new Animation();
	(*playerAni).playerShootingBodyAni->Init(playerImg.playerShootingBodyImg->GetWidth(), playerImg.playerShootingBodyImg->GetHeight(),
		playerImg.playerShootingBodyImg->GetFrameWidth(), playerImg.playerShootingBodyImg->GetFrameHeight());
	(*playerAni).playerShootingBodyAni->SetPlayFrame(false, false);
	(*playerAni).playerShootingBodyAni->SetUpdateTime(FPS * 2);
	(*playerAni).playerShootingBodyAni->Start();

	int arrAni_jumpBody[] = { 0, 1, 2, 3, 4, 5, 5, 5, 4, 3 };
	(*playerAni).playerIdleJumpBodyAni = new Animation();
	(*playerAni).playerIdleJumpBodyAni->Init(playerImg.playerIdleJumpBodyImg->GetWidth(), playerImg.playerIdleJumpBodyImg->GetHeight(),
		playerImg.playerIdleJumpBodyImg->GetFrameWidth(), playerImg.playerIdleJumpBodyImg->GetFrameHeight());
	(*playerAni).playerIdleJumpBodyAni->SetPlayFrame(arrAni_jumpBody, sizeof(arrAni_jumpBody) / sizeof(int), false, false);
	(*playerAni).playerIdleJumpBodyAni->SetUpdateTime(FPS / 4);
	(*playerAni).playerIdleJumpBodyAni->Start();




	//Leg Animationó��
	(*playerAni).playerWalkLegAni = new Animation();
	(*playerAni).playerWalkLegAni->Init(playerImg.playerWalkLegImg->GetWidth(), playerImg.playerWalkLegImg->GetHeight(),
		playerImg.playerWalkLegImg->GetFrameWidth(), playerImg.playerWalkLegImg->GetFrameHeight());
	(*playerAni).playerWalkLegAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkLegAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkLegAni->Start();


	int arrAni_jumpLeg[] = { 0, 1, 2, 3, 4, 5, 5, 5, 4, 3 };
	(*playerAni).playerIdleJumpLegAni = new Animation();
	(*playerAni).playerIdleJumpLegAni->Init(playerImg.playerIdleJumpLegImg->GetWidth(), playerImg.playerIdleJumpLegImg->GetHeight(),
		playerImg.playerIdleJumpLegImg->GetFrameWidth(), playerImg.playerIdleJumpLegImg->GetFrameHeight());
	(*playerAni).playerIdleJumpLegAni->SetPlayFrame(true, false);
	(*playerAni).playerIdleJumpLegAni->SetUpdateTime(FPS / 4);
	(*playerAni).playerIdleJumpLegAni->Start();


}


Player::Player()
{
}


Player::~Player()
{
}

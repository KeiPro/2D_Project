#include "EditorScene.h"
#include "Image.h"


HRESULT EditorScene::Init()
{
	panel = { 0, 0, WINSIZE_X, WINSIZE_Y };
	editorMenuPanel = { 0, 0, WINSIZE_X / 3, WINSIZE_Y };
	editorMapPanel = {WINSIZE_X / 3, 0, WINSIZE_X, WINSIZE_Y};

	//�귯�� ����
	hWhiteBrush = CreateSolidBrush(RGB(255, 255, 255));
	hBlackBrush = CreateSolidBrush(RGB(0, 0, 0));
	hGreyBrush = CreateSolidBrush(RGB(195, 195, 195));

	saveButtonRect = { 0 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 6 - 20), (WINSIZE_Y * 3 / 4) + 40 };
	loadButtonRect = { WINSIZE_X / 6 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 3 - 20), (WINSIZE_Y * 3 / 4) + 40 };

	currentprintPos = {0, 0};
	stage2MapImg = ImageManager::GetSingleton()->AddImage("Stage2_Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));

	g_wheelMouse = 1.0f;
	mouseClickDown = false;

	return S_OK;
}

void EditorScene::Release()
{
}

void EditorScene::Update()
{

	//editorMap�� ���콺���� ����
	if (PtInRect(&editorMapPanel, g_ptMouse))
	{
		if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
		{
			if (mouseClickDown == false)
			{
				mousePos[0] = g_ptMouse;
				mouseClickDown = true;
			}
		}

		if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON))
		{
			mouseClickDown = false;
			currentprintPos.x += (mousePos[0].x - g_ptMouse.x) * 0.5f;
			currentprintPos.y += (mousePos[0].y - g_ptMouse.y) * 0.5f;
		}
	}




}

void EditorScene::Render(HDC hdc)
{
	// Panel
	FillRect(hdc, &panel, hGreyBrush);

	// ��輱
	FillRect(hdc, &editorMenuPanel, hWhiteBrush);

	FillRect(hdc, &saveButtonRect, hBlackBrush);
	FillRect(hdc, &loadButtonRect, hBlackBrush);

	stage2MapImg->MapEditorRender(hdc, (WINSIZE_X / 3 + 20), 0, g_wheelMouse, currentprintPos);


	char szText[128];
	sprintf_s(szText, "���콺 ��ġ : [%d, %d]", g_ptMouse.x, g_ptMouse.y);
	TextOut(hdc, 50, 50, szText, strlen(szText));

	char szText2[128];
	sprintf_s(szText2, " �� ������ ��ġ : [ %d, %d, %f ] ", currentprintPos.x, currentprintPos.y, g_wheelMouse);
	TextOut(hdc, 50, 100, szText2, strlen(szText2));
}

EditorScene::EditorScene()
{
}


EditorScene::~EditorScene()
{
}

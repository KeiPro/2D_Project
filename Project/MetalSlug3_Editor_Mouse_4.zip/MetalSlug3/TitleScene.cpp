#include "TitleScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT TitleScene::Init()
{
	//body_AnimationImage = ImageManager::GetSingleton()->AddImage("Player_Walk_Body", "Image/Player/Body/Player_Walk_Body.bmp", 0, 0, 960 * 2, 80 * 2, 12, 1, true, RGB(86,177,222));
	//leg_AnimationImage = ImageManager::GetSingleton()->AddImage("Player_Walk_Leg", "Image/Player/Leg/Player_Walk_Leg.bmp", 0, 0, 540 * 2, 25 * 2, 12, 1, true, RGB(86, 177, 222));
	//
	//testAni = new Animation();
	//testAni->Init(body_AnimationImage->GetWidth(), body_AnimationImage->GetHeight(), body_AnimationImage->GetFrameWidth(), body_AnimationImage->GetFrameHeight());
	//testAni->SetPlayFrame(false, true);
	//testAni->SetUpdateTime(FPS * 2 / 3);
	//testAni->Start();

	//testAni_leg = new Animation();
	//testAni_leg->Init(leg_AnimationImage->GetWidth(), leg_AnimationImage->GetHeight(), leg_AnimationImage->GetFrameWidth(), leg_AnimationImage->GetFrameHeight());
	//testAni_leg->SetPlayFrame(false, true);
	//testAni_leg->SetUpdateTime(FPS * 2 / 3);
	//testAni_leg->Start();
	//testAni2 = 



	return S_OK;
}

void TitleScene::Release()
{
	//SAFE_DELETE(testAni);
}

void TitleScene::Update()
{
	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	{
		//SceneManager::GetSingleton()->ChangeScene("BattleScene");	
		SceneManager::GetSingleton()->ChangeScene("EditorScene");
	}

	//testAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	//testAni_leg->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void TitleScene::Render(HDC hdc)
{
	//leg_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2 - 10, WINSIZE_Y / 2 + 40, testAni_leg);
	//body_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, testAni);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}

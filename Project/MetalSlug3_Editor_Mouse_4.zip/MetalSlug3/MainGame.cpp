#include "Image.h"
#include "MainGame.h"
#include "TitleScene.h"
#include "LoadingScene.h"
#include "CharacterSelectScene.h"
#include "StageSecondScene.h"
#include "BattleScene.h"
#include "EditorScene.h"

HRESULT MainGame::Init()
{
	hdc = GetDC(g_hWnd);

	// backBuffer
	backBuffer = new Image();
	backBuffer->Init(WINSIZE_X, WINSIZE_Y);

	KeyManager::GetSingleton()->Init();
	ImageManager::GetSingleton()->Init();
	TimeManager::GetSingleton()->Init();
	SoundManager::GetSingleton()->Init();
	SceneManager::GetSingleton()->Init();

	titleScene = new TitleScene();
	SceneManager::GetSingleton()->AddScene("TitleScene", titleScene);

	characterSelectScene = new CharacterSelectScene();
	SceneManager::GetSingleton()->AddScene("CharacterSelectScene", titleScene);

	stageSecondScene = new StageSecondScene();
	SceneManager::GetSingleton()->AddScene("StageSecondScene", stageSecondScene);

	battleScene = new BattleScene();
	SceneManager::GetSingleton()->AddScene("BattleScene", battleScene);

	editorScene = new EditorScene();
	SceneManager::GetSingleton()->AddScene("EditorScene", editorScene);


	//titleScene->Init();

	//loadingScene = new LoadingScene();
	//SceneManager::GetSingleton()->AddLoadingScene("�ε�1", loadingScene);
	//loadingScene->Init();

	/*tileMapToolScene = new TilemapToolScene();
	SceneManager::GetSingleton()->AddScene("�ʿ�����", tileMapToolScene);
	tileMapToolScene->Init();*/

	//SceneManager::GetSingleton()->ChangeScene("BattleScene");
	SceneManager::GetSingleton()->ChangeScene("TitleScene");

	isInit = true;

	return S_OK;
}

void MainGame::Release()
{
	battleScene->Release();
	SAFE_DELETE(battleScene);

	stageSecondScene->Release();
	SAFE_DELETE(stageSecondScene);

	characterSelectScene->Release();
	SAFE_DELETE(characterSelectScene);

	titleScene->Release();
	SAFE_DELETE(titleScene);

	SceneManager::GetSingleton()->Release();
	SceneManager::GetSingleton()->ReleaseSingleton();

	SoundManager::GetSingleton()->Release();
	SoundManager::GetSingleton()->ReleaseSingleton();

	TimeManager::GetSingleton()->Release();
	TimeManager::GetSingleton()->ReleaseSingleton();
	
	ImageManager::GetSingleton()->Release();
	ImageManager::GetSingleton()->ReleaseSingleton();

	KeyManager::GetSingleton()->Release();
	KeyManager::GetSingleton()->ReleaseSingleton();

	backBuffer->Release();
	delete backBuffer;

	ReleaseDC(g_hWnd, hdc);
}

void MainGame::Update()
{
	SceneManager::GetSingleton()->Update();

	//if (tileMapToolScene)
	//	tileMapToolScene->Update();

	
	InvalidateRect(g_hWnd, NULL, false);
}

void MainGame::Render()
{	
	SceneManager::GetSingleton()->Render(backBuffer->GetMemDC());

	//TimeManager::GetSingleton()->Render(backBuffer->GetMemDC());

	//if(tileMapToolScene)
	//	tileMapToolScene->Render(backBuffer->GetMemDC());
	
	backBuffer->Render(hdc, 0, 0);
}

LRESULT MainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	case WM_MOUSEMOVE:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		break;

	case WM_TIMER:
		//if (isInit)
		//	this->Update();
		break;

	case WM_MOUSEWHEEL:

		if ((SHORT)HIWORD(wParam) > 0) //���콺���� �ø� ���
		{
			if(g_wheelMouse < 2.9f)
				g_wheelMouse += 0.1f;
		}
		else  //���콺���� ���� ���
		{
			if(g_wheelMouse > 0.9f)
				g_wheelMouse -= 0.1f;
		}

		break;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		//if (isInit)
		//	this->Render(hdc);

		EndPaint(hWnd, &ps);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}


MainGame::MainGame()
	: isInit(false)
{
}


MainGame::~MainGame()
{
}

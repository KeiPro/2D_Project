#include "Object.h"



HRESULT Object::Init()
{
	return S_OK;
}

void Object::Release()
{
}

void Object::Update()
{
}

void Object::Render(HDC hdc)
{
}

Object::Object()
{
}


Object::~Object()
{
}

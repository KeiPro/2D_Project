#include "Background.h"
#include "Image.h"

HRESULT Background::Init()
{
	stage2MapImg = ImageManager::GetSingleton()->AddImage("Stage2_Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));



	return S_OK;
}

void Background::Release()
{
}

void Background::Update()
{
}

void Background::Render(HDC hdc)
{
	if (stage2MapImg)
	{
		stage2MapImg->BackgroundMapRender(hdc, 0, 0);
	}
}

Background::Background()
{
}


Background::~Background()
{
}

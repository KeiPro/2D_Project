#include "Player.h"
#include "Animation.h"
#include "Image.h"

HRESULT Player::Init()
{
	playerImg.playerIdleBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Body", "Image/Player/Body/Player_Idle_Body.bmp", 0, 0, 320, 80, 4, 1, true, RGB(86, 177, 222));
	playerImg.playerWalkBodyImg		 = ImageManager::GetSingleton()->AddImage("Player_Walk_Body", "Image/Player/Body/Player_Walk_Body.bmp", 0, 0, 960, 80, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerShootingBodyImg  = ImageManager::GetSingleton()->AddImage("Player_Shooting_Body", "Image/Player/Body/Player_Shooting_Body.bmp", 0, 0, 900, 80, 10, 1, true, RGB(86, 177, 222));
	
	playerImg.playerWalkLegImg		 = ImageManager::GetSingleton()->AddImage("Player_Walk_Leg", "Image/Player/Leg/Player_Walk_Leg.bmp", 0, 0, 540, 25, 12, 1, true, RGB(86, 177, 222));
	playerImg.playerIdleLegImg		 = ImageManager::GetSingleton()->AddImage("Player_Idle_Leg", "Image/Player/Leg/Player_Idle_Leg.bmp", 0, 0, 47, 25, 1, 1, true, RGB(86, 177, 222));

	PlayerAnimationSetting(&playerAni);


	//�ɸ��� �⺻ ����
	pos = {WINSIZE_X / 2, WINSIZE_Y / 2 + 100};
	speed = 200.0f;

	//�÷��̾��� ��, ��ü ����
	playerBodyState = PlayerState::Idle;
	playerLegState = PlayerState::Idle;

	//����Ű�� ���ȴ����� üũ�ϴ� ����
	isHorizontal = false;
	isVertical = false;


	return S_OK;
}

void Player::Release()
{
	SAFE_DELETE(playerAni.playerIdleBodyAni);
	SAFE_DELETE(playerAni.playerShootingBodyAni);
	SAFE_DELETE(playerAni.playerWalkBodyAni);
	SAFE_DELETE(playerAni.playerWalkLegAni);
}

void Player::Update()
{
	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
	{
		isHorizontal = true;

		if (playerBodyState != PlayerState::Shooting)
			playerBodyState = PlayerState::Walk;
			
		playerLegState = PlayerState::Walk;

		pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
	{
		isHorizontal = true;

		//�ٵ� ����
		if (playerBodyState != PlayerState::Shooting)
			playerBodyState = PlayerState::Walk;

		//�ٸ� ����
		playerLegState = PlayerState::Walk;

		pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else
	{
		isHorizontal = false;
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
	{
		isVertical = true;
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
	{
		isVertical = true;
	}
	else
	{
		isVertical = false;
	}

	// ��, �� Ű�� ��, �� Ű�� ������ �ʾ��� ��쿡��
	if ((!isHorizontal) && (!isVertical))
	{
		if((playerBodyState != PlayerState::Shooting))
			playerBodyState = PlayerState::Idle;

		playerLegState = PlayerState::Idle;
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown('Z'))
	{
		playerAni.playerShootingBodyAni->Start();
		playerBodyState = PlayerState::Shooting;
	}


	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerLegState)
	{
	case PlayerState::Idle:

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkLegAni)
		{
			playerAni.playerWalkLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}
	
		break;

	case PlayerState::Shooting:

		break;

	default:

		break;
	}

	//��ü�� ���¸� case�� �����Ͽ� UpdateKeyFrame����.
	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerAni.playerIdleBodyAni)
		{
			playerAni.playerIdleBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Walk:

		if (playerAni.playerWalkBodyAni)
		{
			//playerAni.playerWalkLegAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
			playerAni.playerWalkBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		break;

	case PlayerState::Shooting:

		if (playerAni.playerShootingBodyAni)
		{
			playerAni.playerShootingBodyAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		if (playerAni.playerShootingBodyAni->GetNowPlayIdx() == playerAni.playerShootingBodyAni->GetFrameCount() - 1)
		{
			playerBodyState = PlayerState::Idle;
		}

		break;

	default:

		break;
	}
}





void Player::Render(HDC hdc)
{

	//�ٸ��� ���¿� ���� ����
	switch (playerLegState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleLegImg)
		{
			playerImg.playerIdleLegImg->FrameRender(hdc, pos.x - 7, pos.y-1, 0, 0, 2.0f);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkLegImg)
		{
			playerImg.playerWalkLegImg->AnimationRender(hdc, pos.x - 7, pos.y-1, playerAni.playerWalkLegAni, 2.0f);
		}

		break;

	default:

		break;
	}


	//��ü�� ���¿� ���� ����
	switch (playerBodyState)
	{
	case PlayerState::Idle:

		if (playerImg.playerIdleBodyImg)
		{
			playerImg.playerIdleBodyImg->AnimationRender(hdc, pos.x, pos.y - 40, playerAni.playerIdleBodyAni, 2.0f);
		}

		break;

	case PlayerState::Walk:

		if (playerImg.playerWalkBodyImg)
		{
			playerImg.playerWalkBodyImg->AnimationRender(hdc, pos.x, pos.y - 40, playerAni.playerWalkBodyAni, 2.0f);
		}

		break;

	case PlayerState::Shooting:

		if (playerImg.playerShootingBodyImg)
		{
			playerImg.playerShootingBodyImg->AnimationRender(hdc, pos.x, pos.y - 40, playerAni.playerShootingBodyAni, 2.0f);
		}

		break;

	default:

		break;
	}
}

void Player::PlayerAnimationSetting(PlayerAni * playerAni)
{
	(*playerAni).playerIdleBodyAni = new Animation();
	(*playerAni).playerIdleBodyAni->Init(playerImg.playerIdleBodyImg->GetWidth(), playerImg.playerIdleBodyImg->GetHeight(), 
		playerImg.playerIdleBodyImg->GetFrameWidth(), playerImg.playerIdleBodyImg->GetFrameHeight());
	(*playerAni).playerIdleBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerIdleBodyAni->SetUpdateTime(FPS / 5);
	(*playerAni).playerIdleBodyAni->Start();

	(*playerAni).playerWalkBodyAni = new Animation();
	(*playerAni).playerWalkBodyAni->Init(playerImg.playerWalkBodyImg->GetWidth(), playerImg.playerWalkBodyImg->GetHeight(),
		playerImg.playerWalkBodyImg->GetFrameWidth(), playerImg.playerWalkBodyImg->GetFrameHeight());
	(*playerAni).playerWalkBodyAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkBodyAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkBodyAni->Start();

	(*playerAni).playerShootingBodyAni = new Animation();
	(*playerAni).playerShootingBodyAni->Init(playerImg.playerShootingBodyImg->GetWidth(), playerImg.playerShootingBodyImg->GetHeight(),
		playerImg.playerShootingBodyImg->GetFrameWidth(), playerImg.playerShootingBodyImg->GetFrameHeight());
	(*playerAni).playerShootingBodyAni->SetPlayFrame(false, false);
	(*playerAni).playerShootingBodyAni->SetUpdateTime(FPS * 2);
	(*playerAni).playerShootingBodyAni->Start();

	(*playerAni).playerWalkLegAni = new Animation();
	(*playerAni).playerWalkLegAni->Init(playerImg.playerWalkLegImg->GetWidth(), playerImg.playerWalkLegImg->GetHeight(),
		playerImg.playerWalkLegImg->GetFrameWidth(), playerImg.playerWalkLegImg->GetFrameHeight());
	(*playerAni).playerWalkLegAni->SetPlayFrame(false, true);
	(*playerAni).playerWalkLegAni->SetUpdateTime(FPS * 2 / 3);
	(*playerAni).playerWalkLegAni->Start();
}

Player::Player()
{
}


Player::~Player()
{
}

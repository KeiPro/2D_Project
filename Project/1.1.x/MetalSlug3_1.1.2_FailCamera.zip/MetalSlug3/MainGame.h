#pragma once
#include "GameNode.h"


class Image;
class BattleScene;
class TitleScene;
class LoadingScene;
class TilemapToolScene;
class MainGame : public GameNode
{
private:
	HDC hdc;
	bool isInit;
	HANDLE hTimer;

	GameNode* titleScene;	// Ÿ��Ʋ��
	GameNode* characterSelectScene;
	GameNode* stageSecondScene;
	GameNode* battleScene;
	//GameNode* battleScene;	// ��Ʋ��
	//GameNode* loadingScene;	// �ε���
	//GameNode* tileMapToolScene;
	
	Image* backBuffer;

public:
	virtual HRESULT Init();
	virtual void Release();
	virtual void Update();
	virtual void Render();

	LRESULT MainProc(HWND hWnd, UINT iMessage,
		WPARAM wParam, LPARAM lParam);

	MainGame();
	~MainGame();
};


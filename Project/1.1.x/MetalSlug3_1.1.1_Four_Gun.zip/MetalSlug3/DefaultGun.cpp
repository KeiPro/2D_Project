#include "DefaultGun.h"
#include "Image.h"
#include "Missile.h"
#include "Animation.h"


void DefaultGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* defaultMissile = missileStack.top();
		defaultMissile->SetIsFire(true);
		defaultMissile->SetPos(firePos);
		defaultMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(defaultMissile);
	}
}

void DefaultGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();

		if ((*it)->GetPos().x >= WINSIZE_X || (*it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10)
		{
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}

		if (it == missileVec.end())
			break;
	}
}

void DefaultGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void DefaultGun::Release()
{

}

//�⺻ �Ѿ��� 50������ ����.
DefaultGun::DefaultGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		DefaultMissile* defaultMissile = new DefaultMissile();
		defaultMissile->Init();
		missileStack.push(defaultMissile);
	}
}


DefaultGun::~DefaultGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void HeavyMachinGun::Attack(FPOINT firePos, float fireAngle, int _heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* heavyMissile = missileStack.top();
		heavyMissile->SetIsFire(true);
		switch (_heavyMissile)
		{
			case 0: heavyMissile->SetPos({ firePos.x, firePos.y - 20 }); break;
			case 1: heavyMissile->SetPos({ firePos.x, firePos.y - 15}); break;
			case 2: heavyMissile->SetPos({ firePos.x, firePos.y  }); break;
		}
		
		heavyMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(heavyMissile);
	}
}

void HeavyMachinGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();

		if ((*it)->GetPos().x >= WINSIZE_X || (*it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10)
		{
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}

		if (it == missileVec.end())
			break;
	}
}

void HeavyMachinGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void HeavyMachinGun::Release()
{
}

HeavyMachinGun::HeavyMachinGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		HeavyMissile* heavyMissile = new HeavyMissile();
		heavyMissile->Init();
		missileStack.push(heavyMissile);
	}
}

HeavyMachinGun::~HeavyMachinGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void FlameShotGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* flameMissile = missileStack.top();
		flameMissile->SetIsFire(true);
		flameMissile->SetPos(firePos);
		flameMissile->SetAngle(fireAngle);
		missileStack.pop();
		missileVec.push_back(flameMissile);
	}
}

void FlameShotGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();
		
	/*	....*/
		FlameMissile* _flameMissile = (FlameMissile*)(*it);
		
		// �ִϸ��̼� ������ �����ӱ��� �������� ��� Stack�� �ٽ� �����Ѵ�.
		if (_flameMissile->GetAni()->GetNowPlayIdx() == _flameMissile->GetAni()->GetFrameCount() - 1)
		{
			_flameMissile->GetAni()->Start();
			_flameMissile->SetSpeed(500.0f);
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}


		if (it == missileVec.end())
			break;
	}
}

void FlameShotGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void FlameShotGun::Release()
{
}

FlameShotGun::FlameShotGun()
{
	missileVec.reserve(10);

	for (int i = 0; i < 10; i++)
	{
		FlameMissile* flameMissile = new FlameMissile();
		flameMissile->Init();
		missileStack.push(flameMissile);
	}
}

FlameShotGun::~FlameShotGun()
{
	for (int i = 0; i < 10; i++)
	{
		if (missileStack.empty()) break;
		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void RocketLauncherGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* rocketMissile = missileStack.top();
		rocketMissile->SetIsFire(true);
		rocketMissile->SetPos(firePos);
		rocketMissile->SetAngle(fireAngle);
		missileStack.pop();
		missileVec.push_back(rocketMissile);
	}
}

void RocketLauncherGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();

		if ((*it)->GetPos().x >= WINSIZE_X || (*it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10)
		{
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}

		if (it == missileVec.end()) break;
	}
}

void RocketLauncherGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void RocketLauncherGun::Release()
{
}

RocketLauncherGun::RocketLauncherGun()
{
	missileVec.reserve(30);

	for (int i = 0; i < 30; i++)
	{
		RocketMissile* rocketMissile = new RocketMissile();
		rocketMissile->Init();
		missileStack.push(rocketMissile);
	}
}

RocketLauncherGun::~RocketLauncherGun()
{
	for (int i = 0; i < 30; i++)
	{
		if (missileStack.empty()) break;
		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

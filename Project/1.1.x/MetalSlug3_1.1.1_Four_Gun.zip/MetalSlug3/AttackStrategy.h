#pragma once
#include "GameNode.h"

class AttackStrategy : public GameNode
{
public:
	virtual void Attack(FPOINT pos, float angle, int heavyMissile = 0) = 0;
	virtual void Update() = 0;

	AttackStrategy();
	virtual ~AttackStrategy();
};


#pragma once
#include "GameNode.h"

class Player;
class Image;
class PixelCollision : public GameNode
{
	Player* player;
	Image*  pixelBackground;
	Image*	pixelBackbuffer;

	int currentPrintPosX;
	int currentPrintPosY;

public:

	HRESULT Init();
	void Update(int currentPrintPosX = 0, int currentPrintPosY = 0);
	void Release();
	void Render(HDC hdc);
	

	void SetPlayer(Player* _player) { player = _player; }
	void SetCurrentPrintPosX(int _currentX) { currentPrintPosX = _currentX; }
	void SetCurrentPrintPosY(int _currentY) { currentPrintPosY = _currentY; }

	PixelCollision();
	~PixelCollision();
};


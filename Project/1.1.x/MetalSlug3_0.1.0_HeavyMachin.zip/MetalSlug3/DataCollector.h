#pragma once
#include "pch.h"
#include "SingletonBase.h"

class Player;
class DataCollector : public SingletonBase<DataCollector>
{
	Player* player;
	int editorAddValue;

public:

	void SetPlayer(Player* _player) { player = _player; }
	Player* GetPlayer() { return player; }

	void SetEditorAddValue(int _addValue) { editorAddValue = _addValue; }
	int GetEditorAddValue() { return editorAddValue; }


	DataCollector();
	~DataCollector();
};


#pragma once
#include "AttackStrategy.h"

class Missile;
class DefaultGun : public AttackStrategy
{
private:
	
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;
	

public:
	virtual void Attack(FPOINT firePos, float firAngle);
	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();

	DefaultGun();
	virtual ~DefaultGun();
};

class HeavyMachinGun : public AttackStrategy
{
private:
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;

public:

	virtual void Attack(FPOINT firePos, float firAngle);
	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();

	HeavyMachinGun();
	virtual ~HeavyMachinGun();
};

class FlameShotGun : public AttackStrategy
{
private:
	Missile* missile;

public:
	virtual void Attack(FPOINT firePos, float fireAngle);
	virtual void Update();

	FlameShotGun();
	virtual ~FlameShotGun();
};

class RocketLauncherGun : public AttackStrategy
{
private:
	Missile* missile;


public:
	virtual void Attack(FPOINT firePos, float fireAngle);
	virtual void Update();

	RocketLauncherGun();
	virtual ~RocketLauncherGun();
};


#include "DefaultGun.h"
#include "Image.h"
#include "Missile.h"


void DefaultGun::Attack(FPOINT firePos, float fireAngle)
{
	if (!missileStack.empty())
	{
		Missile* defaultMissile = missileStack.top();
		defaultMissile->SetIsFire(true);
		defaultMissile->SetPos(firePos);
		defaultMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(defaultMissile);
	}
}

void DefaultGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();

		if ((*it)->GetPos().x >= WINSIZE_X || (*it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10)
		{
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}

		if (it == missileVec.end())
			break;
	}
}

void DefaultGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void DefaultGun::Release()
{

}

//�⺻ �Ѿ��� 50������ ����.
DefaultGun::DefaultGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		DefaultMissile* defaultMissile = new DefaultMissile();
		defaultMissile->Init();
		missileStack.push(defaultMissile);
	}
}


DefaultGun::~DefaultGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void HeavyMachinGun::Attack(FPOINT firePos, float fireAngle)
{
	if (!missileStack.empty())
	{
		Missile* defaultMissile = missileStack.top();
		defaultMissile->SetIsFire(true);
		defaultMissile->SetPos(firePos);
		defaultMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(defaultMissile);
	}
}

void HeavyMachinGun::Update()
{
	for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	{
		(*it)->Update();

		if ((*it)->GetPos().x >= WINSIZE_X || (*it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10)
		{
			Missile* tmpMissile = *it;
			(*it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			it = missileVec.erase(it);
		}

		if (it == missileVec.end())
			break;
	}
}

void HeavyMachinGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void HeavyMachinGun::Release()
{
}

HeavyMachinGun::HeavyMachinGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		HeavyMissile* defaultMissile = new HeavyMissile();
		defaultMissile->Init();
		missileStack.push(defaultMissile);
	}
}

HeavyMachinGun::~HeavyMachinGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void FlameShotGun::Attack(FPOINT firePos, float fireAngle)
{
}

void FlameShotGun::Update()
{

}

FlameShotGun::FlameShotGun()
{
	missile = new FlameMissile();

}

FlameShotGun::~FlameShotGun()
{
}

void RocketLauncherGun::Attack(FPOINT firePos, float fireAngle)
{

}

void RocketLauncherGun::Update()
{
}

RocketLauncherGun::RocketLauncherGun()
{
	missile = new RocketMissile();
}

RocketLauncherGun::~RocketLauncherGun()
{
}

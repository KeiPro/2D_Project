#include "Attacking.h"

Attacking::Attacking() : attackStrategy(nullptr)
{
}


Attacking::~Attacking()
{

}

#include "AttackStrategy.h"

void AttackStrategy::Attack(FPOINT pos, float angle)
{
}

AttackStrategy::AttackStrategy()
{
}


AttackStrategy::~AttackStrategy()
{
}

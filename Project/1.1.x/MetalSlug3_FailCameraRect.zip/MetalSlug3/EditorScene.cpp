#include "EditorScene.h"
#include "Image.h"
#include "ButtonFunction.h"
#include "Button.h"

HRESULT EditorScene::Init()
{
	stage2MapImg = ImageManager::GetSingleton()->AddImage("Stage1_Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));
	buttonClickImg = ImageManager::GetSingleton()->AddImage("CameraButtonImg", "Image/Button/button.bmp", 0.0f, 0.0f, 122, 62, 1, 2);
	

	panel = { 0, 0, WINSIZE_X, WINSIZE_Y };
	editorMenuPanel = { 0, 0, WINSIZE_X / 3, WINSIZE_Y };
	editorMapPanel = {WINSIZE_X / 3, 0, WINSIZE_X, WINSIZE_Y};

	//�귯�� ����
	hWhiteBrush = CreateSolidBrush(RGB(255, 255, 255));
	hBlackBrush = CreateSolidBrush(RGB(0, 0, 0));
	hGreyBrush = CreateSolidBrush(RGB(195, 195, 195));

	saveButtonRect = { 0 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 6 - 20), (WINSIZE_Y * 3 / 4) + 40 };
	loadButtonRect = { WINSIZE_X / 6 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 3 - 20), (WINSIZE_Y * 3 / 4) + 40 };

	currentPrintPos = {0, 0};

	//g_wheelMouse = 1.0f;
	mouseClickDown = false;

	POINT upFramePoint = { 0, 0 };
	POINT downFramePoint = { 0, 1 };

	//// ��ư
	buttonRect[0] = GetRectToCenter(WINSIZE_X / 12 - 30,  WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[2] = GetRectToCenter(WINSIZE_X / 4 + 30, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[3] = GetRectToCenter(WINSIZE_X / 8 - 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[4] = GetRectToCenter(WINSIZE_X * 5 / 24 + 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());

	for (int i = 0; i < 5; i++)
	{
		buttonDown[i] = false;
	}

	//H ��ư�� ������ �ִ����� üũ�� ����
	hButtonCheck = false;

	//�� ��° ��ư�� ���ȴ����� üũ�� ����
	buttonTmp = 0;

	//�޴� ī�޶� ��Ʈ ����
	menuCameraYRect = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2, 20, 100);
	menuCameraMoveYRect = menuCameraYRect;
	menuCameraMouseMove = false;
	menuCameraRectMoveCheck = false;

	//�޴� ���׹� ��Ʈ ����
	menuEnemyRect[0] = GetRectToCenter(WINSIZE_X / 12, WINSIZE_Y / 2, 50, 80);
	menuEnemyRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2, 50, 100);
	menuEnemyRect[2] = GetRectToCenter(WINSIZE_X / 4, WINSIZE_Y / 2, 100, 100);
	menuEnemyMoveRect = menuEnemyRect[0];
	enemyId = -1;
	menuEnemyMoveBool = false;


	buttonType = BUTTON_TYPE::TYPE_NONE;

	//����� ���
	debugMode = false;

	return S_OK;
}

void EditorScene::Release()
{
}

void EditorScene::Update()
{
	//editorMap�� ���콺���� ����

	if (KeyManager::GetSingleton()->IsStayKeyDown('H'))
	{
		hButtonCheck = true;
	}
	
	if (KeyManager::GetSingleton()->IsOnceKeyUp('H'))
	{
		hButtonCheck = false;
	}

	if ( PtInRect(&editorMapPanel, g_ptMouse) )
	{
		if (hButtonCheck == true)
		{	//hButton�� ������ ������ �� �����͸� �̵���Ų��. ( �ڵ��� )
			if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
			{
				if (mouseClickDown == false)
				{
					mousePos[0] = g_ptMouse;
					mouseClickDown = true;
				}

				//if (mouseClickDown == true)
				//{
				//	mousePos[1] = g_ptMouse;
				//}

				//if (mousePos[1].x != mousePos[2].x && mousePos[1].y != mousePos[2].y)
				//{
				//	currentprintPos.x += (mousePos[2].x - mousePos[1].x) * 0.5f;
				//	currentprintPos.y += (mousePos[2].y - mousePos[1].y) * 0.5f;
				//}

				//mousePos[2] = g_ptMouse;
			}

			if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON))
			{
				mouseClickDown = false;

				// �� ������ ��ġ������ ����Ǳ� ���� ����ó��
				// if (g_ptMouse.x <= 445) g_ptMouse.x = mousePos[0].x;
				mapMoveValue.x = (mousePos[0].x - g_ptMouse.x);

				currentPrintPos.x += mapMoveValue.x;


				//currentPrintPos����ó��.
				if (currentPrintPos.x <= 0 || currentPrintPos.x >= 5175)
				{
					if(currentPrintPos.x <=0)	currentPrintPos.x = 0;
					else currentPrintPos.x = 5175;
				}

				mapMoveValue.y = (mousePos[0].y - g_ptMouse.y);
				currentPrintPos.y += mapMoveValue.y;

				if (currentPrintPos.y <= -30 || currentPrintPos.y >= 460)
				{
					if (currentPrintPos.y <= -30) currentPrintPos.y = -30;
					else currentPrintPos.y = 460;
				}

				menuCameraRectMoveCheck = false;

				//for (int i = 0; i < menuTmpCameraRectVec.size(); i++)
				//{
				//	menuTmpCameraRectVec[i].left -= mapMoveValue.x * 2.7f;
				//	menuTmpCameraRectVec[i].top -= mapMoveValue.y * 2.7f;
				//	menuTmpCameraRectVec[i].right -= mapMoveValue.x * 2.7f;
				//	menuTmpCameraRectVec[i].bottom -= mapMoveValue.y * 2.7f;
				//}
			}
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON))
	{
		//������Ʈ ��ġ
		if (PtInRect(&editorMapPanel, g_ptMouse) && (hButtonCheck == false))
		{
			switch (buttonType)
			{
			case (int)BUTTON_TYPE::TYPE_CAMERA:
			{
				RECT rc = menuCameraMoveYRect;
				// ���� ���� currPrintPos.x�� y�� ������,
				// menuCameraMoveYRect.left, top, right, bottom��ŭ�� �����ش�.
				rc.left += currentPrintPos.x;
				rc.right += currentPrintPos.x;
				rc.top += currentPrintPos.y;
				rc.bottom += currentPrintPos.y;
				
				//RECT tmpFRect = { rc.left, rc.top, rc.right, rc.bottom };

				// --> ���� ���� ��ǥ�� �ȴ�.
				menuCameraRectMoveCheck = true;
				menuCameraRectVec.push_back(rc);
				//menuTmpCameraRectVec.push_back(tmpFRect);

				break;
			}

			case (int)BUTTON_TYPE::TYPE_ENEMY:
				for (int i = 0; i < 3; i++)
				{
					if (PtInRect(&menuEnemyRect[i], g_ptMouse))
					{
						enemyId = i;
						menuEnemyMoveBool = true;
						break;
					}
				}
				break;

			default:


				break;
			}
		}

		///////////////////////////��ư�� Ŭ�� ��
		for (int i = 0; i < 5; i++)
		{
			if (PtInRect(&buttonRect[i], g_ptMouse))
			{
				buttonDown[i] = true;
				buttonTmp = i;

				switch (i)
				{
				case (int)BUTTON_TYPE::TYPE_CAMERA:
					
					buttonType = BUTTON_TYPE::TYPE_CAMERA;
					menuEnemyMoveBool = false;

					break;

				case (int)BUTTON_TYPE::TYPE_ENEMY:

					buttonType = BUTTON_TYPE::TYPE_ENEMY;
					menuCameraMouseMove = false;

					break;

				default:

					buttonType = BUTTON_TYPE::TYPE_NONE;
					break;
				}

				break;
			}
		}

		for (int i = 0; i < 5; i++)
		{
			if (i != buttonTmp)
			{
				buttonDown[i] = false;
			}
		}
		////////////////////////

		//////////////////////// �ش� ��ư Ÿ�Կ��� ������Ʈ�� Ŭ������ ��
		switch (buttonType)
		{
		case (int)BUTTON_TYPE::TYPE_CAMERA:
			if (PtInRect(&menuCameraYRect, g_ptMouse))
			{
				menuCameraMouseMove = true;
			}
			break;

		case (int)BUTTON_TYPE::TYPE_ENEMY:
			for (int i = 0; i < 3; i++)
			{
				if (PtInRect(&menuEnemyRect[i], g_ptMouse))
				{
					enemyId = i;
					menuEnemyMoveBool = true;
					break;
				}
			}
			break;

		default:

			break;
		}
	}


	//��ư�� Ŭ���ϰ� �ش� Rect�� ���콺�� ����ٴϱ� ���ؼ�
	switch (buttonType)
	{
	case (int)BUTTON_TYPE::TYPE_CAMERA:
		if (menuCameraMouseMove == true)
		{
			menuCameraMoveYRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y, 20, 100);
		}
		break;

	case (int)BUTTON_TYPE::TYPE_ENEMY:
		if (menuEnemyMoveBool == true)
		{
			menuEnemyRect[enemyId];
			menuEnemyMoveRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y, 
				menuEnemyRect[enemyId].right - menuEnemyRect[enemyId].left, 
				menuEnemyRect[enemyId].bottom - menuEnemyRect[enemyId].top);
		}
		break;

	default:


		break;
	}

	// �� ��ǥ ���
	// (currentPrintPos.x, currentPrintPos.y) + ( g_ptMouse.x, g_ptMouse.y )

	// Debug �����ֱ�
	if (KeyManager::GetSingleton()->IsOnceKeyDown('P'))
	{
		debugMode = !debugMode;
	}
}

void EditorScene::Render(HDC hdc)
{
	// Panel ( ��ü �г� )
	FillRect(hdc, &panel, hGreyBrush);

	FillRect(hdc, &editorMenuPanel, hWhiteBrush);

	// �������� ��ü �̹��� ���
	stage2MapImg->MapEditorRender(hdc, (WINSIZE_X / 3 + 20), 0, 2.7f, currentPrintPos);

	//ī�޶� ��Ʈ ������ŭ ����
	if (hButtonCheck == false)
	{
		for (int i = 0; i < menuCameraRectVec.size(); i++)
		{
			// currentPrintPos��ǥ�� �������� ���� �ȿ� ������ �簢���� �����ش�.
			//if (CameraRectInYRect(currentPrintPos, menuCameraRectVec[i]) == true)
			//{
			if ( (menuCameraRectMoveCheck == true) && (i == menuCameraRectVec.size() - 1) )
			{
				Rectangle(hdc,
					menuCameraRectVec[i].left - currentPrintPos.x,
					menuCameraRectVec[i].top - currentPrintPos.y,
					menuCameraRectVec[i].right - currentPrintPos.x,
					menuCameraRectVec[i].bottom - currentPrintPos.y);
			}
			else
			{
				Rectangle(hdc,
					menuCameraRectVec[i].left - ( currentPrintPos.x * 2.7f ),
					menuCameraRectVec[i].top - ( currentPrintPos.y * 2.7f ),
					menuCameraRectVec[i].right - ( currentPrintPos.x * 2.7f ),
					menuCameraRectVec[i].bottom - ( currentPrintPos.y * 2.7f) );
			}

			
		}
	}

	// ��� �г� ( �޴� )
	

	if (buttonClickImg)
	{
		for (int i = 0; i < 5; i++)
		{
			buttonClickImg->FrameRender(hdc, buttonRect[i].left + buttonClickImg->GetFrameWidth() / 2,
				buttonRect[i].top + buttonClickImg->GetFrameHeight() / 2, 0, buttonDown[i]);
		}
	}

	//���̺� �ε� ��ư ��Ʈ 
	FillRect(hdc, &saveButtonRect, hBlackBrush);
	FillRect(hdc, &loadButtonRect, hBlackBrush);


	switch (buttonType)
	{
		case BUTTON_TYPE::TYPE_CAMERA:

			Rectangle(hdc, menuCameraYRect.left, menuCameraYRect.top, menuCameraYRect.right, menuCameraYRect.bottom);

			if (menuCameraMouseMove && (hButtonCheck == false))
			{
				Rectangle(hdc, menuCameraMoveYRect.left, menuCameraMoveYRect.top, menuCameraMoveYRect.right, menuCameraMoveYRect.bottom);
			}

			break;

		case BUTTON_TYPE::TYPE_ENEMY:
			for (int i = 0; i < 3; i++)
				Rectangle(hdc, menuEnemyRect[i].left, menuEnemyRect[i].top, menuEnemyRect[i].right, menuEnemyRect[i].bottom);

			if (menuEnemyMoveBool && (hButtonCheck == false))
			{
				Rectangle(hdc, menuEnemyMoveRect.left, menuEnemyMoveRect.top, menuEnemyMoveRect.right, menuEnemyMoveRect.bottom);
			}

			break;

		default:

			break;
	}



	if (debugMode)
	{
		char szText[128];
		sprintf_s(szText, "���콺 ��ġ : [ %d, %d ]", g_ptMouse.x, g_ptMouse.y);
		TextOut(hdc, 50, 30, szText, strlen(szText));
		sprintf_s(szText, "�� ������ ��ġ : [ %d, %d ] ", currentPrintPos.x, currentPrintPos.y);
		TextOut(hdc, 50, 60, szText, strlen(szText));
		sprintf_s(szText, "ī�޶� �� Ƚ�� : [ %d ] ", menuCameraRectVec.size());
		TextOut(hdc, 50, 90, szText, strlen(szText));
		sprintf_s(szText, "mapMoveValue : [ %d, %d ] ", mapMoveValue.x, mapMoveValue.y);
		TextOut(hdc, 50, 120, szText, strlen(szText));
		for (int i = 0; i < menuCameraRectVec.size(); i++)
		{
			sprintf_s(szText, "��Ʈ ��ġ : [ %d, %d, %d, %d ] ", menuCameraRectVec[i].left, menuCameraRectVec[i].top, menuCameraRectVec[i].right, menuCameraRectVec[i].bottom);
			TextOut(hdc, 50, 150 + i * 30, szText, strlen(szText));
		}
	}
}
bool EditorScene::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{

	if (currentPrintPos.x * 2.7f + 450 < cameraYRect.left &&
		currentPrintPos.y * 2.7f < cameraYRect.top &&
		currentPrintPos.x * 2.7f + 450 + GAME_SIZE_X > cameraYRect.right &&
		currentPrintPos.y * 2.7f + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}


EditorScene::EditorScene()
{
}


EditorScene::~EditorScene()
{
}

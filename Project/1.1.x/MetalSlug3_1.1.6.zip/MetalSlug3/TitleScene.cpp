#include "TitleScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT TitleScene::Init()
{
	test_AnimationImage = ImageManager::GetSingleton()->AddImage("Player_Shooting", "Image/Player/Player_Walk_Leg.bmp", 0, 0, 540 * 2, 25 * 2, 12, 1, true, RGB(86,177,222));
	testAni = new Animation();
	testAni->Init(test_AnimationImage->GetWidth(), test_AnimationImage->GetHeight(), test_AnimationImage->GetFrameWidth(), test_AnimationImage->GetFrameHeight());
	testAni->SetPlayFrame(false, true);
	testAni->SetUpdateTime(FPS * 2 / 3);
	testAni->Start();

	return S_OK;
}

void TitleScene::Release()
{
	SAFE_DELETE(testAni);
}

void TitleScene::Update()
{
	//if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	//{
	//	SceneManager::GetSingleton()->ChangeScene("��Ʋ��", "�ε�1");			  
	//}

	testAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void TitleScene::Render(HDC hdc)
{
	test_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, testAni);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}

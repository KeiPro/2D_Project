#include "TitleScene.h"
#include "Image.h"

HRESULT TitleScene::Init()
{
	//titleImage = ImageManager::GetSingleton()->AddImage("���� Ÿ��", "Image/Title.bmp",WINSIZE_X, WINSIZE_Y);

	return S_OK;
}

void TitleScene::Release()
{

}

void TitleScene::Update()
{
	//if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	//{
	//	SceneManager::GetSingleton()->ChangeScene("��Ʋ��", "�ε�1");			  
	//}
}

void TitleScene::Render(HDC hdc)
{
	//titleImage->Render(hdc, 0, 0);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}

﻿#pragma once

#include <Windows.h>
#include <math.h>
#include <map>
#include <vector>
#include <string>

using namespace std;

#include "KeyManager.h"
#include "ImageManager.h"
#include "TimeManager.h"
#include "SoundManager.h"
#include "SceneManager.h"



// enum, struct, .h, #define
enum BOX
{
	BOX_First,
	BOX_Second,
	BOX_End
};

typedef struct tagFPOINT
{
	float x;
	float y;
} FPOINT, *PFPOINT;

typedef struct floatRect
{
	float left;
	float top;
	float right;
	float bottom;
}FRECT;

typedef struct tagArguments
{
	const char* sceneName;
	const char* loadingName;

} ARGUMENT_INFO;

enum PlayerState
{
	Idle,
	Walk,
	Shooting,
	Idle_Jump,
};

#define FPS			30.0f
#define WINSIZE_X	GetSystemMetrics(SM_CXSCREEN)
#define WINSIZE_Y	GetSystemMetrics(SM_CYSCREEN)
#define WINSTART_X	0
#define WINSTART_Y	0
#define GAME_SIZE_X 800
#define GAME_SIZE_Y 600

#define WINSIZE_TILE_MAP_X	GetSystemMetrics(SM_CXSCREEN)
#define WINSIZE_TILE_MAP_Y	GetSystemMetrics(SM_CYSCREEN)

#define PI			3.141592

#define SAFE_DELETE(p)		{ if (p) { delete p; p = NULL; }}
#define SAFE_ARR_DELETE(p)	{ if (p) { delete [] p; p = NULL; }}

#define DEGREE_TO_RADIAN(x)	( x * PI / 180 )
#define RADIAN_TO_DEGREE(x) (int)( x * 180 / PI )

#define IDC_EDITBOX_TEXT 1000
#define IDC_EDITBOX_OK 100
#define IDC_EDITBOX_CANCLE 101

extern HWND g_hWnd;
extern HWND g_hNewWnd;
extern HWND g_hEdit;
extern HINSTANCE g_hInstance;
extern POINT	g_ptMouse;

//extern float	g_wheelMouse;

#include "macroFunction.h"
#include "PixelCollision.h"
#include "Image.h"
#include "Player.h"

void PixelCollision::Init()
{
	currentPrintPosX = 0;
	currentPrintPosY = 0;

	//�ȼ� �����
	pixelBackbuffer = new Image();
	pixelBackbuffer->Init(GAME_SIZE_X, GAME_SIZE_Y);

	pixelBackground = ImageManager::GetSingleton()->FindImage("PixelCollision");
}

void PixelCollision::Update(int currentPrintPosX, int currentPrintPosY)
{
	StretchBlt(pixelBackbuffer->GetMemDC(),
		0, 0,
		GAME_SIZE_X * 2.7f,
		GAME_SIZE_Y * 2.7f,
		pixelBackground->GetMemDC(),
		currentPrintPosX / 2.7f,
		186 + currentPrintPosY / 2.7f,
		GAME_SIZE_X,
		GAME_SIZE_Y,
		SRCCOPY);

	//�ȼ� �浹
	COLORREF color;
	int R, G, B;
	for (int i = player->GetRC().top; i < player->GetRC().bottom; i++)
	{
		color = GetPixel(pixelBackbuffer->GetMemDC(), player->GetPlayerPos().x, i);
		R = GetRValue(color);
		G = GetGValue(color);
		B = GetBValue(color);

		// �ȼ� �浹
		if ((R == 255) && (G == 0) && (B == 255))
		{
			player->SetPlayerPosY(i-10);
			player->SetIsLanding(true);
			player->SetJumpAniCheck(false);
			player->SetG_Acceleration(0);
			player->SetyAxisV(0);
			//player->SetPlayerLegState(PlayerState::Idle);

			break;
		}
		else
		{
			player->SetIsLanding(false);
		}
	}
}

void PixelCollision::Release()
{
	if (pixelBackbuffer)
	{
		pixelBackbuffer->Release();
		SAFE_DELETE(pixelBackbuffer);
	}
}

PixelCollision::PixelCollision()
{
}


PixelCollision::~PixelCollision()
{
}

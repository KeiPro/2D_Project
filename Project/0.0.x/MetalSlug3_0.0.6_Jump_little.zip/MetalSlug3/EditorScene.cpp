#include "EditorScene.h"
#include "Image.h"
#include "ButtonFunction.h"
#include "Button.h"
#include "Player.h"
#include "CameraRect.h"
#include "Camera.h"
#include "PixelCollision.h"

HRESULT EditorScene::Init()
{
	stage2MapImg = ImageManager::GetSingleton()->AddImage("Stage2_Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));
	mapPixelCollision = ImageManager::GetSingleton()->AddImage("PixelCollision", "Image/Background/Stage2_Map_PixelCollision.bmp", 5483, 906);
	buttonClickImg = ImageManager::GetSingleton()->AddImage("CameraButtonImg", "Image/Button/button.bmp", 0.0f, 0.0f, 122, 62, 1, 2);

	color = RGB(255, 255, 255);
	brush = CreateSolidBrush(color);
	pen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));

	player = new Player();
	player->Init(WINSIZE_X - GAME_SIZE_X);

	pixelCollision = new PixelCollision();
	pixelCollision->Init();
	pixelCollision->SetPlayer(player);


	camera = new Camera();
	camera->Init(WINSIZE_X - GAME_SIZE_X);
	camera->SetPlayer(player);

	cameraRect = new CameraRect();
	cameraRect->Init();


	



	panel = { 0, 0, WINSIZE_X, WINSIZE_Y };
	//editorMenuPanel = { 0, 0, WINSIZE_X / 3, WINSIZE_Y };
	//editorMapPanel = {WINSIZE_X / 3, 0, WINSIZE_X, WINSIZE_Y};

	editorMenuPanel = { 0, 0, WINSIZE_X - 800, WINSIZE_Y };
	editorMapPanel = {WINSIZE_X - 800, 0, WINSIZE_X, WINSIZE_Y};

	//�귯�� ����

	/*saveButtonRect = { 0 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 6 - 20), (WINSIZE_Y * 3 / 4) + 40 };
	loadButtonRect = { WINSIZE_X / 6 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 3 - 20), (WINSIZE_Y * 3 / 4) + 40 };*/

	currentPrintPos = {0, 0};

	//g_wheelMouse = 1.0f;
	mouseClickDown = false;

	POINT upFramePoint = { 0, 0 };
	POINT downFramePoint = { 0, 1 };

	//// ��ư
	ButtonsSetPosition();
	
	for (int i = 0; i < 5; i++)
	{
		buttonDown[i] = false;
	}

	editBoxCheck = false;

	//H ��ư�� ������ �ִ����� üũ�� ����
	hButtonCheck = false;

	//�� ��° ��ư�� ���ȴ����� üũ�� ����
	buttonTmp = 0;

	//�޴� ī�޶� ��Ʈ ����
	MenuCameraYRectSet();

	//�޴� ���׹� ��Ʈ ����
	MenuEnemysRect();


	buttonType = BUTTON_TYPE::TYPE_NONE;

	//����� ���
	debugMode = false;

	//CreateWindow(TEXT("new"), TEXT("���ο� â"), , 100, 100, 400, 300, hWnd, (HMENU)0, g_hInst,

	//	NULL);



	//g_hWnd2 = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 50, 50, 20, g_hWnd, (HMENU)IDC_EDITBOX_TEXT, g_hInstance, NULL);

	//ShowWindow(g_hWnd2, SW_SHOW);

	return S_OK;
}

void EditorScene::Release()
{
	if (pixelCollision)
	{
		pixelCollision->Release();
		SAFE_DELETE(pixelCollision);
	}

	if (camera) 
	{
		camera->Release();
		SAFE_DELETE(camera);
	}

	if (cameraRect)
	{
		cameraRect->Release();
		SAFE_DELETE(cameraRect);
	}

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}


	DeleteObject(brush);
	DeleteObject(pen);
}

void EditorScene::Update()
{
	//editorMap�� ���콺���� ����

	if (KeyManager::GetSingleton()->IsStayKeyDown('H'))
	{
		hButtonCheck = true;
	}
	
	if (KeyManager::GetSingleton()->IsOnceKeyUp('H'))
	{
		hButtonCheck = false;
	}

	if (debugMode == true)
	{
		//�� �����Ϳ� ���콺 ��ġ���� ����
		if (PtInRect(&editorMapPanel, g_ptMouse))
		{
			if (hButtonCheck == true)
			{	//hButton�� ������ ������ �� �����͸� �̵���Ų��. ( �ڵ��� )
				if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
				{
					if (mouseClickDown == false)
					{
						mousePos[0] = g_ptMouse;
						mouseClickDown = true;
					}

					//if (mouseClickDown == true)
					//{
					//	mousePos[1] = g_ptMouse;
					//}

					//if (mousePos[1].x != mousePos[2].x && mousePos[1].y != mousePos[2].y)
					//{
					//	currentprintPos.x += (mousePos[2].x - mousePos[1].x) * 0.5f;
					//	currentprintPos.y += (mousePos[2].y - mousePos[1].y) * 0.5f;
					//}

					//mousePos[2] = g_ptMouse;
				}

				if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON))
				{
					mouseClickDown = false;

					// �� ������ ��ġ������ ����Ǳ� ���� ����ó��
					// if (g_ptMouse.x <= 445) g_ptMouse.x = mousePos[0].x;
					mapMoveValue.x = (mousePos[0].x - g_ptMouse.x);
					currentPrintPos.x += mapMoveValue.x;

					//currentPrintPos����ó��.
					if (currentPrintPos.x <= 0 || currentPrintPos.x >= 5175 * 2.7f)
					{
						if (currentPrintPos.x <= 0)	currentPrintPos.x = 0;
						else currentPrintPos.x = 5175 * 2.7f;
					}

					mapMoveValue.y = (mousePos[0].y - g_ptMouse.y);
					currentPrintPos.y += mapMoveValue.y;

					if (currentPrintPos.y <= -30 * 2.7f || currentPrintPos.y >= 460 * 2.7f)
					{
						if (currentPrintPos.y <= -30 * 2.7f) currentPrintPos.y = -30 * 2.7f;
						else currentPrintPos.y = 460 * 2.7f;
					}

					cameraRect->menuCameraRectMoveCheck = false;
				}
			}
		}

		//���콺 ���� ��ư�� ���� �� - ������Ʈ ��ġ, ��ư Ŭ�� ��
		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON))
		{
			//������Ʈ ��ġ 
			if (PtInRect(&editorMapPanel, g_ptMouse) && (hButtonCheck == false))
			{
				switch (buttonType)
				{
				case (int)BUTTON_TYPE::TYPE_CAMERA:
				{
					if ( (cameraRect->menuCameraMouseMove == true) && (editBoxCheck == false))
					{
						cameraRect->menuCameraMouseMove = false;
						//editBoxCheck = true;
						ShowWindow(g_hNewWnd, SW_SHOW);
						VectorInputCameraYRect(); //ī�޶� ��Ʈ ���Ϳ� �ִ� �ڵ�
					}


					break;
				}

				case (int)BUTTON_TYPE::TYPE_ENEMY:
					for (int i = 0; i < 3; i++)
					{
						if (PtInRect(&menuEnemyRect[i], g_ptMouse))
						{
							enemyId = i;
							menuEnemyMoveBool = true;
							break;
						}
					}
					break;

				default:


					break;
				}
			}

			///////////////////////////��ư�� Ŭ�� ��
			for (int i = 0; i < 5; i++)
			{
				if (PtInRect(&buttonRect[i], g_ptMouse))
				{
					buttonDown[i] = true;
					buttonTmp = i;

					switch (i)
					{
					case (int)BUTTON_TYPE::TYPE_CAMERA:

						buttonType = BUTTON_TYPE::TYPE_CAMERA;
						menuEnemyMoveBool = false;

						break;

					case (int)BUTTON_TYPE::TYPE_ENEMY:

						buttonType = BUTTON_TYPE::TYPE_ENEMY;
						cameraRect->menuCameraMouseMove = false;

						break;

					default:

						buttonType = BUTTON_TYPE::TYPE_NONE;
						break;
					}

					break;
				}
			}

			for (int i = 0; i < 5; i++)
			{
				if (i != buttonTmp)
				{
					buttonDown[i] = false;
				}
			}
			////////////////////////

			//////////////////////// �ش� ��ư Ÿ�Կ��� ������Ʈ�� Ŭ������ ��
			switch (buttonType)
			{
			case (int)BUTTON_TYPE::TYPE_CAMERA:
				if (PtInRect(&cameraRect->menuCameraYRect, g_ptMouse))
				{
					cameraRect->menuCameraMouseMove = true;
				}
				break;

			case (int)BUTTON_TYPE::TYPE_ENEMY:
				for (int i = 0; i < 3; i++)
				{
					if (PtInRect(&menuEnemyRect[i], g_ptMouse))
					{
						enemyId = i;
						menuEnemyMoveBool = true;
						break;
					}
				}
				break;

			default:

				break;
			}
		}

		//��ư�� Ŭ���ϰ� �ش� Rect�� ���콺�� ����ٴϱ� ���ؼ�
		switch (buttonType)
		{
		case (int)BUTTON_TYPE::TYPE_CAMERA:
			if (cameraRect->menuCameraMouseMove == true)
			{
				cameraRect->menuCameraMoveYRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y, 20, 100);
			}
			break;

		case (int)BUTTON_TYPE::TYPE_ENEMY:
			if (menuEnemyMoveBool == true)
			{
				menuEnemyRect[enemyId];
				menuEnemyMoveRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y,
					menuEnemyRect[enemyId].right - menuEnemyRect[enemyId].left,
					menuEnemyRect[enemyId].bottom - menuEnemyRect[enemyId].top);
			}
			break;

		default:


			break;
		}
	}

	if (player)
		player->Update();

	if (camera)
		camera->Update();

	currentPrintPos.x += camera->GetCameraSpeed();

	if (KeyManager::GetSingleton()->IsStayKeyDown('K'))
	{
		currentPrintPos.y++;
	}

	pixelCollision->Update(currentPrintPos.x, currentPrintPos.y);
	
	// Debug �����ֱ�
	if (KeyManager::GetSingleton()->IsOnceKeyDown('P'))
	{
		debugMode = !debugMode;
	}
}

void EditorScene::Render(HDC hdc)
{
	// Panel ( ��ü �г� )
	SetColor(RGB(195, 195, 195));
	FillRect(hdc, &panel, brush);

	SetColor(RGB(255,255,255));
	FillRect(hdc, &editorMenuPanel, brush);

	// �������� ��ü �̹��� ���
	stage2MapImg->MapEditorRender(hdc, WINSIZE_X-800, 0, 2.7f, currentPrintPos);

	//BitBlt(hdc, WINSIZE_X - 800, 0, WINSIZE_X, WINSIZE_Y, pixelBackbuffer->GetMemDC(), 0, 0, SRCCOPY);

	//ī�޶� ��Ʈ ������ŭ ����
	if (hButtonCheck == false)
	{
		for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
		{
			if (CameraRectInYRect(currentPrintPos, cameraRect->cameraYRectVec[i]) == true)
			{
				SetColor(RGB(255, 255, 255));
				Rectangle(hdc,
					(WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i].left - currentPrintPos.x,
					cameraRect->cameraYRectVec[i].top - currentPrintPos.y,
					(WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i].right - currentPrintPos.x,
					cameraRect->cameraYRectVec[i].bottom - currentPrintPos.y);
			}
		}
	}


	// ��� �г� ( �޴� )
	if (buttonClickImg)
	{
		for (int i = 0; i < 5; i++)
		{
			buttonClickImg->FrameRender(hdc, buttonRect[i].left + buttonClickImg->GetFrameWidth() / 2,
				buttonRect[i].top + buttonClickImg->GetFrameHeight() / 2, 0, buttonDown[i]);
		}
	}

	//���̺� �ε� ��ư ��Ʈ 
	FillRect(hdc, &saveButtonRect, brush);
	FillRect(hdc, &loadButtonRect, brush);


	switch (buttonType)
	{
		case BUTTON_TYPE::TYPE_CAMERA:

			Rectangle(hdc, cameraRect->menuCameraYRect.left, cameraRect->menuCameraYRect.top, cameraRect->menuCameraYRect.right, cameraRect->menuCameraYRect.bottom);

			if (cameraRect->menuCameraMouseMove && (hButtonCheck == false))
			{
				Rectangle(hdc, cameraRect->menuCameraMoveYRect.left, cameraRect->menuCameraMoveYRect.top, cameraRect->menuCameraMoveYRect.right, cameraRect->menuCameraMoveYRect.bottom);
			}

			break;

		case BUTTON_TYPE::TYPE_ENEMY:
			for (int i = 0; i < 3; i++)
				Rectangle(hdc, menuEnemyRect[i].left, menuEnemyRect[i].top, menuEnemyRect[i].right, menuEnemyRect[i].bottom);

			if (menuEnemyMoveBool && (hButtonCheck == false))
			{
				Rectangle(hdc, menuEnemyMoveRect.left, menuEnemyMoveRect.top, menuEnemyMoveRect.right, menuEnemyMoveRect.bottom);
			}

			break;

		default:

			break;
	}

	if (player)
		player->Render(hdc);


	if (debugMode)
	{
		if (camera)
			camera->Render(hdc);

		char szText[128];
		sprintf_s(szText, "���콺 ��ġ : [ %d, %d ]", g_ptMouse.x, g_ptMouse.y);
		TextOut(hdc, 50, 30, szText, strlen(szText));
		sprintf_s(szText, "�� ������ ��ġ : [ %d, %d ] ", currentPrintPos.x, currentPrintPos.y);
		TextOut(hdc, 50, 60, szText, strlen(szText));
		sprintf_s(szText, "ī�޶� �� Ƚ�� : [ %d ] ", cameraRect->cameraYRectVec.size());
		TextOut(hdc, 50, 90, szText, strlen(szText));
		//sprintf_s(szText, "mapMoveValue : [ %d, %d ] ", mapMoveValue.x, mapMoveValue.y);
		//TextOut(hdc, 50, 120, szText, strlen(szText));	
		sprintf_s(szText, "cameraYRectVec : [ %d ] ", cameraRect->cameraYRectVec.capacity());
		TextOut(hdc, 50, 120, szText, strlen(szText));
		for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
		{
			sprintf_s(szText, "��Ʈ ��ġ : [ %d, %d, %d, %d ] ", (WINSIZE_X - GAME_SIZE_X)  + cameraRect->cameraYRectVec[i].left,
				cameraRect->cameraYRectVec[i].top, (WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i].right, cameraRect->cameraYRectVec[i].bottom);
			TextOut(hdc, 50, 150 + i * 30, szText, strlen(szText));
		}
	}
}

bool EditorScene::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{
	if ( currentPrintPos.x < cameraYRect.left &&
		 currentPrintPos.y < cameraYRect.top &&
		currentPrintPos.x + GAME_SIZE_X> cameraYRect.right &&
		currentPrintPos.y + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}

void EditorScene::ButtonsSetPosition()
{
	buttonRect[0] = GetRectToCenter(WINSIZE_X / 12 - 30, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[2] = GetRectToCenter(WINSIZE_X / 4 + 30, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[3] = GetRectToCenter(WINSIZE_X / 8 - 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[4] = GetRectToCenter(WINSIZE_X * 5 / 24 + 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
}

void EditorScene::MenuCameraYRectSet()
{
	cameraRect->menuCameraYRect = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2, 20, 100);
	cameraRect->menuCameraMoveYRect = cameraRect->menuCameraYRect;
	cameraRect->menuCameraMouseMove = false;
	cameraRect->menuCameraRectMoveCheck = false;
}

void EditorScene::MenuEnemysRect()
{
	menuEnemyRect[0] = GetRectToCenter(WINSIZE_X / 12, WINSIZE_Y / 2, 50, 80);
	menuEnemyRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2, 50, 100);
	menuEnemyRect[2] = GetRectToCenter(WINSIZE_X / 4, WINSIZE_Y / 2, 100, 100);
	menuEnemyMoveRect = menuEnemyRect[0];
	enemyId = -1;
	menuEnemyMoveBool = false;
}

void EditorScene::VectorInputCameraYRect()
{
	RECT rc = cameraRect->menuCameraMoveYRect;
	// ���� ���� currPrintPos.x�� y�� ������,
	// menuCameraMoveYRect.left, top, right, bottom��ŭ�� �����ش�.
	rc.left += currentPrintPos.x;
	rc.right += currentPrintPos.x;
	rc.top += currentPrintPos.y;
	rc.bottom += currentPrintPos.y;

	rc.left -= WINSIZE_X - GAME_SIZE_X;
	rc.right -= WINSIZE_X - GAME_SIZE_X;

	//RECT tmpFRect = { rc.left, rc.top, rc.right, rc.bottom };

	// --> ���� ���� ��ǥ�� �ȴ�.
	cameraRect->menuCameraRectMoveCheck = true;
	cameraRect->cameraYRectVec.push_back(rc);
}


EditorScene::EditorScene()
{
}


EditorScene::~EditorScene()
{
}

#include "BattleScene.h"
#include "Player.h"
#include "Background.h"

HRESULT BattleScene::Init()
{
	player = new Player();
	player->Init();

	background = new Background();
	background->Init();

	return S_OK;
}

void BattleScene::Release()
{
	if (background)
		background->Release();


	if (player)
		player->Release();
}

void BattleScene::Update()
{
	if (background)
		background->Update();

	if (player)
		player->Update();
}

void BattleScene::Render(HDC hdc)
{
	if (background)
		background->Render(hdc);

	if (player)
		player->Render(hdc);
}

BattleScene::BattleScene()
{
}


BattleScene::~BattleScene()
{
}

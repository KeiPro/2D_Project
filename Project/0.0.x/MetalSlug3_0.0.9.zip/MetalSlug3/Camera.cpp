#include "Camera.h"
#include "Player.h"
#include "Image.h"
#include "CameraRect.h"

void Camera::Init(int _addValue, bool _isDebug)
{
	stage2MapImg = ImageManager::GetSingleton()->FindImage("Stage2_Map");
	pixelBackground = ImageManager::GetSingleton()->FindImage("PixelCollision");

	addValue = _addValue;
	isDebug = _isDebug;
	player = nullptr;

	disBaseLineToPlayer = 0;
	speed = 7;
	cameraYMove = false;
	moveValueRate = 0;

	baseLineTop = { GAME_SIZE_X / 3, 0 };
	baseLineBottom = { GAME_SIZE_X / 3, GAME_SIZE_Y };

	color = RGB(255, 0, 0);
	hPen = CreatePen(PS_SOLID, 2, color);
}

void Camera::Update()
{
	if (isDebug == true)
	{
		////y��Ʈ �浹�� �Ͼ�ٸ�
		//if (cameraYMove == true)
		//{
		//	YAxisMove();
		//}
	}
	else
	{
		//y��Ʈ �浹�� �Ͼ�ٸ�
		if (cameraYMove == true)
		{
			YAxisMove();
		}

		if (player->GetPlayerPos().x > baseLineTop.x)
		{
			disBaseLineToPlayer = player->GetPlayerPos().x - baseLineTop.x;
			cameraSpeed = (disBaseLineToPlayer * speed * TimeManager::GetSingleton()->GetDeltaTime());
			//player->SetPlayerPosX((player->GetPlayerPos().x) - (int)cameraSpeed);
		}
		else
		{
			cameraSpeed = 0;
		}
	}
}

void Camera::Render(HDC hdc)
{
	//currPrintPos.y += 3;

	// �������� ��ü �̹��� ���
	stage2MapImg->MapEditorRender(hdc, addValue, 0, 2.7f, currPrintPos);
	
	if (isDebug == true)
	{
		hOldPen = (HPEN)SelectObject(hdc, hPen);
		MoveToEx(hdc, baseLineTop.x + addValue, baseLineTop.y, NULL);
		LineTo(hdc, baseLineBottom.x + addValue, baseLineBottom.y);
		SelectObject(hdc, hOldPen);
		/*StretchBlt(hdc, addValue, 0, GAME_SIZE_X * 2.7f , GAME_SIZE_Y * 2.7f, 
			pixelBackground->GetMemDC(), 
			currPrintPos.x / 2.7f,	186 + currPrintPos.y / 2.7f,
			GAME_SIZE_X, GAME_SIZE_Y, SRCCOPY);*/

		//ī�޶� ��Ʈ ������ŭ ����
		for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
		{
			//ī�޶� ���� �ȿ� ��Ʈ�� �����Ѵٸ� ����Ѵ�.
			if (CameraRectInYRect(currPrintPos, cameraRect->cameraYRectVec[i]->rc) == true)
			{
				SetColor(RGB(255, 255, 255));
				Rectangle(hdc,
					(WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i]->rc.left - currPrintPos.x,
					cameraRect->cameraYRectVec[i]->rc.top - currPrintPos.y,
					(WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i]->rc.right - currPrintPos.x,
					cameraRect->cameraYRectVec[i]->rc.bottom - currPrintPos.y);

				sprintf_s(szText, "%d", cameraRect->cameraYRectVec[i]->value);
				TextOut(hdc, (WINSIZE_X - GAME_SIZE_X) + cameraRect->cameraYRectVec[i]->rc.left - currPrintPos.x,
					(cameraRect->cameraYRectVec[i]->rc.bottom + cameraRect->cameraYRectVec[i]->rc.top) / 2 - currPrintPos.y, szText, strlen(szText));
			}
		}

		//if (player)
		//	player->Render(hdc);
	}
	else
	{
		if (player)
			player->Render(hdc, currPrintPos);
	}
}

HRESULT Camera::Init()
{
	return S_OK;
}

void Camera::Release()
{
	DeleteObject(hPen);
}


Camera::Camera()
{
}


Camera::~Camera()
{
}

bool Camera::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{
	if ( currentPrintPos.x < cameraYRect.left &&
		 currentPrintPos.y < cameraYRect.top &&
		currentPrintPos.x + GAME_SIZE_X> cameraYRect.right &&
		currentPrintPos.y + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}

void Camera::YAxisMove()
{
	if (moveValue.empty())
	{
		cameraYMove = false;
		return;
	}
	else if (moveValue.front() == 0)
	{
		moveValue.pop();
		moveValueRate = 0;
	}
	else
	{
		if (moveValue.front() < 0)
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
			}
			currPrintPos.y -= 150 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate--;
		}
		else
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
			}

			currPrintPos.y += 150 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate++;
		}
	}
}

void Camera::SetIsDebug(bool _isDebug)
{
	isDebug = _isDebug;
	if (isDebug == false)
	{
		player->SetPlayerPos({ (float)currPrintPos.x + 50, (float)currPrintPos.y -50 });
	}
}

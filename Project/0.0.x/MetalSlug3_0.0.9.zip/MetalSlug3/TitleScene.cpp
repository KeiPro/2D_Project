#include "TitleScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT TitleScene::Init()
{
	introImg = ImageManager::GetSingleton()->AddImage("IntroImg", "Image/Intro/Intro_1.bmp", 0, 0, 10400, 600, 13, 1);
	introAnimation = new Animation();
	introAnimation->Init(introImg->GetWidth(), introImg->GetHeight(), introImg->GetFrameWidth(), introImg->GetFrameHeight());
	introAnimation->SetPlayFrame(false, true);
	introAnimation->SetUpdateTime(FPS / 3);
	introAnimation->Start();

	return S_OK;
}

void TitleScene::Release()
{
	if (introAnimation)
		SAFE_DELETE(introAnimation);
}

void TitleScene::Update()
{
	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	{
		//SceneManager::GetSingleton()->ChangeScene("BattleScene");	
		SceneManager::GetSingleton()->ChangeScene("EditorScene");
	}

	if (introAnimation)
	{
		introAnimation->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}

	//testAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	//testAni_leg->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void TitleScene::Render(HDC hdc)
{
	introImg->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, introAnimation);
	//leg_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2 - 10, WINSIZE_Y / 2 + 40, testAni_leg);
	//body_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, testAni);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}

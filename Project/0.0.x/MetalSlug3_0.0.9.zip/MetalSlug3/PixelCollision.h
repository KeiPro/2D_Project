#pragma once
#include "GameNode.h"

class Player;
class Image;
class PixelCollision
{
	Player* player;
	Image*  pixelBackground;
	Image*	pixelBackbuffer;

	POINT currPrintPos;

public:

	void Init();
	void Update(POINT _currPrintPos);
	void Release();
	void Render(HDC hdc);

	void SetPlayer(Player* _player) { player = _player; }
	//void SetCurrentPrintPosX(int _currentX) { currentPrintPosX = _currentX; }
	//void SetCurrentPrintPosY(int _currentY) { currentPrintPosY = _currentY; }
	void SetPixelBackground(Image* _pixelBackground) { pixelBackground = _pixelBackground; }

	PixelCollision();
	~PixelCollision();
};


#pragma once
#include "pch.h"
#include "SingletonBase.h"

//class BrainEnemy;
//class Collision;
class NPCMgr;
class EnemyMgr;
class Image;
class Player;
class DataCollector : public SingletonBase<DataCollector>
{
	Player* player;
	PlayerLookDir playerLookDir;
	int editorAddValue;
	POINT currentPrintPos;

	Image* pixelBackbuffer; //�ȼ� �浹�� ���ؼ�
	EnemyMgr* enemyMgr;
	NPCMgr* npcMgr;
	GunState gunState;

	//UI
	bool isGoUIOn;
	   
	//Collision* collision;

	//vector < BrainEnemy* >* brainEnemyVec;
	//vector < FatEnemy* >* fatEnemyVec;
	//vector < TarEnemy* >* tarEnemyVec;
	
public:

	//void SetBrainVec(vector < BrainEnemy* >* _brainEnemyVec) { brainEnemyVec = _brainEnemyVec; }
	//vector < BrainEnemy* >* GetBrainVec() { return brainEnemyVec; }

	//void SetCollision(Collision* _collision) { collision = _collision; }
	//Collision* GetCollision() { return collision; }

	void SetGunState(GunState _gunState) { gunState = _gunState; }
	GunState GetGunState() { return gunState; }

	void SetIsGoUIOn(bool _isGoUIOn) { isGoUIOn = _isGoUIOn; }
	bool GetIsGoUIOn() { return isGoUIOn; }

	void SetNPCMgr(NPCMgr* _npcMgr) { npcMgr = _npcMgr; }
	NPCMgr* GetNPCMgr() { return npcMgr; }

	void SetEnemyMgr(EnemyMgr* _enemyMgr) { enemyMgr = _enemyMgr; }
	EnemyMgr* GetEnemyMgr() { return enemyMgr; }

	void SetPlayer(Player* _player) { player = _player; }
	Player* GetPlayer() { return player; }

	void SetEditorAddValue(int _addValue) { editorAddValue = _addValue; }
	int GetEditorAddValue() { return editorAddValue; }

	void SetPlayerLookDir(PlayerLookDir _playerLookDir) { playerLookDir = _playerLookDir; }
	PlayerLookDir GetPlayerLookDir() { return playerLookDir; }

	void SetCurrentPrintPos(POINT _currentPrintPos) { currentPrintPos = _currentPrintPos; }
	POINT GetCurrentPrintPos() { return currentPrintPos; }

	void SetPixelBackbuffer(Image* _pixelBackbuffer) { pixelBackbuffer = _pixelBackbuffer; }
	Image* GetPixelBackbuffer() { return pixelBackbuffer; }

	DataCollector();
	~DataCollector();
};


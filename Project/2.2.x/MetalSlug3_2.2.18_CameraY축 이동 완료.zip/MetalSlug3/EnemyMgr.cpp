#include "EnemyMgr.h"

HRESULT EnemyMgr::Init()
{
	FileInput();

	return S_OK;
}

void EnemyMgr::Release()
{
	brainEnemyVec.clear();

	vector<BrainEnemy *>().swap(brainEnemyVec);

	fatEnemyVec.clear();

	vector<FatEnemy *>().swap(fatEnemyVec);
}

void EnemyMgr::Update()
{
	for (auto& it : brainEnemyVec)
	{
		if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
			&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
		{
			it->SetIsAppear(true);
			it->Update();
		}
	}

	for (auto& it : fatEnemyVec)
	{
		if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
			&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
		{
			it->SetIsAppear(true);
			it->Update();
		}
	}
}

void EnemyMgr::Render(HDC hdc)
{
	for (auto& it : brainEnemyVec)
	{
		if (it->GetIsAppear() == true)
		{
			it->Render(hdc);
		}
	}

	for (auto& it : fatEnemyVec)
	{
		if (it->GetIsAppear() == true)
		{
			it->Render(hdc);
		}
	}
}

void EnemyMgr::CreateFatZombie(FPOINT _pos)
{
	FatEnemy* fatEnemy = new FatEnemy();
	fatEnemy->Init(_pos);
	fatEnemyVec.push_back(fatEnemy);
}

void EnemyMgr::FileInput()
{
	FILE* fp = NULL;

	fopen_s(&fp, "Save/Enemy.txt", "r");

	if (fp != NULL)
	{
		int vecCount;
		fscanf_s(fp, "%d", &vecCount);

		brainEnemyVec.reserve(vecCount);

		for (int i = 0; i < vecCount; i++)
		{
			BrainEnemy* brain = new BrainEnemy();
			int posX, posY;
			fscanf_s(fp, "%d", &posX);
			fscanf_s(fp, "%d", &posY);

			brain->Init({ (float)posX, (float)posY });
			brainEnemyVec.push_back(brain);
		}


		fscanf_s(fp, "%d", &vecCount);

		fatEnemyVec.reserve(vecCount);

		for (int i = 0; i < vecCount; i++)
		{
			FatEnemy* fat = new FatEnemy();
			int posX, posY;
			fscanf_s(fp, "%d", &posX);
			fscanf_s(fp, "%d", &posY);

			fat->Init({ (float)posX, (float)posY });
			fatEnemyVec.push_back(fat);
		}

		fclose(fp);
	}
}

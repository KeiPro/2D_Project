#include "BattleScene.h"
#include "Player.h"
#include "Background.h"
#include "PixelCollision.h"
#include "Camera.h"
#include "CameraRect.h"
#include "Image.h"
#include "EnemyMgr.h"
#include "NPCMgr.h"
#include "BattleSceneUI.h"

HRESULT BattleScene::Init()
{
	battleSceneUI = new BattleSceneUI();
	battleSceneUI->Init();

	background = new Background();
	background->Init();

	firstMapImg = ImageManager::GetSingleton()->AddImage("First_Black", "Image/Background/First_Black.bmp", 229, 123, true, RGB(0, 0, 0));
	secondMapImg = ImageManager::GetSingleton()->AddImage("UpMap_Black", "Image/Background/UpMap_Black.bmp", 338, 121, true, RGB(0, 0, 0));

	//collision = new Collision();
	//collision->Init();
	//DataCollector::GetSingleton()->SetCollision(collision);

	//�ȼ� �����
	pixelBackground = ImageManager::GetSingleton()->AddImage("PixelCollision", "Image/Background/Stage2_Map_PixelCollision.bmp", 5483, 906);
	pixelBackbuffer = new Image();
	pixelBackbuffer->Init( GAME_SIZE_X + 200, GAME_SIZE_Y + 200 );

	DataCollector::GetSingleton()->SetPixelBackbuffer(pixelBackbuffer);

	player = new Player();
	DataCollector::GetSingleton()->SetPlayer(player); //�÷��̾� ����
	//collision->SetPlayer(player);
	player->Init();
	
	camera = new Camera();
	camera->Init(DataCollector::GetSingleton()->GetEditorAddValue());
	camera->SetPlayer(player);
	
	cameraRect = new CameraRect();
	cameraRect->Init();

	npcMgr = new NPCMgr();
	enemyMgr = new EnemyMgr();

	DataCollector::GetSingleton()->SetNPCMgr(npcMgr);
	DataCollector::GetSingleton()->SetEnemyMgr(enemyMgr);

	npcMgr->Init();
	enemyMgr->Init();

	currentPrintPos = { 0, 0 };

	//y�� ī�޶� ����
	cameraYMove = false;
	moveValueRate = 0;

	return S_OK;
}

void BattleScene::Release()
{
	if (battleSceneUI)
	{
		battleSceneUI->Release();
		SAFE_DELETE(battleSceneUI);
	}

	if (npcMgr)
	{
		npcMgr->Release();
		SAFE_DELETE(npcMgr);
	}

	if (enemyMgr)
	{
		enemyMgr->Release();
		SAFE_DELETE(enemyMgr);
	}

	if (cameraRect)
	{
		cameraRect->Release();
		SAFE_DELETE(cameraRect);
	}

	if (camera)
	{
		camera->Release();
		SAFE_DELETE(camera);
	}

	if (background)
	{
		background->Release();
		SAFE_DELETE(background);
	}

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}
}

void BattleScene::Update()
{
	if (background)
		background->Update();

	if (player)
		player->Update();

	if (camera)
		camera->Update();

	if (enemyMgr)
		enemyMgr->Update();

	if (npcMgr)
		npcMgr->Update();

	if (cameraYMove == true)
	{
		YAxisMove(); //y�� �̵� ����
	}

	CollisionYRect(DataCollector::GetSingleton()->GetEditorAddValue());

	if (currentPrintPos.x >= 14000)
	{
		currentPrintPos.x = 14000;
	}
	else
	{
		currentPrintPos.x += camera->GetCameraSpeed();
	}
	
	StretchBlt(pixelBackbuffer->GetMemDC(),
	0, 0,
	GAME_SIZE_X * 2.7f,
	GAME_SIZE_Y * 2.7f,
	pixelBackground->GetMemDC(),
	currentPrintPos.x / 2.7f,
	186 + currentPrintPos.y / 2.7f,
	GAME_SIZE_X,
	GAME_SIZE_Y,
	SRCCOPY);

	//������������� �����ǥ�� ���ϱ� ���ؼ� currentPrintPos�� ���� ������ �� �ְ� �������ش�.
	DataCollector::GetSingleton()->SetCurrentPrintPos(currentPrintPos);

	if (battleSceneUI)
	{
		battleSceneUI->Update();
	}
}

void BattleScene::Render(HDC hdc)
{
	if (background)
		background->Render(hdc);

	for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
	{
		Rectangle(hdc, cameraRect->cameraYRectVec[i]->rc.left - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
			cameraRect->cameraYRectVec[i]->rc.top - DataCollector::GetSingleton()->GetCurrentPrintPos().y,
			cameraRect->cameraYRectVec[i]->rc.right - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
			cameraRect->cameraYRectVec[i]->rc.bottom - DataCollector::GetSingleton()->GetCurrentPrintPos().y);
	}

	if (player)
		player->Render(hdc);

	if (enemyMgr)
		enemyMgr->Render(hdc);

	if (npcMgr)
		npcMgr->Render(hdc);

	if (firstMapImg)
		firstMapImg->Render(hdc, 2460 - DataCollector::GetSingleton()->GetCurrentPrintPos().x, 250 - DataCollector::GetSingleton()->GetCurrentPrintPos().y, 2.7f);

	if (secondMapImg)
		secondMapImg->Render(hdc, 3900 - DataCollector::GetSingleton()->GetCurrentPrintPos().x, 150 - DataCollector::GetSingleton()->GetCurrentPrintPos().y, 2.8f, 2.7f );

	if (battleSceneUI)
		battleSceneUI->Render(hdc);
}

void BattleScene::YAxisMove()
{
	if (moveValue.empty())
	{
		cameraYMove = false;
		return;
	}
	else if (moveValue.front() == 0)
	{
		moveValue.pop();
	}
	else
	{
		if (moveValue.front() < 0)
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
			}
			currentPrintPos.y -= 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate--;
		}
		else
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
				moveValueRate = 0;
			}

			currentPrintPos.y += 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate++;
		}
	}
}

void BattleScene::CollisionYRect(int addValue)
{
	for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
	{
		// ���� i��° ��Ʈ�� �浹���°� false�̰� ī�޶� ���� �ȿ� ������
		if ((cameraRect->cameraYRectVec[i]->isCollision == false) && (CameraRectInYRect(currentPrintPos, cameraRect->cameraYRectVec[i]->rc) == true))
		{
			RECT tmpRC = { cameraRect->cameraYRectVec[i]->rc.left - currentPrintPos.x,
			cameraRect->cameraYRectVec[i]->rc.top - currentPrintPos.y,
			cameraRect->cameraYRectVec[i]->rc.right - currentPrintPos.x,
			cameraRect->cameraYRectVec[i]->rc.bottom - currentPrintPos.y };

			//�浹 ó���� �����Ѵ�.
			if (CheckRectCollision(tmpRC, player->GetPlayerCollRC()))
			{
				cout << "�浹!!" << endl;
				cameraRect->cameraYRectVec[i]->isCollision = true;
				moveValue.push(cameraRect->cameraYRectVec[i]->value);
				cameraYMove = true;
				moveValueRate = 0;
			}
		}
	}
}

bool BattleScene::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{
	if (currentPrintPos.x < cameraYRect.left &&
		currentPrintPos.y < cameraYRect.top &&
		currentPrintPos.x + GAME_SIZE_X> cameraYRect.right &&
		currentPrintPos.y + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}

BattleScene::BattleScene()
{
}


BattleScene::~BattleScene()
{
}

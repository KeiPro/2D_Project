#include "Background.h"
#include "Image.h"

HRESULT Background::Init()
{
	mapImg = ImageManager::GetSingleton()->AddImage("stage2Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));
	backImg1 = ImageManager::GetSingleton()->AddImage("BackImg1", "Image/Background/Stage2_Background1.bmp", 417 * 4.0f, 152 * 4.0f);
	moveFrameX = 0;

	return S_OK;
}

void Background::Release()
{
}

void Background::Update()
{


}

void Background::Render(HDC hdc)
{
	if(backImg1)
	{
		backImg1->MoveRender(hdc, (DataCollector::GetSingleton()->GetCurrentPrintPos().x)/2 % backImg1->GetWidth(), 0);
	}

	if (mapImg)
	{
		mapImg->BackgroundMapRender(hdc, 0, 0, DataCollector::GetSingleton()->GetCurrentPrintPos());
	}
}

Background::Background()
{
}


Background::~Background()
{
}

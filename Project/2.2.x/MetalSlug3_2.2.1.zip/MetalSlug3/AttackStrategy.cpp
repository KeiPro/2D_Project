#include "AttackStrategy.h"

void AttackStrategy::Attack(FPOINT pos, float angle, int _heavyMissile)
{
}

void AttackStrategy::InitMissile()
{
}

AttackStrategy::AttackStrategy()
{
}


AttackStrategy::~AttackStrategy()
{
}

#include "EnemyMgr.h"

HRESULT EnemyMgr::Init()
{
	/*brainEnemyVec.reserve(10);
	fatEnemyVec.reserve(10);
	tarEnemyVec.reserve(10);

	for (int i = 0; i < 10; i++)
	{
		BrainEnemy* brain = new BrainEnemy();
		brain->Init({ (float)GAME_SIZE_X + i * 50, 300.0f });

		FatEnemy* fat = new FatEnemy();
		fat->Init();

		TarEnemy* tar = new TarEnemy();
		tar->Init();

		brainEnemyVec.push_back(brain);
		fatEnemyVec.push_back(fat);
		tarEnemyVec.push_back(tar);
	}*/

	brainEnemyVec.reserve(1);

	BrainEnemy* brain = new BrainEnemy();
	brain->Init({ GAME_SIZE_X, 300.0f });
	brainEnemyVec.push_back(brain);

	return S_OK;
}

void EnemyMgr::Release()
{
}

void EnemyMgr::Update()
{
	for (brainEnemyIt = brainEnemyVec.begin(); brainEnemyIt != brainEnemyVec.end(); brainEnemyIt++)
	{
		(*brainEnemyIt)->Update();
	}



}

void EnemyMgr::Render(HDC hdc)
{
	for (auto& it : brainEnemyVec)
	{
		it->Render(hdc);
	}


}

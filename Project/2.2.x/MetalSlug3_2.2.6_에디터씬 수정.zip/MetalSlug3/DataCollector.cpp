#include "DataCollector.h"

DataCollector::DataCollector()
{
}


DataCollector::~DataCollector()
{
}

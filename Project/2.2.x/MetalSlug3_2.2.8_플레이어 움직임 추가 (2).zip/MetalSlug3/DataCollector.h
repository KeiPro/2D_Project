#pragma once
#include "pch.h"
#include "SingletonBase.h"

class Image;
class Player;
class DataCollector : public SingletonBase<DataCollector>
{
	Player* player;
	PlayerLookDir playerLookDir;
	int editorAddValue;
	POINT currentPrintPos;

	Image* pixelBackbuffer; //�ȼ� �浹�� ���ؼ�
	
public:

	void SetPlayer(Player* _player) { player = _player; }
	Player* GetPlayer() { return player; }

	void SetEditorAddValue(int _addValue) { editorAddValue = _addValue; }
	int GetEditorAddValue() { return editorAddValue; }

	void SetPlayerLookDir(PlayerLookDir _playerLookDir) { playerLookDir = _playerLookDir; }
	PlayerLookDir GetPlayerLookDir() { return playerLookDir; }

	void SetCurrentPrintPos(POINT _currentPrintPos) { currentPrintPos = _currentPrintPos; }
	POINT GetCurrentPrintPos() { return currentPrintPos; }

	void SetPixelBackbuffer(Image* _pixelBackbuffer) { pixelBackbuffer = _pixelBackbuffer; }
	Image* GetPixelBackbuffer() { return pixelBackbuffer; }

	DataCollector();
	~DataCollector();
};


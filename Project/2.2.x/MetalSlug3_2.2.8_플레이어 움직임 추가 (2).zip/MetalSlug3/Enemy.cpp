#include "Enemy.h"
#include "Image.h"
#include "Animation.h"
#include "Player.h"
#include "EnemyMissile.h"

HRESULT Enemy::Init()
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
	
}

void Enemy::Render(HDC hdc)
{
	
}

void Enemy::Fire()
{
}

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

HRESULT BrainEnemy::Init(FPOINT _pos)
{
	// ObjectŬ������ Enemy�� this�� �Ѱ��ְ� �Ʒ����� Init�� ���� PixelCollision������ Enemy�� ������ �Ѱ��ش�.
	Object::SetEnemy(this);
	Object::Init(PixelColl_ID::ENEMY);

	missile = new EnemyMissile();
	missile->Init();

	enemyImg.walkImg = ImageManager::GetSingleton()->AddImage("Brain_Walk", "Image/Enemy/Brain/Brain_Walk.bmp", 0, 0, 900, 60, 15, 1 , true, RGB(115, 155, 115));
	enemyImg.attackImg = ImageManager::GetSingleton()->AddImage("Brain_Attack", "Image/Enemy/Brain/Brain_Attack.bmp", 0, 0, 420, 240, 7, 4, true, RGB(115, 155, 115));
	
	enemyAni.walkAni = new Animation();
	enemyAni.walkAni->Init(enemyImg.walkImg->GetWidth(), enemyImg.walkImg->GetHeight(), enemyImg.walkImg->GetFrameWidth(), enemyImg.walkImg->GetFrameHeight());
	enemyAni.walkAni->SetPlayFrame(false, true);
	enemyAni.walkAni->SetUpdateTime(FPS / 6);
	enemyAni.walkAni->Start();

	enemyAni.attackAni = new Animation();
	enemyAni.attackAni->Init(enemyImg.attackImg->GetWidth(), enemyImg.attackImg->GetHeight(), enemyImg.attackImg->GetFrameWidth(), enemyImg.attackImg->GetFrameHeight());
	enemyAni.attackAni->SetPlayFrame(false, false);
	enemyAni.attackAni->SetUpdateTime(FPS / 3);
	enemyAni.attackAni->Start();

	//missileAni = new Animation();
	//missileAni->Init(missileImg->GetWidth(), missileImg->GetHeight(), missileImg->GetFrameWidth(), missileImg->GetFrameHeight());
	//missileAni->SetPlayFrame(false, true);
	//missileAni->SetUpdateTime(FPS / 2);
	//missileAni->Start();

	//missileDisappearAni = new Animation();
	//missileDisappearAni->Init(
	//	missileDisappearImg->GetWidth(),
	//	missileDisappearImg->GetHeight(),
	//	missileDisappearImg->GetFrameWidth(),
	//	missileDisappearImg->GetFrameHeight());
	//missileDisappearAni->SetPlayFrame(false, true);
	//missileDisappearAni->SetUpdateTime(FPS);
	//missileDisappearAni->Start();

	pos = _pos;
	scale = 2.5f;
	speed = 20.0f;
	probeY = 50;
	isLanding = false;
	isAppear = false;
	enemyState = EnemyState::IDLE;
	enemyLookDir = EnemyLookDir::LEFT;

	//��� ��ǥ
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	pixelRect = GetRectToCenter(pos.x, pos.y + 40, 100, 60);

	return S_OK;
}

void BrainEnemy::Release()
{
	if (missile)
	{
		missile->Release();
		SAFE_DELETE(missile);
	}

	if (enemyAni.walkAni)
		SAFE_DELETE(enemyAni.walkAni);

	if (enemyAni.attackAni)
		SAFE_DELETE(enemyAni.attackAni);

	Object::Release();
}

void BrainEnemy::Update()
{
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 50, probeY, probeY * 1.5f);

	//if (missile->GetIsFire() == false)
	//{
	//	
	//	//cout << missile->GetPos().x << ", " << missile->GetPos().y << endl;
	//}

	if (isLanding == false && isAppear)
	{
		pos.y += 10.0f;
	}

	// ���ʹ� ���¸� �������ִ� �ڵ�
	EnemyStateUpdate();

	// ���ʹ� ������
	EnemyMovement();

	if (missile && missile->GetIsFire() == true)
	{
		missile->Update();
	}
	
	Object::Update();
}

void BrainEnemy::Render(HDC hdc)
{
	if (missile && missile->GetIsFire() == true)
	{
		missile->Render(hdc);
	}

	switch (enemyState)
	{
	case EnemyState::IDLE:


		break;

	case EnemyState::WALK:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.walkImg)
				enemyImg.walkImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.walkAni, scale);
		}
		else
		{
			if (enemyImg.walkImg)
				enemyImg.walkImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.walkAni, scale);
		}

		break;

	case EnemyState::ATTACK:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.attackImg)
				enemyImg.attackImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.attackAni, scale);
		}
		else
		{
			if (enemyImg.attackImg)
				enemyImg.attackImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.attackAni, scale);
		}

		break;

	case EnemyState::DIE:



		break;

	default:
		break;
	}
	
	//�ȼ� �浹 ��Ʈ
	//Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);

	/*if(missileImg)
		missileImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, missileAni, scale);*/

	//if(missileDisappearImg)
	//	missileDisappearImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, missileDisappearAni, scale);
}

void BrainEnemy::Fire()
{
	if (enemyLookDir == EnemyLookDir::LEFT)
	{
		missile->SetAngle(135.0f);
		missile->SetPos({ pos.x - 50, pos.y - 50 });
	
		int tmp = relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x;
		if (tmp >= 200)
			tmp = 200;
		else if (tmp < 30)
			tmp = 30;

		((EnemyMissile *)missile)->SetX_Speed((tmp) * 3 / 4);
		
		((EnemyMissile *)missile)->SetY_Speed(200);
	}
	else
	{
		missile->SetAngle(45.0f);
		missile->SetPos({ pos.x + 40, pos.y - 50 });

		int tmp = abs(relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x);
		if (tmp >= 200)
			tmp = 200;
		else if (tmp < 30)
			tmp = 30;

		((EnemyMissile *)missile)->SetX_Speed(tmp * 3 / 4);
		((EnemyMissile *)missile)->SetY_Speed(200);
	}

	((EnemyMissile*)missile)->GetMissileAni()->Start();
	missile->SetIsFire(true);
}

void BrainEnemy::EnemyStateUpdate()
{
	if (isLanding == true) //���� ������ Player�� ���� �Ѿƿ´�.
	{
		//���� ����
		if (enemyState != EnemyState::ATTACK)
		{
			// �ٶ󺸴� ������ �����ϴ� �ڵ�
			if (relativePos.x > DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x)
			{
				enemyLookDir = EnemyLookDir::LEFT;
			}
			else
			{
				enemyLookDir = EnemyLookDir::RIGHT;
			}
		}

		if ( abs(relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x) < 200 )
		{
			if (enemyState != EnemyState::ATTACK)
			{
				enemyAni.attackAni->Start();
				enemyState = EnemyState::ATTACK;
			}
			
		}
		else
		{
			if (enemyState != EnemyState::ATTACK)
			{
				enemyState = EnemyState::WALK;
			}
		}
	}
}

void BrainEnemy::EnemyMovement()
{
	switch (enemyState)
	{
	case EnemyState::IDLE:

		break;

	case EnemyState::WALK:

		if (enemyAni.walkAni)
			enemyAni.walkAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

		if (enemyLookDir == EnemyLookDir::LEFT)
			pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
		else
			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();

		break;

	case EnemyState::ATTACK:

		if (enemyAni.attackAni)
			enemyAni.attackAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

		if (enemyAni.attackAni->GetNowPlayIdx() == 10)
		{
			Fire();
		}

		if (enemyAni.attackAni->GetNowPlayIdx() == enemyAni.attackAni->GetFrameCount() - 1)
		{
			enemyState = EnemyState::WALK;
		}

		break;

	case EnemyState::DIE:



		break;

	default:
		break;
	}
}

BrainEnemy::BrainEnemy()
{
}

BrainEnemy::~BrainEnemy()
{
}

HRESULT FatEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Fat", "Image/Enemy/Fat/Fat.bmp", 47, 56, true, RGB(134, 44, 118));
	pos = { 650 , 100 };


	return S_OK;
}

void FatEnemy::Release()
{
}

void FatEnemy::Update()
{
}

void FatEnemy::Render(HDC hdc)
{
}

void FatEnemy::Fire()
{
}

FatEnemy::FatEnemy()
{
}

FatEnemy::~FatEnemy()
{
}

HRESULT TarEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Tar", "Image/Enemy/Tar/Tar.bmp", 42, 51, true, RGB(87, 111, 183));
	pos = { 700 , 100 };


	return S_OK;
}

void TarEnemy::Release()
{
}

void TarEnemy::Update()
{
}

void TarEnemy::Render(HDC hdc)
{
}

void TarEnemy::Fire()
{
}

TarEnemy::TarEnemy()
{
}

TarEnemy::~TarEnemy()
{
}

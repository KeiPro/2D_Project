#include "Collision.h"

HRESULT Collision::Init(MissileType _missileType)
{
	missileType = _missileType;



	return S_OK;
}

void Collision::Release()
{
}

void Collision::Update()
{
}

void Collision::Render(HDC hdc)
{
}

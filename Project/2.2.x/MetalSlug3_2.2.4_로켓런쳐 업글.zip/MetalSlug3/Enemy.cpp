#include "Enemy.h"
#include "Image.h"
#include "Animation.h"

HRESULT Enemy::Init()
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
	
}

void Enemy::Render(HDC hdc)
{
	
}

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

HRESULT BrainEnemy::Init(FPOINT _pos)
{
	enemyWalkImg = ImageManager::GetSingleton()->AddImage("Brain", "Image/Enemy/Brain/Brain_Walk.bmp", 900, 54, true, RGB(115, 155, 115));
	
	walkAni = new Animation();
	walkAni->Init(enemyWalkImg->GetWidth(), enemyWalkImg->GetHeight(), enemyWalkImg->GetFrameWidth(), enemyWalkImg->GetFrameHeight());
	walkAni->SetPlayFrame(false, true);
	walkAni->SetUpdateTime(FPS / 3);
	walkAni->Start();

	pos = _pos;
	scale = 2.3f;
	speed = 500.0f;
	probeY = 50;

	//��� ��ǥ
	relativePos = { 0, 0 };

	pixelRect = GetRectToCenter(pos.x, pos.y + 40, 100, 60);

	return S_OK;
}

void BrainEnemy::Release()
{
	if (walkAni)
		SAFE_DELETE(walkAni);
}

void BrainEnemy::Update()
{
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y, probeY, probeY * 2);;



	if (walkAni)
		walkAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void BrainEnemy::Render(HDC hdc)
{
	//�ȼ� �浹 ��Ʈ
	Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);

	if (enemyWalkImg)
		enemyWalkImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, walkAni, scale);
}

BrainEnemy::BrainEnemy()
{
}

BrainEnemy::~BrainEnemy()
{
}

HRESULT FatEnemy::Init()
{
	enemyWalkImg = ImageManager::GetSingleton()->AddImage("Fat", "Image/Enemy/Fat/Fat.bmp", 47, 56, true, RGB(134, 44, 118));
	pos = { 650 , 100 };


	return S_OK;
}

void FatEnemy::Release()
{
}

void FatEnemy::Update()
{
}

void FatEnemy::Render(HDC hdc)
{
}

FatEnemy::FatEnemy()
{
}

FatEnemy::~FatEnemy()
{
}

HRESULT TarEnemy::Init()
{
	enemyWalkImg = ImageManager::GetSingleton()->AddImage("Tar", "Image/Enemy/Tar/Tar.bmp", 42, 51, true, RGB(87, 111, 183));
	pos = { 700 , 100 };


	return S_OK;
}

void TarEnemy::Release()
{
}

void TarEnemy::Update()
{
}

void TarEnemy::Render(HDC hdc)
{
}

TarEnemy::TarEnemy()
{
}

TarEnemy::~TarEnemy()
{
}

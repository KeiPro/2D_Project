#include "BattleScene.h"
#include "Player.h"
#include "Background.h"
#include "PixelCollision.h"
#include "Camera.h"
#include "CameraRect.h"

HRESULT BattleScene::Init()
{
	player = new Player();
	player->Init();
	DataCollector::GetSingleton()->SetPlayer(player); //�÷��̾� ����

	background = new Background();
	background->Init();

	pixelCollision = new PixelCollision();
	pixelCollision->Init();
	pixelCollision->SetPlayer(player);

	camera = new Camera();
	camera->Init(DataCollector::GetSingleton()->GetEditorAddValue());
	camera->SetPlayer(player);
	
	cameraRect = new CameraRect();
	cameraRect->Init();

	currentPrintPos = { 0, 0 };

	//y�� ī�޶� ����
	cameraYMove = false;
	moveValueRate = 0;

	return S_OK;
}

void BattleScene::Release()
{
	if (cameraRect)
	{
		cameraRect->Release();
		SAFE_DELETE(cameraRect);
	}

	if (camera)
	{
		camera->Release();
		SAFE_DELETE(camera);
	}

	if (pixelCollision)
	{
		pixelCollision->Release();
		SAFE_DELETE(pixelCollision);
	}

	if (background)
	{
		background->Release();
		SAFE_DELETE(background);
	}

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}
}

void BattleScene::Update()
{
	if (background)
		background->Update();

	if (player)
		player->Update();

	if (camera)
		camera->Update();

	if (cameraYMove == true)
	{
		YAxisMove(); //y�� �̵� ����
	}

	CollisionYRect(DataCollector::GetSingleton()->GetEditorAddValue());

	if (currentPrintPos.x >= 14000)
	{
		currentPrintPos.x = 14000;
	}
	else
	{
		currentPrintPos.x += camera->GetCameraSpeed();
	}

	pixelCollision->Update(currentPrintPos.x, currentPrintPos.y);

	//������������� �����ǥ�� ���ϱ� ���ؼ� currentPrintPos�� ���� ������ �� �ְ� �������ش�.
	DataCollector::GetSingleton()->SetCurrentPrintPos(currentPrintPos);
}

void BattleScene::Render(HDC hdc)
{
	if (background)
		background->Render(hdc);

	//if (pixelCollision)
	//	pixelCollision->Render(hdc);

	if (player)
		player->Render(hdc);
}

void BattleScene::YAxisMove()
{
	if (moveValue.empty())
	{
		cameraYMove = false;
		return;
	}
	else if (moveValue.front() == 0)
	{
		moveValue.pop();
	}
	else
	{
		if (moveValue.front() < 0)
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
			}
			currentPrintPos.y -= 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate--;
		}
		else
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
				moveValueRate = 0;
			}

			currentPrintPos.y += 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate++;
		}
	}
}

void BattleScene::CollisionYRect(int addValue)
{
	for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
	{
		// ���� i��° ��Ʈ�� �浹���°� false�̰� ī�޶� ���� �ȿ� ������
		if ((cameraRect->cameraYRectVec[i]->isCollision == false) && (CameraRectInYRect(currentPrintPos, cameraRect->cameraYRectVec[i]->rc) == true))
		{
			RECT tmpRC = { cameraRect->cameraYRectVec[i]->rc.left,
			cameraRect->cameraYRectVec[i]->rc.top,
			cameraRect->cameraYRectVec[i]->rc.right,
			cameraRect->cameraYRectVec[i]->rc.bottom };

			//�浹 ó���� �����Ѵ�.
			if (CheckRectCollision(tmpRC, player->GetPlayerCollRC()))
			{
				cameraRect->cameraYRectVec[i]->isCollision = true;
				moveValue.push(cameraRect->cameraYRectVec[i]->value);
				cameraYMove = true;
				moveValueRate = 0;
				//currentPrintPos.y += cameraRect->cameraYRectVec[i]->value;
			}
		}
	}
}

bool BattleScene::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{
	if (currentPrintPos.x < cameraYRect.left &&
		currentPrintPos.y < cameraYRect.top &&
		currentPrintPos.x + GAME_SIZE_X> cameraYRect.right &&
		currentPrintPos.y + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}

BattleScene::BattleScene()
{
}


BattleScene::~BattleScene()
{
}

#include "EnemyMissile.h"
#include "Animation.h"
#include "Image.h"
#include "PixelCollision.h"


HRESULT EnemyMissile::Init()
{
	Object::SetMissile(this);
	Object::Init(PixelColl_ID::BULLET);

	//�Ѿ� �̹��� ����.
	missileImg = ImageManager::GetSingleton()->AddImage("E_DefaultMissile", "Image/Enemy/Brain/Missile.bmp", 0, 0, 520, 40, 13, 1, true, RGB(115, 155, 115));
	missileDisappearImg = ImageManager::GetSingleton()->AddImage("E_MissileDisappear", "Image/Enemy/Brain/Missile_Disappear.bmp", 0, 0, 1140, 60, 19, 1, true, RGB(115, 155, 115));

	missileAni = new Animation();
	missileAni->Init(missileImg->GetWidth(), missileImg->GetHeight(), missileImg->GetFrameWidth(), missileImg->GetFrameHeight());
	missileAni->SetPlayFrame(false, false);
	missileAni->SetUpdateTime(FPS / 4);
	missileAni->Start();

	missileDisappearAni = new Animation();
	missileDisappearAni->Init(
		missileDisappearImg->GetWidth(),
		missileDisappearImg->GetHeight(),
		missileDisappearImg->GetFrameWidth(),
		missileDisappearImg->GetFrameHeight()
	);
	missileDisappearAni->SetPlayFrame(false, false);
	missileDisappearAni->SetUpdateTime(FPS);
	missileDisappearAni->Start();

	pos = { 0, 0 };
	relativePos = { 0, 0 };
	speed = 50.0f;
	xSpeed = speed;
	ySpeed = speed;
	angle = 0.0f;
	damage = 1;
	rc = {0, 0, 0, 0};
	isFire = false;
	isCollision = false;

	return S_OK;
}

void EnemyMissile::Release()
{
	if (missileAni)
		SAFE_DELETE(missileAni);

	if (missileDisappearAni)
		SAFE_DELETE(missileDisappearAni);

	Object::Release();
}

void EnemyMissile::Update()
{
	if (isFire == true)
	{
		relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

		if (isCollision)
		{
			if (missileDisappearAni->GetNowPlayIdx() >= missileDisappearAni->GetFrameCount() - 1)
			{
				isCollision = false;
				isFire = false;
				missileDisappearAni->Start();
			}
			missileDisappearAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}
		else
		{
			pos.x += xSpeed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
			pos.y -= ySpeed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
			ySpeed -= 15;
			missileAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		rc = GetRectToCenter(relativePos.x, relativePos.y, 50, 50);
	}

	Object::Update();
}

void EnemyMissile::Render(HDC hdc)
{
	if (isFire)
	{
		//Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

		if (isCollision)
		{
			if (missileDisappearImg)
			{
				if (angle == 135.0f)
					missileDisappearImg->AnimationRender(hdc, relativePos.x, relativePos.y - 65, missileDisappearAni, 2.5f);
				else
					missileDisappearImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y - 65 , missileDisappearAni, 2.5f);
			}
		}
		else
		{
			if (missileImg)
			{
				if(angle == 135.0f)
					missileImg->AnimationRender(hdc, relativePos.x, relativePos.y, missileAni, 2.5f);
				else
					missileImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y, missileAni, 2.5f);
			}
		}
	}
}

EnemyMissile::EnemyMissile()
{
}


EnemyMissile::~EnemyMissile()
{
}

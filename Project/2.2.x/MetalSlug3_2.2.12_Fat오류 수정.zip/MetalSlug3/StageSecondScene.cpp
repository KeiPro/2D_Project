#include "StageSecondScene.h"

HRESULT StageSecondScene::Init()
{
	return S_OK;
}

void StageSecondScene::Release()
{
}

void StageSecondScene::Update()
{
}

void StageSecondScene::Render(HDC hdc)
{
}

StageSecondScene::StageSecondScene()
{
}


StageSecondScene::~StageSecondScene()
{
}

#include "Object.h"
#include "PixelCollision.h"

HRESULT Object::Init(PixelColl_ID _pixelCollId)
{
	pixelCollision = new PixelCollision();
	pixelCollId = _pixelCollId;
	pixelCollision->SetEnemy(enemy);
	pixelCollision->SetMissile(missile);
	pixelCollision->Init(pixelCollId);
	
	return S_OK;
}

void Object::Release()
{
	if(pixelCollision)
		pixelCollision->Release();
}

void Object::Update()
{
	if (pixelCollision)
		pixelCollision->Update();
}

void Object::Render(HDC hdc)
{
}

Object::Object()
{
}


Object::~Object()
{
}

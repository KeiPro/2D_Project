#include "GoUI.h"
#include "Image.h"
#include "Animation.h"

HRESULT GoUI::Init()
{
	image = ImageManager::GetSingleton()->AddImage("GoUI", "Image/UI/GO.bmp", 0, 0, 480, 31, 15, 1, true, RGB(0, 248, 0));
	goAni = new Animation();
	goAni->Init(image->GetWidth(), image->GetHeight(), image->GetFrameWidth(), image->GetFrameHeight());
	goAni->SetPlayFrame(false, true);
	goAni->SetUpdateTime(FPS * 0.7f);
	goAni->Start();

	pos = { (long)(GAME_SIZE_X - image->GetFrameWidth() * 2.5f), (long)(GAME_SIZE_Y / 2 - image->GetFrameHeight()) };

	return S_OK;
}

void GoUI::Release()
{
	if (goAni)
		SAFE_DELETE(goAni);
}

void GoUI::Update()
{
	if (goAni)
		goAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void GoUI::Render(HDC hdc)
{
	if (image)
		image->AnimationRender(hdc, pos.x, pos.y, goAni, 2.5f);
}

GoUI::GoUI()
{
}


GoUI::~GoUI()
{
}

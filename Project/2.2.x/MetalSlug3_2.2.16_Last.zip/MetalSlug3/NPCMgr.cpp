#include "NPCMgr.h"
#include "NPC.h"
#include "EnemyMgr.h"

HRESULT NPCMgr::Init()
{
	FileInput();

	enemyMgr = DataCollector::GetSingleton()->GetEnemyMgr();

	return S_OK;
}

void NPCMgr::Release()
{
	fatHumanVec.clear();
	vector<Fat_Human *>().swap(fatHumanVec);
}

void NPCMgr::Update()
{
	for (fatHumanIt = fatHumanVec.begin(); fatHumanIt != fatHumanVec.end(); fatHumanIt++)
	{
		if ((*fatHumanIt)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
			&& (*fatHumanIt)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
		{
			(*fatHumanIt)->SetIsAppear(true);
			(*fatHumanIt)->Update();

			if ((*fatHumanIt)->GetIsZombie() == true && (*fatHumanIt)->GetIsZombieCreating() == false)
			{
				enemyMgr->CreateFatZombie((*fatHumanIt)->GetPos());
				(*fatHumanIt)->SetIsZombieCreating(true);
			}

			if ((*fatHumanIt)->GetErasingData() == true && (*fatHumanIt)->GetIsZombieCreating() == true)
			{
				fatHumanIt = fatHumanVec.erase(fatHumanIt);

				if (fatHumanIt == fatHumanVec.end())
					break;
			}
		}
	}
}

void NPCMgr::Render(HDC hdc)
{
	for (auto& it : fatHumanVec)
	{
		if (it->GetIsAppear() == true)
		{
			it->Render(hdc);
		}
	}
}

void NPCMgr::FileInput()
{
	FILE* fp = NULL;

	fopen_s(&fp, "Save/NPC.txt", "r");

	if (fp != NULL)
	{
		int vecCount;
		fscanf_s(fp, "%d", &vecCount);

		fatHumanVec.reserve(vecCount);

		for (int i = 0; i < vecCount; i++)
		{
			Fat_Human* fatHuman = new Fat_Human();
			int posX, posY;
			fscanf_s(fp, "%d", &posX);
			fscanf_s(fp, "%d", &posY);

			fatHuman->Init({ (float)posX, (float)posY });
			fatHumanVec.push_back(fatHuman);
		}

		fclose(fp);
	}
}

NPCMgr::NPCMgr()
{
}


NPCMgr::~NPCMgr()
{
}

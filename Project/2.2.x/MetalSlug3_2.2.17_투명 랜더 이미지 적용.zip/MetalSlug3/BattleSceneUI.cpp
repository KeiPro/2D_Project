#include "BattleSceneUI.h"
#include "GoUI.h"
#include "UI_MissileType.h"
#include "UI_Timer.h"


HRESULT BattleSceneUI::Init()
{
	goUI = new GoUI();
	goUI->Init();

	uiMissileType = new UI_MissileType();
	uiMissileType->Init();

	uiTimer = new UI_Timer();
	uiTimer->Init();

	return S_OK;
}

void BattleSceneUI::Release()
{
	if (goUI)
	{
		goUI->Release();
		SAFE_DELETE(goUI);
	}
}

void BattleSceneUI::Update()
{
	if (goUI && DataCollector::GetSingleton()->GetIsGoUIOn() == true)
	{
		goUI->Update();
	}

	if (uiMissileType)
		uiMissileType->Update();

	if (uiTimer)
		uiTimer->Update();
}

void BattleSceneUI::Render(HDC hdc)
{
	if (goUI && DataCollector::GetSingleton()->GetIsGoUIOn() == true)
	{
		goUI->Render(hdc);
	}

	if (uiMissileType)
		uiMissileType->Render(hdc);

	if (uiTimer)
		uiTimer->Render(hdc);
}

BattleSceneUI::BattleSceneUI()
{
}


BattleSceneUI::~BattleSceneUI()
{
}

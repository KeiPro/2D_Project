#include "Enemy.h"
#include "Image.h"
#include "Animation.h"

HRESULT Enemy::Init()
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
	
}

void Enemy::Render(HDC hdc)
{
	
}

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

HRESULT BrainEnemy::Init(FPOINT _pos)
{
	// ObjectŬ������ Enemy�� this�� �Ѱ��ְ� �Ʒ����� Init�� ���� PixelCollision������ Enemy�� ������ �Ѱ��ش�.
	SetEnemy(this);
	Object::Init(PixelColl_ID::ENEMY);

	enemyImg.walkImg = ImageManager::GetSingleton()->AddImage("Brain_Walk", "Image/Enemy/Brain/Brain_Walk.bmp", 0, 0, 900, 60, 15, 1 , true, RGB(115, 155, 115));
	enemyImg.attackImg = ImageManager::GetSingleton()->AddImage("Brain_Attack", "Image/Enemy/Brain/Brain_Attack.bmp", 0, 0, 420, 300, 7, 5, true, RGB(115, 155, 115));
	missileImg = ImageManager::GetSingleton()->AddImage("EnemyDefaultMissile", "Image/Enemy/Brain/Missile.bmp", 0, 0, 520, 40, 13, 1, true, RGB(115, 155, 115));


	enemyAni.walkAni = new Animation();
	enemyAni.walkAni->Init(enemyImg.walkImg->GetWidth(), enemyImg.walkImg->GetHeight(), enemyImg.walkImg->GetFrameWidth(), enemyImg.walkImg->GetFrameHeight());
	enemyAni.walkAni->SetPlayFrame(false, true);
	enemyAni.walkAni->SetUpdateTime(FPS / 6);
	enemyAni.walkAni->Start();

	enemyAni.attackAni = new Animation();
	enemyAni.attackAni->Init(enemyImg.attackImg->GetWidth(), enemyImg.attackImg->GetHeight(), enemyImg.attackImg->GetFrameWidth(), enemyImg.attackImg->GetFrameHeight());
	enemyAni.attackAni->SetPlayFrame(false, true);
	enemyAni.attackAni->SetUpdateTime(FPS / 3);
	enemyAni.attackAni->Start();

	missileAni = new Animation();
	missileAni->Init(missileImg->GetWidth(), missileImg->GetHeight(), missileImg->GetFrameWidth(), missileImg->GetFrameHeight());
	missileAni->SetPlayFrame(false, true);
	missileAni->SetUpdateTime(FPS / 2);
	missileAni->Start();



	pos = _pos;
	scale = 2.5f;
	speed = 500.0f;
	probeY = 50;
	isLanding = false;

	//��� ��ǥ
	relativePos = { 0, 0 };

	pixelRect = GetRectToCenter(pos.x, pos.y + 40, 100, 60);

	return S_OK;
}

void BrainEnemy::Release()
{


	if (enemyAni.walkAni)
		SAFE_DELETE(enemyAni.walkAni);

	if (enemyAni.attackAni)
		SAFE_DELETE(enemyAni.attackAni);

	Object::Release();
}

void BrainEnemy::Update()
{
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 50, probeY, probeY * 1.5f);

	if (isLanding == false)
	{
		pos.y += 10.0f;
	}

	//if (enemyAni.walkAni)
	//	enemyAni.walkAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

	//if (enemyAni.attackAni)
	//	enemyAni.attackAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

	if (missileAni)
		missileAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

	Object::Update();
}

void BrainEnemy::Render(HDC hdc)
{
	//�ȼ� �浹 ��Ʈ
	Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);

	/*if (enemyImg.walkImg)
		enemyImg.walkImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.walkAni, scale);*/

	/*if (enemyImg.attackImg)
		enemyImg.attackImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.attackAni, scale);*/

	if(missileImg)
		missileImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, missileAni, scale);
}

BrainEnemy::BrainEnemy()
{
}

BrainEnemy::~BrainEnemy()
{
}

HRESULT FatEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Fat", "Image/Enemy/Fat/Fat.bmp", 47, 56, true, RGB(134, 44, 118));
	pos = { 650 , 100 };


	return S_OK;
}

void FatEnemy::Release()
{
}

void FatEnemy::Update()
{
}

void FatEnemy::Render(HDC hdc)
{
}

FatEnemy::FatEnemy()
{
}

FatEnemy::~FatEnemy()
{
}

HRESULT TarEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Tar", "Image/Enemy/Tar/Tar.bmp", 42, 51, true, RGB(87, 111, 183));
	pos = { 700 , 100 };


	return S_OK;
}

void TarEnemy::Release()
{
}

void TarEnemy::Update()
{
}

void TarEnemy::Render(HDC hdc)
{
}

TarEnemy::TarEnemy()
{
}

TarEnemy::~TarEnemy()
{
}

#include "Enemy.h"
#include "Image.h"
#include "Animation.h"
#include "Player.h"
#include "EnemyMissile.h"

HRESULT Enemy::Init()
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
	
}

void Enemy::Render(HDC hdc)
{
	
}

void Enemy::Fire()
{
}


Enemy::Enemy()
{
}

Enemy::~Enemy()
{
}

HRESULT BrainEnemy::Init(FPOINT _pos)
{
	// ObjectŬ������ Enemy�� this�� �Ѱ��ְ� �Ʒ����� Init�� ���� PixelCollision������ Enemy�� ������ �Ѱ��ش�.
	Object::SetEnemy(this);
	Object::Init(PixelColl_ID::ENEMY);

	missile = new EnemyMissile();
	missile->Init();

	enemyImg.walkImg = ImageManager::GetSingleton()->AddImage("Brain_Walk", "Image/Enemy/Brain/Brain_Walk.bmp", 0, 0, 900, 60, 15, 1 , true, RGB(115, 155, 115));
	enemyImg.attackImg = ImageManager::GetSingleton()->AddImage("Brain_Attack", "Image/Enemy/Brain/Brain_Attack.bmp", 0, 0, 420, 240, 7, 4, true, RGB(115, 155, 115));
	enemyImg.dieImg = ImageManager::GetSingleton()->AddImage("Enemy_Default_Die", "Image/Enemy/Brain/DefaultDie.bmp", 0, 0, 1800, 100, 15, 1, true, RGB(87, 111, 183));
	enemyImg.flameDieImg = ImageManager::GetSingleton()->AddImage("Brain_Flame_Die", "Image/Enemy/Brain/Brain_Flame_Die.bmp", 0, 0, 640, 450, 8, 5, true, RGB(115,155,115));

	damagingImg[0] = ImageManager::GetSingleton()->AddImage("E_Damaging1", "Image/Enemy/Damaging/damaging_1.bmp", 0, 0, 480, 40, 8, 1, true, RGB(115, 155, 115));
	damagingImg[1] = ImageManager::GetSingleton()->AddImage("E_Damaging2", "Image/Enemy/Damaging/damaging_2.bmp", 0, 0, 480, 50, 8, 1, true, RGB(115, 155, 115));
	damagingImg[2] = ImageManager::GetSingleton()->AddImage("E_Damaging3", "Image/Enemy/Damaging/damaging_3.bmp", 0, 0, 600, 40, 10, 1, true, RGB(115, 155, 115));

	for (int i = 0; i < 3; i++)
	{
		damagingAni[i] = new Animation();
		damagingAni[i]->Init(damagingImg[i]->GetWidth(), damagingImg[i]->GetHeight(), damagingImg[i]->GetFrameWidth(), damagingImg[i]->GetFrameHeight());
		damagingAni[i]->SetPlayFrame(false, false);
		damagingAni[i]->SetUpdateTime(FPS / 2);
		damagingAni[i]->Start();
	}

	enemyAni.walkAni = new Animation();
	enemyAni.walkAni->Init(enemyImg.walkImg->GetWidth(), enemyImg.walkImg->GetHeight(), enemyImg.walkImg->GetFrameWidth(), enemyImg.walkImg->GetFrameHeight());
	enemyAni.walkAni->SetPlayFrame(false, true);
	enemyAni.walkAni->SetUpdateTime(FPS / 6);
	enemyAni.walkAni->Start();

	enemyAni.attackAni = new Animation();
	enemyAni.attackAni->Init(enemyImg.attackImg->GetWidth(), enemyImg.attackImg->GetHeight(), enemyImg.attackImg->GetFrameWidth(), enemyImg.attackImg->GetFrameHeight());
	enemyAni.attackAni->SetPlayFrame(false, false);
	enemyAni.attackAni->SetUpdateTime(FPS / 3);
	enemyAni.attackAni->Start();

	enemyAni.dieAni = new Animation();
	enemyAni.dieAni->Init(enemyImg.dieImg->GetWidth(), enemyImg.dieImg->GetHeight(), enemyImg.dieImg->GetFrameWidth(), enemyImg.dieImg->GetFrameHeight());
	enemyAni.dieAni->SetPlayFrame(false, false);
	enemyAni.dieAni->SetUpdateTime(FPS / 2);
	enemyAni.dieAni->Start();

	enemyAni.flameDieAni = new Animation();
	enemyAni.flameDieAni->Init(enemyImg.flameDieImg->GetWidth(), enemyImg.flameDieImg->GetHeight(), enemyImg.flameDieImg->GetFrameWidth(), enemyImg.flameDieImg->GetFrameHeight());
	enemyAni.flameDieAni->SetPlayFrame(false, false);
	enemyAni.flameDieAni->SetUpdateTime(FPS / 3);
	enemyAni.flameDieAni->Start();

	pos = _pos;
	scale = 2.5f;
	speed = 20.0f;
	probeY = 50;
	isLanding = false;
	isAppear = false;
	isAlive = true;
	isDieLastFrame = false;
	isFlameDie = false;
	
	for (int i = 0; i < 3; i++)
		isDamaging[i] = false;

	hp = 15;
	enemyState = EnemyState::IDLE;
	enemyLookDir = EnemyLookDir::LEFT;

	//��� ��ǥ
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	pixelRect = GetRectToCenter(pos.x, pos.y + 40, 100, 60);

	return S_OK;
}

void BrainEnemy::Release()
{
	for (int i = 0; i < 3; i++)
	{
		SAFE_DELETE(damagingAni[i]);
	}

	if (missile)
	{
		missile->Release();
		SAFE_DELETE(missile);
	}

	if (enemyAni.dieAni)
		SAFE_DELETE(enemyAni.dieAni);

	if (enemyAni.flameDieAni)
		SAFE_DELETE(enemyAni.flameDieAni);

	if (enemyAni.walkAni)
		SAFE_DELETE(enemyAni.walkAni);

	if (enemyAni.attackAni)
		SAFE_DELETE(enemyAni.attackAni);

	Object::Release();
}

void BrainEnemy::Update()
{
	if (isDieLastFrame == false)
	{
		relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
						pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
		pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 70, probeY, probeY * 1.3f);
		rect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 20,
			probeY - 10, probeY * 2.3f);

		if (isLanding == false && isAppear)
		{
			pos.y += 10.0f;
		}

		// ���ʹ� ���¸� �������ִ� �ڵ�
		EnemyStateUpdate();

		// ���ʹ� ������
		EnemyMovement();

		//���ʹ� ����Ʈ
		EnemyEffectUpdate();

		damagingAni[1]->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

		Object::Update();
	}

	if (missile && missile->GetIsFire() == true)
	{
		missile->Update();
	}
}

void BrainEnemy::Render(HDC hdc)
{
	if (missile && missile->GetIsFire() == true)
	{
		missile->Render(hdc);
	}

	if (isDieLastFrame == false)
	{
		EnemyEffectRender(hdc);
		
		EnemyAnimationRender(hdc); //���¿� ���� �ִϸ��̼� ����

	}

	// ���ʹ� ��Ʈ
	//Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
	
	//�ȼ� �浹 ��Ʈ
	//Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);

	
	/*if(missileImg)
		missileImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, missileAni, scale);*/

	//if(missileDisappearImg)
	//	missileDisappearImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, missileDisappearAni, scale);
}

void BrainEnemy::Fire()
{
	if (enemyLookDir == EnemyLookDir::LEFT)
	{
		missile->SetAngle(135.0f);
		missile->SetPos({ pos.x - 50, pos.y - 50 });
	
		int tmp = relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x;
		if (tmp >= 200)
			tmp = 200;
		else if (tmp < 30)
			tmp = 30;

		((EnemyMissile *)missile)->SetX_Speed((tmp) * 3 / 4);
		
		((EnemyMissile *)missile)->SetY_Speed(200);
	}
	else
	{
		missile->SetAngle(45.0f);
		missile->SetPos({ pos.x + 40, pos.y - 50 });

		int tmp = abs(relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x);
		if (tmp >= 200)
			tmp = 200;
		else if (tmp < 30)
			tmp = 30;

		((EnemyMissile *)missile)->SetX_Speed(tmp * 3 / 4);
		((EnemyMissile *)missile)->SetY_Speed(200);
	}

	((EnemyMissile*)missile)->GetMissileAni()->Start();
	missile->SetIsFire(true);
}

void BrainEnemy::EnemyEffectUpdate()
{
	for (int i = 0; i < 3; i++)
	{
		if (isDamaging[i] == true)
		{
			damagingAni[i]->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		if (damagingAni[i]->GetNowPlayIdx() == damagingAni[i]->GetFrameCount() - 1)
		{
			isDamaging[i] = false;
		}
	}
}

void BrainEnemy::EnemyEffectRender(HDC hdc)
{
	for (int i = 0; i < 3; i++)
	{
		if (isDamaging[i] == true)
		{
			if (enemyLookDir == EnemyLookDir::LEFT)
			{
				if (i == 0)
					damagingImg[i]->AnimationRender(hdc, relativePos.x + 60, relativePos.y - 10, damagingAni[i], 2.0f);
				else if (i == 1)
					damagingImg[i]->AnimationRender(hdc, relativePos.x + 20, relativePos.y - 10, damagingAni[i], 2.0f);
				else
					damagingImg[i]->AnimationRender(hdc, relativePos.x + 60, relativePos.y - 50, damagingAni[i], 2.0f);
			}
			else
			{
				if (i == 0)
					damagingImg[i]->AnimationReverseRender(hdc, relativePos.x - 60, relativePos.y - 10, damagingAni[i], 2.0f);
				else if (i == 1)
					damagingImg[i]->AnimationReverseRender(hdc, relativePos.x - 20, relativePos.y - 10, damagingAni[i], 2.0f);
				else
					damagingImg[i]->AnimationReverseRender(hdc, relativePos.x - 60, relativePos.y - 50, damagingAni[i], 2.0f);
			}
			
		}
	}
}

void BrainEnemy::EffectStarting(int _index)
{
	isDamaging[_index] = true;
	damagingAni[_index]->Start();
}

void BrainEnemy::EnemyStateUpdate()
{
	if (isFlameDie == true)
	{
		enemyState = EnemyState::FLAME_DIE;
		return;
	}

	if (hp <= 0)
	{
		enemyState = EnemyState::DIE;
		return;
	}

	if (isLanding == true) //���� ������ Player�� ���� �Ѿƿ´�.
	{
		//���� ����
		if (enemyState != EnemyState::ATTACK)
		{
			// �ٶ󺸴� ������ �����ϴ� �ڵ�
			if (relativePos.x > DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x)
			{
				enemyLookDir = EnemyLookDir::LEFT;
			}
			else
			{
				enemyLookDir = EnemyLookDir::RIGHT;
			}
		}


		if ( abs(relativePos.x - DataCollector::GetSingleton()->GetPlayer()->GetRelativePos().x) < 200 )
		{
			if (enemyState != EnemyState::ATTACK)
			{
				enemyAni.attackAni->Start();
				enemyState = EnemyState::ATTACK;
			}
			
		}
		else
		{
			if (enemyState != EnemyState::ATTACK)
			{
				enemyState = EnemyState::WALK;
			}
		}
	}
}

void BrainEnemy::EnemyMovement()
{
	switch (enemyState)
	{
	case EnemyState::IDLE:

		break;

	case EnemyState::WALK:

		if (isAlive == true)
		{
			if (enemyAni.walkAni)
				enemyAni.walkAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

			if (enemyLookDir == EnemyLookDir::LEFT)
				pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
			else
				pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		break;

	case EnemyState::ATTACK:

		if (isAlive == true)
		{
			if (enemyAni.attackAni)
				enemyAni.attackAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

			if (enemyAni.attackAni->GetNowPlayIdx() == 10)
			{
				Fire();
			}

			if (enemyAni.attackAni->GetNowPlayIdx() == enemyAni.attackAni->GetFrameCount() - 1)
			{
				enemyState = EnemyState::WALK;
			}
		}
		break;

	case EnemyState::DIE:

		if (enemyAni.dieAni)
		{
			enemyAni.dieAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 1.5f);
			if (enemyAni.dieAni->GetNowPlayIdx() == enemyAni.dieAni->GetFrameCount() - 1)
				isDieLastFrame = true;
		}
		
		break;

	case EnemyState::FLAME_DIE:

		if (enemyAni.flameDieAni)
			enemyAni.flameDieAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

		if ((enemyAni.flameDieAni->GetNowPlayIdx() < enemyAni.flameDieAni->GetFrameCount() - 16))
		{
			if (enemyLookDir == EnemyLookDir::LEFT)
				pos.x -= 10.0f * TimeManager::GetSingleton()->GetDeltaTime();
			else
				pos.x += 10.0f * TimeManager::GetSingleton()->GetDeltaTime();
		}
		if (enemyAni.flameDieAni->GetNowPlayIdx() == enemyAni.flameDieAni->GetFrameCount() - 1)
			isDieLastFrame = true;

		break;

	default:
		break;
	}
}

void BrainEnemy::EnemyAnimationRender(HDC hdc)
{
	switch (enemyState)
	{
	case EnemyState::IDLE:


		break;

	case EnemyState::WALK:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.walkImg)
				enemyImg.walkImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.walkAni, scale);
		}
		else
		{
			if (enemyImg.walkImg)
				enemyImg.walkImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.walkAni, scale);
		}

		break;

	case EnemyState::ATTACK:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.attackImg)
				enemyImg.attackImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.attackAni, scale);
		}
		else
		{
			if (enemyImg.attackImg)
				enemyImg.attackImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.attackAni, scale);
		}

		break;

	case EnemyState::DIE:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.dieImg)
				enemyImg.dieImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.dieAni, scale);
		}
		else
		{
			if (enemyImg.dieImg)
				enemyImg.dieImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y, enemyAni.dieAni, scale);
		}

		break;

	case EnemyState::FLAME_DIE:

		if (enemyLookDir == EnemyLookDir::LEFT)
		{
			if (enemyImg.flameDieImg)
				enemyImg.flameDieImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y - 40, enemyAni.flameDieAni, scale);
		}
		else
		{
			if (enemyImg.flameDieImg)
				enemyImg.flameDieImg->AnimationReverseRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y - 40, enemyAni.flameDieAni, scale);
		}

		break;

	default:
		break;
	}

}

BrainEnemy::BrainEnemy()
{
}

BrainEnemy::~BrainEnemy()
{
}

HRESULT FatEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Fat", "Image/Enemy/Fat/Fat.bmp", 47, 56, true, RGB(134, 44, 118));
	pos = { 650 , 100 };


	return S_OK;
}

void FatEnemy::Release()
{
}

void FatEnemy::Update()
{
}

void FatEnemy::Render(HDC hdc)
{
}

void FatEnemy::Fire()
{
}

void FatEnemy::EffectStarting(int _index)
{
}

FatEnemy::FatEnemy()
{
}

FatEnemy::~FatEnemy()
{
}

HRESULT TarEnemy::Init()
{
	//enemyWalkImg = ImageManager::GetSingleton()->AddImage("Tar", "Image/Enemy/Tar/Tar.bmp", 42, 51, true, RGB(87, 111, 183));
	pos = { 700 , 100 };


	return S_OK;
}

void TarEnemy::Release()
{
}

void TarEnemy::Update()
{
}

void TarEnemy::Render(HDC hdc)
{
}

void TarEnemy::Fire()
{
}

void TarEnemy::EffectStarting(int _index)
{
}

TarEnemy::TarEnemy()
{
}

TarEnemy::~TarEnemy()
{
}

#pragma once
#include "AttackStrategy.h"

class Attacking : public AttackStrategy
{
private:

	AttackStrategy* attackStrategy;

public:

	void SetStrategy( AttackStrategy* _attackStrategy )
	{
		if (attackStrategy)
			attackStrategy->InitMissile();

		attackStrategy = _attackStrategy;
	}
	
	virtual void Attack(FPOINT pos, float angle, int _heavyMissile=0)
	{
		attackStrategy->Attack(pos, angle, _heavyMissile);
	}

	void Update()
	{
		attackStrategy->Update();
	}

	void Render(HDC hdc)
	{
		attackStrategy->Render(hdc);
	}

	Attacking();
	virtual ~Attacking();
};


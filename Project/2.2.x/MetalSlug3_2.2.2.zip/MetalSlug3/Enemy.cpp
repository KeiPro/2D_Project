#include "Enemy.h"
#include "Image.h"

HRESULT Enemy::Init()
{
	brainEnemyVec.reserve(10);
	fatEnemyVec.reserve(10);
	tarEnemyVec.reserve(10);

	for (int i = 0; i < 10; i++)
	{
		BrainEnemy* brain = new BrainEnemy();
		brain->Init();

		FatEnemy* fat = new FatEnemy();
		fat->Init();

		TarEnemy* tar = new TarEnemy();
		tar->Init();

		brainEnemyVec.push_back(brain);
		fatEnemyVec.push_back(fat);
		tarEnemyVec.push_back(tar);
	}

	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
	for (brainEnemyIt = brainEnemyVec.begin(); brainEnemyIt != brainEnemyVec.end(); brainEnemyIt++)
	{
		(*brainEnemyIt)->Update();
	}
}

void Enemy::Render(HDC hdc)
{
	for (auto& it : brainEnemyVec)
	{
		it->Render(hdc);
	}
}

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

HRESULT BrainEnemy::Init()
{
	enemyImg = ImageManager::GetSingleton()->AddImage("Brain", "Image/Enemy/Brain/Brain.bmp", 39, 53, true, RGB(115, 155, 115));
	
	pos = { 600 , 100 };
	scale = 2.5f;
	speed = 500.0f;

	return S_OK;
}

void BrainEnemy::Release()
{
}

void BrainEnemy::Update()
{


}

void BrainEnemy::Render(HDC hdc)
{
	if (enemyImg)
		enemyImg->Render(hdc, pos.x + DataCollector::GetSingleton()->GetEditorAddValue(), pos.y, 2.3f);
}

BrainEnemy::BrainEnemy()
{
}

BrainEnemy::~BrainEnemy()
{
}

HRESULT FatEnemy::Init()
{
	enemyImg = ImageManager::GetSingleton()->AddImage("Fat", "Image/Enemy/Fat/Fat.bmp", 47, 56, true, RGB(134, 44, 118));
	pos = { 650 , 100 };


	return S_OK;
}

void FatEnemy::Release()
{
}

void FatEnemy::Update()
{
}

void FatEnemy::Render(HDC hdc)
{
}

FatEnemy::FatEnemy()
{
}

FatEnemy::~FatEnemy()
{
}

HRESULT TarEnemy::Init()
{
	enemyImg = ImageManager::GetSingleton()->AddImage("Tar", "Image/Enemy/Tar/Tar.bmp", 42, 51, true, RGB(87, 111, 183));
	pos = { 700 , 100 };


	return S_OK;
}

void TarEnemy::Release()
{
}

void TarEnemy::Update()
{
}

void TarEnemy::Render(HDC hdc)
{
}

TarEnemy::TarEnemy()
{
}

TarEnemy::~TarEnemy()
{
}

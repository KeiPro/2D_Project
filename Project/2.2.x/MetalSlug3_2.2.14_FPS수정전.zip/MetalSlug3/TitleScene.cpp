#include "TitleScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT TitleScene::Init()
{
	introImg = ImageManager::GetSingleton()->AddImage("Intro1", "Image/Intro/Intro_1.bmp", 0, 0, 10400, 600, 13, 1 );
	introAni = new Animation();
	introAni->Init(introImg->GetWidth(), introImg->GetHeight(), introImg->GetFrameWidth(), introImg->GetFrameHeight());
	introAni->SetPlayFrame(false, true);
	introAni->SetUpdateTime(FPS);
	introAni->Start();
	return S_OK;
}

void TitleScene::Release()
{
	if (introAni)
	{
		SAFE_DELETE(introAni);
	}
}

void TitleScene::Update()
{
	if (introAni)
	{
		introAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	{
		SceneManager::GetSingleton()->ChangeScene("BattleScene");	
		//SceneManager::GetSingleton()->ChangeScene("EditorScene");
	}

	//testAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	//testAni_leg->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void TitleScene::Render(HDC hdc)
{
	if (introImg)
	{
		introImg->AnimationRender(hdc, introImg->GetFrameWidth() / 2, introImg->GetFrameHeight() / 2, introAni);
	}

	//leg_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2 - 10, WINSIZE_Y / 2 + 40, testAni_leg);
	//body_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, testAni);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}

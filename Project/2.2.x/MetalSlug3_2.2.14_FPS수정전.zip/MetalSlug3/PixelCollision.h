#pragma once
#include "GameNode.h"

class NPC;
class Missile;
class Enemy;
class Player;
class Image;
class PixelCollision : public GameNode
{
private:
	Player* player;
	//Image*  pixelBackground;
	Image*	pixelBackbuffer;
	PixelColl_ID pixelCollId;
	Enemy* enemy;
	Missile* missile;
	NPC* npc;
	
/*
	int currentPrintPosX;
	int currentPrintPosY;*/

public:

	HRESULT Init(PixelColl_ID _pixelCollId);
	void Update(int currentPrintPosX = 0, int currentPrintPosY = 0);
	void Release();
	void Render(HDC hdc);
	
	void SetEnemy(Enemy* _enemy) { enemy = _enemy; }
	void SetPlayer(Player* _player) { player = _player; }
	void SetMissile(Missile* _missile) { missile = _missile; }
	void SetNPC(NPC* _npc) { npc = _npc; }


	//void SetCurrentPrintPosX(int _currentX) { currentPrintPosX = _currentX; }
	//void SetCurrentPrintPosY(int _currentY) { currentPrintPosY = _currentY; }
	//void SetPixelBackground

	PixelCollision();
	~PixelCollision();
};


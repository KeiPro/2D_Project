#include "NPC.h"
#include "Animation.h"
#include "Image.h"

NPC::NPC()
{
}


NPC::~NPC()
{
}

HRESULT Fat_Human::Init(FPOINT _pos)
{
	Object::SetNPC(this);
	Object::Init(PixelColl_ID::NPC);

	defaultImg = ImageManager::GetSingleton()->AddImage("FatHumanDefault", "Image/Enemy/Fat/Fat_Default.bmp", 0, 0, 400, 40, 8, 1, true, RGB(134, 44, 118));
	zombieChangeImg = ImageManager::GetSingleton()->AddImage("FatZombieChangeImg", "Image/Enemy/Fat/Fat_HumanChange.bmp", 0, 0, 550, 40, 11, 1, true, RGB(134, 44, 118));
	downZombieImg = ImageManager::GetSingleton()->AddImage("downZombieImg", "Image/Enemy/Fat/Fat_Zombie_Default.bmp", 0, 0, 50, 50, 1, 1, true, RGB(134, 44, 118));

	defaultAni = new Animation();
	defaultAni->Init(defaultImg->GetWidth(), defaultImg->GetHeight(), defaultImg->GetFrameWidth(), defaultImg->GetFrameHeight());
	defaultAni->SetPlayFrame(false, true);
	defaultAni->SetUpdateTime(FPS / 6);
	defaultAni->Start();

	zombieChangeAni = new Animation();
	zombieChangeAni->Init(zombieChangeImg->GetWidth(), zombieChangeImg->GetHeight(), zombieChangeImg->GetFrameWidth(), zombieChangeImg->GetFrameHeight());
	zombieChangeAni->SetPlayFrame(false, false);
	zombieChangeAni->SetUpdateTime(FPS / 3);
	zombieChangeAni->Start();

	pos = _pos;
	scale = 2.5f;
	probeY = 50;
	isLanding = false;
	isAppear = false;
	isZombie = false;
	isMissileColl = false;
	isCreatingZombie = false;
	isEraseData = false;
	//rect = GetRectToCenter()


	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
	pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	
	return S_OK;
}

void Fat_Human::Release()
{
	if (defaultAni)
		SAFE_DELETE(defaultAni);

	if (zombieChangeAni)
		SAFE_DELETE(zombieChangeAni);

	Object::Release();
}

void Fat_Human::Update()
{
	if ( (isLanding == false) && (isAppear == true) )
	{
		pos.y += 10.0f;
	}

	if (isMissileColl == false)
	{
		defaultAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}
	else
	{
		zombieChangeAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

		if (zombieChangeAni->GetNowPlayIdx() == zombieChangeAni->GetFrameCount() - 1)
		{
			isZombie = true;
		}
	}

	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
						pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 30, probeY, probeY);
	rect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y,
		defaultImg->GetFrameWidth() * 2.0f, defaultImg->GetFrameHeight() * 1.2f);

	Object::Update();
}

void Fat_Human::Render(HDC hdc)
{
	//Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);

	if (isZombie == true)
	{
		//downZombieImg->FrameRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y - 35, 0, 0, scale);
		isEraseData = true;
		return;
	}

	if (isMissileColl == false)
	{
		defaultImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y - 20, defaultAni, scale);
	}
	else
	{
		zombieChangeImg->AnimationRender(hdc, relativePos.x + DataCollector::GetSingleton()->GetEditorAddValue(), relativePos.y - 20, zombieChangeAni, scale);
	}
}

Fat_Human::Fat_Human()
{
}

Fat_Human::~Fat_Human()
{
}

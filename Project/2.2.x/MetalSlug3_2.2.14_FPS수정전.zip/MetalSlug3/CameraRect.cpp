#include "CameraRect.h"


void CameraRect::Init()
{
	//cameraYRectList

	//.reserve(20);
	//cameraYRectVec.clear();

	FILE* fp = NULL;

	fopen_s(&fp, "Save/Camera.txt", "r");

	if (fp != NULL)
	{
		int vecCount;
		fscanf_s(fp, "%d", &vecCount);

		cameraYRectVec.reserve(vecCount);

		while (true)
		{
			if (feof(fp))
				break;

			RECT_INFO* rectInfo = new RECT_INFO();
			fscanf_s(fp, "%d", &(rectInfo->rc.left));
			fscanf_s(fp, "%d", &(rectInfo->rc.top));
			fscanf_s(fp, "%d", &(rectInfo->rc.right));
			fscanf_s(fp, "%d", &(rectInfo->rc.bottom));
			fscanf_s(fp, "%d", &(rectInfo->value));
			fscanf_s(fp, "%d", &(rectInfo->isCollision));

			cameraYRectVec.push_back(rectInfo);
		}

		fclose(fp);
	}
}

void CameraRect::Release()
{
	cameraYRectVec.clear();

	vector<RECT_INFO*>().swap(cameraYRectVec);
}

CameraRect::CameraRect()
{
}


CameraRect::~CameraRect()
{
}

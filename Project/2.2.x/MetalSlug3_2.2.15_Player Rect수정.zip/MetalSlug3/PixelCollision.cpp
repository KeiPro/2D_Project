#include "PixelCollision.h"
#include "Image.h"
#include "Player.h"
#include "Enemy.h"
#include "Missile.h"
#include "NPC.h"

HRESULT PixelCollision::Init(PixelColl_ID _pixelCollId)
{
	pixelCollId = _pixelCollId;
	pixelBackbuffer = DataCollector::GetSingleton()->GetPixelBackbuffer();
	player = DataCollector::GetSingleton()->GetPlayer();

	return S_OK;
}

void PixelCollision::Update(int currentPrintPosX, int currentPrintPosY)
{
	//�ȼ� �浹
	COLORREF color;
	int R, G, B;

	switch (pixelCollId)
	{
	case PixelColl_ID::PLAYER:
	{
		for (int i = player->GetRC().top; i < player->GetRC().bottom; i++)
		{
			color = GetPixel(pixelBackbuffer->GetMemDC(), player->GetPlayerPos().x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, i);
			R = GetRValue(color);
			G = GetGValue(color);
			B = GetBValue(color);

			// �ȼ� �浹
			if ((R == 255) && (G == 0) && (B == 255))
			{
				if (player->GetIsMaxJumpY() == true)
				{
					player->SetPlayerPosY(i + DataCollector::GetSingleton()->GetCurrentPrintPos().y - 10);
					player->SetIsLanding(true);
					player->SetJumpAniCheck(false);
					player->SetG_Acceleration(0);
					player->SetyAxisV(0);
				}

				//player->SetPlayerLegState(PlayerState::Idle);
				break;
			}
			else
			{
				player->SetIsLanding(false);
			}
		}	
	}
		break;
	case PixelColl_ID::ENEMY:
	{
		for (int i = enemy->GetPixelRc().top; i < enemy->GetPixelRc().bottom; i++)
		{
			color = GetPixel(pixelBackbuffer->GetMemDC(), enemy->GetPos().x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, i);
			R = GetRValue(color);
			G = GetGValue(color);
			B = GetBValue(color);

			// �ȼ� �浹
			if ((R == 255) && (G == 0) && (B == 255))
			{
				enemy->SetPosY(i + DataCollector::GetSingleton()->GetCurrentPrintPos().y - 80);
				enemy->SetIsLanding(true);
				break;
			}
			else
			{
				enemy->SetIsLanding(false);
			}
		}
	}
		break;
	case PixelColl_ID::BULLET:

		if (missile->GetIsFire() == true)
		{
			for (int i = missile->GetRect().top; i < missile->GetRect().bottom; i++)
			{
				color = GetPixel(pixelBackbuffer->GetMemDC(), missile->GetPos().x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, i);
				R = GetRValue(color);
				G = GetGValue(color);
				B = GetBValue(color);

				// �ȼ� �浹
				if ((R == 255) && (G == 0) && (B == 255))
				{
					missile->SetCollision(true);

					break;
				}
				else
				{
					//missile->SetIsLanding(false);
				}
			}
		}
		break;

	case PixelColl_ID::NPC:

		for (int i = npc->GetPixelRc().top; i < npc->GetPixelRc().bottom; i++)
		{
			color = GetPixel(pixelBackbuffer->GetMemDC(), npc->GetPos().x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, i);
			R = GetRValue(color);
			G = GetGValue(color);
			B = GetBValue(color);

			// �ȼ� �浹
			if ((R == 255) && (G == 0) && (B == 255))
			{
				npc->SetPosY(i + DataCollector::GetSingleton()->GetCurrentPrintPos().y - 30);
				npc->SetIsLanding(true);
				break;
			}
			else
			{
				npc->SetIsLanding(false);
			}
		}
		
		break;

	default:
		break;
	}

	
}

void PixelCollision::Release()
{
	if (pixelBackbuffer)
	{
		pixelBackbuffer->Release();
		SAFE_DELETE(pixelBackbuffer);
	}
}

void PixelCollision::Render(HDC hdc)
{
	BitBlt(hdc, DataCollector::GetSingleton()->GetEditorAddValue(), 0, GAME_SIZE_X, GAME_SIZE_Y,
		pixelBackbuffer->GetMemDC(), 0, 0, SRCCOPY);
}

PixelCollision::PixelCollision()
{
}


PixelCollision::~PixelCollision()
{
}

#include "UI.h"



HRESULT UI::Init()
{
	return S_OK;
}

void UI::Release()
{
}

void UI::Update()
{
}

void UI::Render(HDC hdc)
{
}

UI::UI()
{
}


UI::~UI()
{
}

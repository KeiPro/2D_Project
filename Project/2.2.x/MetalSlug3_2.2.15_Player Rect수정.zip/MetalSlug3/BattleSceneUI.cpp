#include "BattleSceneUI.h"
#include "GoUI.h"


HRESULT BattleSceneUI::Init()
{
	goUI = new GoUI();
	goUI->Init();




	return S_OK;
}

void BattleSceneUI::Release()
{
	if (goUI)
	{
		goUI->Release();
		SAFE_DELETE(goUI);
	}
}

void BattleSceneUI::Update()
{
	if (goUI)
	{
		goUI->Update();
	}
}

void BattleSceneUI::Render(HDC hdc)
{
	if (goUI)
	{
		goUI->Render(hdc);
	}
}

BattleSceneUI::BattleSceneUI()
{
}


BattleSceneUI::~BattleSceneUI()
{
}

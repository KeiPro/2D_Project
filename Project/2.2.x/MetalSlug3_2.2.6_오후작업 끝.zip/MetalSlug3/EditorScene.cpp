#include "EditorScene.h"
#include "Image.h"
#include "ButtonFunction.h"
#include "Button.h"
#include "Player.h"
#include "CameraRect.h"
#include "Camera.h"
#include "PixelCollision.h"
#include "DataCollector.h"
#include "Enemy.h"
#include <fstream>


LPSTR		g_lpszClass2 = (LPSTR)TEXT("���� �Է��ϼ���.");
bool		rectSetting = false;
LRESULT CALLBACK WndProcNew(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
char str[128] = {0};

HRESULT EditorScene::Init()
{
	stage2MapImg = ImageManager::GetSingleton()->AddImage("Stage2_Map", "Image/Background/Stage2_Map.bmp", 5483, 906, true, RGB(255, 255, 255));
	//ImageManager::GetSingleton()->AddImage("PixelCollision", "Image/Background/Stage2_Map_PixelCollision.bmp", 5483, 906);
	buttonClickImg = ImageManager::GetSingleton()->AddImage("CameraButtonImg", "Image/Button/button.bmp", 0.0f, 0.0f, 122, 62, 1, 2);

	brainEnemy	 = new BrainEnemy();
	brainEnemy->Init();

	fatEnemy	 = new FatEnemy();
	fatEnemy->Init();

	tarEnemy	 = new TarEnemy();
	tarEnemy->Init();
	
	DataCollector::GetSingleton()->SetEditorAddValue(WINSIZE_X - GAME_SIZE_X);

	color = RGB(255, 255, 255);
	brush = CreateSolidBrush(color);
	pen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));

	player = new Player();
	player->Init(DataCollector::GetSingleton()->GetEditorAddValue());
	DataCollector::GetSingleton()->SetPlayer(player); //�÷��̾� ����

	//pixelCollision = new PixelCollision();
	//pixelCollision->Init();
	//pixelCollision->SetPlayer(player);


	camera = new Camera();
	camera->Init(DataCollector::GetSingleton()->GetEditorAddValue());
	camera->SetPlayer(player);

	cameraRect = new CameraRect();
	cameraRect->Init();

	panel = { 0, 0, WINSIZE_X, WINSIZE_Y };
	//editorMenuPanel = { 0, 0, WINSIZE_X / 3, WINSIZE_Y };
	//editorMapPanel = {WINSIZE_X / 3, 0, WINSIZE_X, WINSIZE_Y};

	editorMenuPanel = { 0, 0, WINSIZE_X - 800, WINSIZE_Y };
	editorMapPanel = {WINSIZE_X - 800, 0, WINSIZE_X, WINSIZE_Y};

	//�귯�� ����

	saveButtonRect = { 0 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 6 - 20), (WINSIZE_Y * 3 / 4) + 40 };
	loadButtonRect = { WINSIZE_X / 6 + 10,  ( WINSIZE_Y * 3 / 4 ), (WINSIZE_X / 3 - 20), (WINSIZE_Y * 3 / 4) + 40 };

	currentPrintPos = {0, 0};

	//g_wheelMouse = 1.0f;
	mouseClickDown = false;

	POINT upFramePoint = { 0, 0 };
	POINT downFramePoint = { 0, 1 };

	//// ��ư
	ButtonsSetPosition();
	
	for (int i = 0; i < 5; i++)
	{
		buttonDown[i] = false;
	}

	editBoxCheck = false;

	//H ��ư�� ������ �ִ����� üũ�� ����
	hButtonCheck = false;

	//�� ��° ��ư�� ���ȴ����� üũ�� ����
	buttonTmp = 0;

	//�޴� ī�޶� ��Ʈ ����
	MenuCameraYRectSet();

	//�޴� ���׹� ��Ʈ ����
	MenuEnemysRect();

	//y�� ī�޶� ����
	cameraYMove = false;
	moveValueRate = 0;

	buttonType = BUTTON_TYPE::TYPE_NONE;

	//����� ���
	debugMode = false;
	return S_OK;
}

void EditorScene::Release()
{
	if (brainEnemy)
	{
		brainEnemy->Release();
		SAFE_DELETE(brainEnemy);
	}

	if (fatEnemy)
	{
		fatEnemy->Release();
		SAFE_DELETE(fatEnemy);
	}

	if (tarEnemy)
	{
		tarEnemy->Release();
		SAFE_DELETE(tarEnemy);
	}

	//if (pixelCollision)
	//{
	//	pixelCollision->Release();
	//	SAFE_DELETE(pixelCollision);
	//}

	if (camera) 
	{
		camera->Release();
		SAFE_DELETE(camera);
	}

	if (cameraRect)
	{
		cameraRect->Release();
		SAFE_DELETE(cameraRect);
	}

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}


	DeleteObject(brush);
	DeleteObject(pen);
}

void EditorScene::Update()
{
	//editorMap�� ���콺���� ����
	if (brainEnemy)
		brainEnemy->Update();

	if (rectSetting == true)
	{
		rectSetting = false;
		//ī�޶� ��Ʈ ���Ϳ� �ִ� �ڵ�
		VectorInputCameraYRect();
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown('H'))
	{
		hButtonCheck = true;
	}
	
	if (KeyManager::GetSingleton()->IsOnceKeyUp('H'))
	{
		hButtonCheck = false;
	}


	if (debugMode == true)
	{
		//�� �����Ϳ� ���콺 ��ġ���� ����
		if (PtInRect(&editorMapPanel, g_ptMouse))
		{
			if (hButtonCheck == true)
			{	//hButton�� ������ ������ �� �����͸� �̵���Ų��. ( �ڵ��� )
				if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
				{
					if (mouseClickDown == false)
					{
						mousePos[0] = g_ptMouse;
						mouseClickDown = true;
					}

					//if (mouseClickDown == true)
					//{
					//	mousePos[1] = g_ptMouse;
					//}

					//if (mousePos[1].x != mousePos[2].x && mousePos[1].y != mousePos[2].y)
					//{
					//	currentprintPos.x += (mousePos[2].x - mousePos[1].x) * 0.5f;
					//	currentprintPos.y += (mousePos[2].y - mousePos[1].y) * 0.5f;
					//}

					//mousePos[2] = g_ptMouse;
				}

				if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON))
				{
					mouseClickDown = false;

					// �� ������ ��ġ������ ����Ǳ� ���� ����ó��
					// if (g_ptMouse.x <= 445) g_ptMouse.x = mousePos[0].x;
					mapMoveValue.x = (mousePos[0].x - g_ptMouse.x);
					currentPrintPos.x += mapMoveValue.x;

					//currentPrintPos����ó��.
					if (currentPrintPos.x <= 0 || currentPrintPos.x >= 5175 * 2.7f)
					{
						if (currentPrintPos.x <= 0)	currentPrintPos.x = 0;
						else currentPrintPos.x = 5175 * 2.7f;
					}

					mapMoveValue.y = (mousePos[0].y - g_ptMouse.y);
					currentPrintPos.y += mapMoveValue.y;

					if (currentPrintPos.y <= -30 * 2.7f || currentPrintPos.y >= 460 * 2.7f)
					{
						if (currentPrintPos.y <= -30 * 2.7f) currentPrintPos.y = -30 * 2.7f;
						else currentPrintPos.y = 460 * 2.7f;
					}

					cameraRect->menuCameraRectMoveCheck = false;
				}
			}
		}

		//���콺 ���� ��ư�� ���� �� - ������Ʈ ��ġ, ��ư Ŭ�� ��
		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON))
		{
			if (PtInRect(&saveButtonRect, g_ptMouse))
			{
				Save();
			}

			if (PtInRect(&loadButtonRect, g_ptMouse))
			{
				Load();
			}


			//�ʿ� ������Ʈ ��ġ
			ObjectPutInMap();

			// ��ư Ŭ����
			for (int i = 0; i < 5; i++)
			{
				if (PtInRect(&buttonRect[i], g_ptMouse))
				{
					buttonDown[i] = true;
					buttonTmp = i;

					switch (i)
					{
					case (int)BUTTON_TYPE::TYPE_CAMERA:

						buttonType = BUTTON_TYPE::TYPE_CAMERA;
						menuEnemyMoveBool = false;

						break;

					case (int)BUTTON_TYPE::TYPE_ENEMY:

						buttonType = BUTTON_TYPE::TYPE_ENEMY;
						cameraRect->menuCameraMouseMove = false;

						break;

					default:

						buttonType = BUTTON_TYPE::TYPE_NONE;
						break;
					}

					break;
				}
			}

			//
			for (int i = 0; i < 5; i++)
			{
				if (i != buttonTmp)
				{
					buttonDown[i] = false;
				}
			}
			
			// �ش� ��ư Ÿ�Կ��� ������Ʈ�� Ŭ������ ��
			ObjectRectClick();
		}

		//��ư�� Ŭ���ϰ� �ش� Rect�� ���콺�� ����ٴϱ� ���ؼ�
		ObjectMouseMove();
	}

	if (player)
	{
		player->Update();
		player->SetTmpCurrentXY({ currentPrintPos.x, currentPrintPos.y});
	}

	if (camera)
		camera->Update();

	if (cameraYMove == true)
	{
		YAxisMove(); //y�� �̵� ����
	}

	CollisionYRect(DataCollector::GetSingleton()->GetEditorAddValue());

	currentPrintPos.x += camera->GetCameraSpeed();

	//pixelCollision->Update(currentPrintPos.x, currentPrintPos.y);
	
	//������������� �����ǥ�� ���ϱ� ���ؼ� currentPrintPos�� ���� ������ �� �ְ� �������ش�.
	DataCollector::GetSingleton()->SetCurrentPrintPos(currentPrintPos);
	
	// Debug �����ֱ�
	if (KeyManager::GetSingleton()->IsOnceKeyDown('P'))
	{
		debugMode = !debugMode;
	}
}

void EditorScene::Render(HDC hdc)
{
	// Panel ( ��ü �г� )
	SetColor(RGB(195, 195, 195));
	FillRect(hdc, &panel, brush);

	SetColor(RGB(255,255,255));
	FillRect(hdc, &editorMenuPanel, brush);

	// �������� ��ü �̹��� ���
	stage2MapImg->MapEditorRender(hdc, WINSIZE_X-GAME_SIZE_X, 0, 2.7f, currentPrintPos);
	
	//if (debugMode)
	//	pixelCollision->Render(hdc);
	//BitBlt(hdc, WINSIZE_X - 800, 0, WINSIZE_X, WINSIZE_Y, pixelBackbuffer->GetMemDC(), 0, 0, SRCCOPY);

	//ī�޶� ��Ʈ ������ŭ ����
	if (hButtonCheck == false)
	{
		for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
		{
			if (CameraRectInYRect(currentPrintPos, cameraRect->cameraYRectVec[i]->rc) == true)
			{
				SetColor(RGB(255, 255, 255));
				Rectangle(hdc,
					(DataCollector::GetSingleton()->GetEditorAddValue()) + cameraRect->cameraYRectVec[i]->rc.left - currentPrintPos.x,
					cameraRect->cameraYRectVec[i]->rc.top - currentPrintPos.y,
					(DataCollector::GetSingleton()->GetEditorAddValue()) + cameraRect->cameraYRectVec[i]->rc.right - currentPrintPos.x,
					cameraRect->cameraYRectVec[i]->rc.bottom - currentPrintPos.y);
				
				sprintf_s(szText, "%d", cameraRect->cameraYRectVec[i]->value);
				TextOut(hdc, (DataCollector::GetSingleton()->GetEditorAddValue()) + cameraRect->cameraYRectVec[i]->rc.left - currentPrintPos.x,
					(cameraRect->cameraYRectVec[i]->rc.bottom + cameraRect->cameraYRectVec[i]->rc.top) / 2 - currentPrintPos.y, szText, strlen(szText));
			}
		}
	}

	// ��� �г� ( �޴� )
	if (buttonClickImg)
	{
		for (int i = 0; i < 5; i++)
		{
			buttonClickImg->FrameRender(hdc, buttonRect[i].left + buttonClickImg->GetFrameWidth() / 2,
				buttonRect[i].top + buttonClickImg->GetFrameHeight() / 2, 0, buttonDown[i]);
		}
	}

	//���̺� �ε� ��ư ��Ʈ 
	//FillRect(hdc, &saveButtonRect, brush);
	//FillRect(hdc, &loadButtonRect, brush);

	Rectangle(hdc, saveButtonRect.left, saveButtonRect.top, saveButtonRect.right, saveButtonRect.bottom);
	Rectangle(hdc, loadButtonRect.left, loadButtonRect.top, loadButtonRect.right, loadButtonRect.bottom);


	switch (buttonType)
	{
		case BUTTON_TYPE::TYPE_CAMERA:

			Rectangle(hdc, cameraRect->menuCameraYRect.left, cameraRect->menuCameraYRect.top, cameraRect->menuCameraYRect.right, cameraRect->menuCameraYRect.bottom);

			if (cameraRect->menuCameraMouseMove && (hButtonCheck == false))
			{
				Rectangle(hdc, cameraRect->menuCameraMoveYRect.left, cameraRect->menuCameraMoveYRect.top, cameraRect->menuCameraMoveYRect.right, cameraRect->menuCameraMoveYRect.bottom);
			}

			break;

		case BUTTON_TYPE::TYPE_ENEMY:
			for (int i = 0; i < 3; i++)
			{
				//Rectangle(hdc, menuEnemyRect[i].left, menuEnemyRect[i].top, menuEnemyRect[i].right, menuEnemyRect[i].bottom);
				enemyImg[i]->Render(hdc, menuEnemyRect[i].left, menuEnemyRect[i].top, 2.0f);
			}
			if (menuEnemyMoveBool && (hButtonCheck == false))
			{
				Rectangle(hdc, menuEnemyMoveRect.left, menuEnemyMoveRect.top, menuEnemyMoveRect.right, menuEnemyMoveRect.bottom);
			}

			break;

		default:

			break;
	}

	
	if (player)
		player->Render(hdc);

	if (brainEnemy)
		brainEnemy->Render(hdc);
	

	if (debugMode)
	{
		int j = 0;
		if (camera)
			camera->Render(hdc, currentPrintPos.y);

		sprintf_s(szText, "���콺 ��ġ : [ %d, %d ]", g_ptMouse.x, g_ptMouse.y);
		TextOut(hdc, 50, 30 * (j + 1), szText, strlen(szText));
		sprintf_s(szText, "�� ������ ��ġ : [ %d, %d ] ", currentPrintPos.x, currentPrintPos.y);
		TextOut(hdc, 50, 30 * (j + 2), szText, strlen(szText));
		sprintf_s(szText, "ī�޶� �� Ƚ�� : [ %d ] ", cameraRect->cameraYRectVec.size());
		TextOut(hdc, 50, 30 * (j + 3), szText, strlen(szText));
		//sprintf_s(szText, "mapMoveValue : [ %d, %d ] ", mapMoveValue.x, mapMoveValue.y);
		//TextOut(hdc, 50, 120, szText, strlen(szText));	
		sprintf_s(szText, "cameraYRectVec : [ %d ] ", cameraRect->cameraYRectVec.capacity());
		TextOut(hdc, 50, 30 * (j + 4), szText, strlen(szText));
		sprintf_s(szText, "player : [ %f, %f ] ", player->GetPlayerPos().x, player->GetPlayerPos().y );
		TextOut(hdc, 50, 30 * (j + 5), szText, strlen(szText));
		sprintf_s(szText, "playerCollRect : [ %d, %d, %d, %d ] ", player->GetPlayerCollRC().left,
			player->GetPlayerCollRC().top, player->GetPlayerCollRC().right, player->GetPlayerCollRC().bottom);
		TextOut(hdc, 50, 30 * (j + 6), szText, strlen(szText));

		for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
		{
			sprintf_s(szText, "��Ʈ ��ġ : [ %d, %d, %d, %d ] ",cameraRect->cameraYRectVec[i]->rc.left,
				cameraRect->cameraYRectVec[i]->rc.top, cameraRect->cameraYRectVec[i]->rc.right, cameraRect->cameraYRectVec[i]->rc.bottom);
			TextOut(hdc, 50, 30 * (j + 7 + i), szText, strlen(szText));
		}
	}
}

bool EditorScene::CameraRectInYRect(POINT currentPrintPos, RECT cameraYRect)
{
	if ( currentPrintPos.x < cameraYRect.left &&
		 currentPrintPos.y < cameraYRect.top &&
		currentPrintPos.x + GAME_SIZE_X> cameraYRect.right &&
		currentPrintPos.y + GAME_SIZE_Y > cameraYRect.bottom)
		return true;
	else
		return false;
}

void EditorScene::ButtonsSetPosition()
{
	buttonRect[0] = GetRectToCenter(WINSIZE_X / 12 - 30, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[2] = GetRectToCenter(WINSIZE_X / 4 + 30, WINSIZE_Y / 15 + 20, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[3] = GetRectToCenter(WINSIZE_X / 8 - 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
	buttonRect[4] = GetRectToCenter(WINSIZE_X * 5 / 24 + 15, WINSIZE_Y / 15 + 70, buttonClickImg->GetFrameWidth(), buttonClickImg->GetFrameHeight());
}

void EditorScene::MenuCameraYRectSet()
{
	cameraRect->menuCameraYRect = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2 - 50, 20, 150);
	cameraRect->menuCameraMoveYRect = cameraRect->menuCameraYRect;
	cameraRect->menuCameraMouseMove = false;
	cameraRect->menuCameraRectMoveCheck = false;
}

void EditorScene::MenuEnemysRect()
{
	menuEnemyRect[0] = GetRectToCenter(WINSIZE_X / 12, WINSIZE_Y / 2, 100, 100);
	menuEnemyRect[1] = GetRectToCenter(WINSIZE_X / 6, WINSIZE_Y / 2, 100, 100);
	menuEnemyRect[2] = GetRectToCenter(WINSIZE_X / 4 + 30, WINSIZE_Y / 2 + 5, 100, 100);
	menuEnemyMoveRect = menuEnemyRect[0];
	enemyId = -1;
	menuEnemyMoveBool = false;
}

void EditorScene::VectorInputCameraYRect()
{
	RECT_INFO* rectInfo = new RECT_INFO();

	rectInfo->rc = cameraRect->menuCameraMoveYRect;

	// ���� ���� currPrintPos.x�� y�� ������,
	// menuCameraMoveYRect.left, top, right, bottom��ŭ�� �����ش�.
	rectInfo->rc.left += currentPrintPos.x;
	rectInfo->rc.right += currentPrintPos.x;
	rectInfo->rc.top += currentPrintPos.y;
	rectInfo->rc.bottom += currentPrintPos.y;

	rectInfo->rc.left -= DataCollector::GetSingleton()->GetEditorAddValue();
	rectInfo->rc.right -= DataCollector::GetSingleton()->GetEditorAddValue();

	rectInfo->value = atoi(str);
	rectInfo->isCollision = false;

	//RECT tmpFRect = { rc.left, rc.top, rc.right, rc.bottom };

	// --> ���� ���� ��ǥ�� �ȴ�.
	cameraRect->menuCameraRectMoveCheck = true;
	cameraRect->cameraYRectVec.push_back(rectInfo);
}

void EditorScene::EditWindowCreate()
{
	WNDCLASS wndClass2;

	wndClass2.cbClsExtra = 0;	// Ŭ���� ���� �޸�
	wndClass2.cbWndExtra = 0;	// ������ ���� �޸�
	wndClass2.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndClass2.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndClass2.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndClass2.hInstance = g_hInstance;
	wndClass2.lpfnWndProc = WndProcNew;
	wndClass2.lpszClassName = g_lpszClass2;
	wndClass2.lpszMenuName = NULL;
	wndClass2.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&wndClass2);

	g_hNewWnd = CreateWindow(g_lpszClass2, TEXT("���� �Է��ϼ���."),
		WS_CHILD | WS_POPUP | WS_BORDER | WS_CAPTION | WS_SYSMENU,
		WINSIZE_X / 2 - 100, WINSIZE_Y / 2 - 100, 200, 150, g_hWnd, (HMENU)0, g_hInstance, NULL);

	g_hEdit = CreateWindow("edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER,
		45, 30, 100, 20, g_hNewWnd, (HMENU)IDC_EDITBOX_TEXT, g_hInstance, NULL);

	g_button_ok = CreateWindow("button", "Ȯ��", WS_CHILD | WS_VISIBLE | WS_BORDER,
		30, 80, 50, 25, g_hNewWnd, (HMENU)IDC_EDITBOX_OK, g_hInstance, NULL);

	g_button_cancle = CreateWindow("button", "���", WS_CHILD | WS_VISIBLE | WS_BORDER,
		110, 80, 50, 25, g_hNewWnd, (HMENU)IDC_EDITBOX_CANCLE, g_hInstance, NULL);

	ShowWindow(g_hNewWnd, SW_SHOW);
}

void EditorScene::ObjectPutInMap()
{
	if (PtInRect(&editorMapPanel, g_ptMouse) && (hButtonCheck == false))
	{
		switch (buttonType)
		{
		case (int)BUTTON_TYPE::TYPE_CAMERA:
		{
			if ((cameraRect->menuCameraMouseMove == true) && (editBoxCheck == false))
			{
				cameraRect->menuCameraMouseMove = false;
				//editBoxCheck = true;

				// ������ â ����
				EditWindowCreate();
			}

			break;
		}

		case (int)BUTTON_TYPE::TYPE_ENEMY:
			for (int i = 0; i < 3; i++)
			{
				if (PtInRect(&menuEnemyRect[i], g_ptMouse))
				{
					enemyId = i;
					menuEnemyMoveBool = true;
					break;
				}
			}
			break;

		default:


			break;
		}
	}
}

void EditorScene::ObjectRectClick()
{
	switch (buttonType)
	{
	case (int)BUTTON_TYPE::TYPE_CAMERA:
		if (PtInRect(&cameraRect->menuCameraYRect, g_ptMouse))
		{
			cameraRect->menuCameraMouseMove = true;
		}
		break;

	case (int)BUTTON_TYPE::TYPE_ENEMY:
		for (int i = 0; i < 3; i++)
		{
			if (PtInRect(&menuEnemyRect[i], g_ptMouse))
			{
				enemyId = i;
				menuEnemyMoveBool = true;
				break;
			}
		}
		break;

	default:

		break;
	}
}

void EditorScene::ObjectMouseMove()
{
	switch (buttonType)
	{
	case (int)BUTTON_TYPE::TYPE_CAMERA:
		if (cameraRect->menuCameraMouseMove == true)
		{
			cameraRect->menuCameraMoveYRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y, 20, 150);
		}
		break;

	case (int)BUTTON_TYPE::TYPE_ENEMY:
		if (menuEnemyMoveBool == true)
		{
			//menuEnemyRect[enemyId];
			menuEnemyMoveRect = GetRectToCenter(g_ptMouse.x, g_ptMouse.y,
				menuEnemyRect[enemyId].right - menuEnemyRect[enemyId].left,
				menuEnemyRect[enemyId].bottom - menuEnemyRect[enemyId].top);
		}
		break;

	default:


		break;
	}
}

void EditorScene::CollisionYRect(int addValue)
{
	for (int i = 0; i < cameraRect->cameraYRectVec.size(); i++)
	{
		// ���� i��° ��Ʈ�� �浹���°� false�̰� ī�޶� ���� �ȿ� ������
		if ( (cameraRect->cameraYRectVec[i]->isCollision == false) && (CameraRectInYRect(currentPrintPos, cameraRect->cameraYRectVec[i]->rc) == true))
		{
			RECT tmpRC = { cameraRect->cameraYRectVec[i]->rc.left,
			cameraRect->cameraYRectVec[i]->rc.top,
			cameraRect->cameraYRectVec[i]->rc.right,
			cameraRect->cameraYRectVec[i]->rc.bottom };

			//�浹 ó���� �����Ѵ�.
			if (CheckRectCollision(tmpRC, player->GetPlayerCollRC()) )
			{
				cameraRect->cameraYRectVec[i]->isCollision = true;
				moveValue.push(cameraRect->cameraYRectVec[i]->value);
				cameraYMove = true;
				moveValueRate = 0;
				//currentPrintPos.y += cameraRect->cameraYRectVec[i]->value;
			}
		}
	}
}

void EditorScene::YAxisMove()
{
	if (moveValue.empty())
	{
		cameraYMove = false;
		return;
	}
	else if (moveValue.front() == 0)
	{
		moveValue.pop();
	}
	else
	{
		if (moveValue.front() < 0)
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
			}
			currentPrintPos.y -= 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate--;
		}
		else
		{
			if (moveValue.front() == moveValueRate)
			{
				moveValue.pop();
				moveValueRate = 0;
			}

			currentPrintPos.y += 300 * TimeManager::GetSingleton()->GetDeltaTime();
			moveValueRate++;
		}
	}
}

void EditorScene::Save()
{
	//Sleep(2000);
	//DWORD writtenByte;
	//OPENFILENAME saveFileDialog;
	//char szSaveFileName[MAX_PATH] = "";
	//memset(&saveFileDialog, 0, sizeof(saveFileDialog));
	//saveFileDialog.lStructSize = sizeof(saveFileDialog);
	//saveFileDialog.hwndOwner = g_hWnd;
	//saveFileDialog.lpstrFilter = "Demonic Text (*.Dtxt)\0*.Dtxt\0Text Files (*.txt)\0*txt\0All Files (*.*)\0*.*\0";
	//saveFileDialog.lpstrFile = szSaveFileName;
	//saveFileDialog.nMaxFile = MAX_PATH;
	//saveFileDialog.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	//saveFileDialog.lpstrDefExt = "Dtxt";
	//saveFileDialog.lpstrInitialDir = "";

	//if (GetSaveFileName(&saveFileDialog)) {
	//	HANDLE hFile = CreateFile(saveFileDialog.lpstrFile, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	//	//// 2��° : ���Ͽ��ٰ� ������ �������� �ּ�, 3��° : �����ּҺ��� �󸶸�ŭ ������ ���ΰ�. //tileInfo : ������ ������ �ּ�
	//	WriteFile(hFile, &(cameraRect->cameraYRectVec), sizeof(cameraRect->cameraYRectVec) * cameraRect->cameraYRectVec.size(), &writtenByte, NULL);

	//	CloseHandle(hFile); //�� ���� �ݾ��ֱ�.
	//}

	//ifstream readFromFile("Save/test.txt");

	//if (readFromFile.is_open())
	//{
	//	cameraRect->cameraYRectVec.clear();

	//	while (!readFromFile.eof())
	//	{
	//		


	//	}
	//}
	//else
	//{

	//}
}

void EditorScene::Load()
{

}

EditorScene::EditorScene()
{
}


EditorScene::~EditorScene()
{
}


LRESULT CALLBACK WndProcNew(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;

	PAINTSTRUCT ps;

	RECT rt = { 0, 0, 400, 300 };

	switch (iMessage)
	{

	case WM_COMMAND:

		switch (LOWORD(wParam))
		{

		case  IDC_EDITBOX_OK:
		{			
			GetWindowText(g_hEdit, str, 128);
			if (IsWindow(g_hNewWnd))
			{
				DestroyWindow(g_hNewWnd);
				DestroyWindow(g_hEdit);
				DestroyWindow(g_button_ok);
				DestroyWindow(g_button_cancle);
			}
			
			rectSetting = true;
		}
			break;

		case IDC_EDITBOX_CANCLE:
			if (IsWindow(g_hNewWnd))
			{
				DestroyWindow(g_hNewWnd);
				DestroyWindow(g_hEdit);
				DestroyWindow(g_button_ok);
				DestroyWindow(g_button_cancle);
			}
			break;

		default:


			break;
		}

		return 0;

		break;

	default:

		break;
	}

	return (DefWindowProc(hWnd, iMessage, wParam, lParam));
}
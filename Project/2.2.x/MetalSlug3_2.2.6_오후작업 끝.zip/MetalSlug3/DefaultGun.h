#pragma once
#include "AttackStrategy.h"

class Missile;
class DefaultGun : public AttackStrategy
{
private:
	
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;
	

public:
	virtual void Attack(FPOINT firePos, float firAngle, int heavyMissile = 0);
	void InitMissile();

	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();

	DefaultGun();
	virtual ~DefaultGun();
};

class HeavyMachinGun : public AttackStrategy
{
private:
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;

public:

	virtual void Attack(FPOINT firePos, float firAngle, int heavyMissile = 0);
	virtual void InitMissile();
	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();


	HeavyMachinGun();
	virtual ~HeavyMachinGun();
};

class FlameShotGun : public AttackStrategy
{
private:
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;

public:
	virtual void Attack(FPOINT firePos, float firAngle, int heavyMissile = 0);
	virtual void InitMissile();
	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();

	FlameShotGun();
	virtual ~FlameShotGun();
};

class RocketLauncherGun : public AttackStrategy
{
private:
	vector<Missile*> missileVec;
	stack<Missile*> missileStack;


public:
	virtual void Attack(FPOINT firePos, float firAngle, int heavyMissile = 0);
	virtual void InitMissile();
	virtual void Update();
	virtual void Render(HDC hdc);
	virtual void Release();

	RocketLauncherGun();
	virtual ~RocketLauncherGun();
};


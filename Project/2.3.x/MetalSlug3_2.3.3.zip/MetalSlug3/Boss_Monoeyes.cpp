#include "Boss_Monoeyes.h"
#include "Animation.h"
#include "Image.h"
#include "BossMissile.h"
#include "Player.h"

HRESULT Boss_Monoeyes::Init()
{
	bossImg = ImageManager::GetSingleton()->AddImage("MonoEyes", "Image/Boss/Boss_Monoeyes.bmp", 0, 0, 1190, 172, 17, 1, true, RGB(0, 251, 0));
	
	bossAni = new Animation();
	bossAni->Init(bossImg->GetWidth(), bossImg->GetHeight(), bossImg->GetFrameWidth(), bossImg->GetFrameHeight());
	bossAni->SetPlayFrame(true, true);
	nextAniTime = (FPS) / 2;
	bossAni->SetUpdateTime(nextAniTime / 2.3f);
	bossAni->Start();

	pattern = 1;

	createMissileImg = ImageManager::GetSingleton()->AddImage("B_CreateMissile", "Image/Boss/Boss_CreateMissile.bmp", 0, 0, 640, 80, 8, 1, true, RGB(248, 0, 248));
	missile1Img = ImageManager::GetSingleton()->AddImage("B_Missile1", "Image/Boss/Boss_Missile1.bmp", 0, 0, 200, 50, 4, 1, true, RGB(248, 0, 248));

	createMissileAni = new Animation();
	createMissileAni->Init(createMissileImg->GetWidth(), createMissileImg->GetHeight(), createMissileImg->GetFrameWidth(), createMissileImg->GetFrameHeight());
	createMissileAni->SetPlayFrame(false, false);
	createMissileAni->SetUpdateTime(FPS / 4);
	createMissileAni->Start();

	missile1Ani = new Animation();
	missile1Ani->Init(missile1Img->GetWidth(), missile1Img->GetHeight(), missile1Img->GetFrameWidth(), missile1Img->GetFrameHeight());
	missile1Ani->SetPlayFrame(false, false);
	missile1Ani->SetUpdateTime(FPS / 2);
	

	pos = { 400, 200 };
	isReverseRender = false;
	isPosRight = true;
	scale = 1.7f;
	speed = (300.0f / 8) / bossAni->GetKeyFrameUpdateTime();
	isCreateMissileAni = false;
	isMissileAni = false;

	life = 1000;

	
	isFire = false;

	bossMissile = new BossMissile[5];

	for(int i = 0 ; i < 5 ; i++)
		bossMissile[i].Init();


	return S_OK;
}

void Boss_Monoeyes::Release()
{
	if (bossAni)
		SAFE_DELETE(bossAni);

	if (missile1Ani)
		SAFE_DELETE(missile1Ani);

	if (createMissileAni)
		SAFE_DELETE(createMissileAni);

	for (int i = 0; i < 5; i++)
	{
		if (bossMissile) 
		{
			bossMissile[i].Release();
			SAFE_ARR_DELETE(bossMissile);
		}
	}
}

void Boss_Monoeyes::Update()
{
	if (bossAni)
	{
		switch (pattern)
		{
		case 0:

			Pattern0();

			break;

		case 1:

			Pattern1();

			break;

		case 2:

			Pattern2();

			break;

		}
		
	}

	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == true)
		{
			bossMissile[i].Update();
		}
	}
}

void Boss_Monoeyes::Render(HDC hdc)
{
	if (bossImg)
	{
		switch (pattern)
		{
		case 0:

			break;

		case 1:

			if (isReverseRender == false)
				bossImg->AnimationRender(hdc, relativePos.x, relativePos.y, bossAni, scale);
			else
				bossImg->AnimationReverseRender(hdc, relativePos.x, relativePos.y, bossAni, scale);

			break;

		case 2:

			Pattern2();

			break;

		}
	
	}

	if (createMissileImg && isCreateMissileAni == true)
		createMissileImg->AnimationRender(hdc, relativePos.x, relativePos.y, createMissileAni, 2.0f);

	if (missile1Img && isMissileAni == true)
		missile1Img->AnimationRender(hdc, relativePos.x, relativePos.y, missile1Ani, 2.0f);
	
	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == true)
		{
			bossMissile[i].Render(hdc);
		}
	}
}

void Boss_Monoeyes::Pattern0()
{

}

void Boss_Monoeyes::Pattern1()
{
	bossAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
					pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	if (bossAni->GetNowPlayIdx() == 0)
	{
		isCreateMissileAni = true;
		createMissileAni->Start();
		isReverseRender = false;
	}
	else if (bossAni->GetNowPlayIdx() == 16)
	{
		isReverseRender = true;
		createMissileAni->Start();
		isCreateMissileAni = true;
	}

	if (isReverseRender == false)
	{
		if (isPosRight == true)
		{
			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		else
			pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else
	{
		if (isPosRight == true)
		{
			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		else
			pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}

	if (relativePos.x >= 700)
		isPosRight = false;
	else if (relativePos.x <= 100)
		isPosRight = true;

	if (isReverseRender == false)
		scale = 1.5f + 0.05 * (bossAni->GetNowPlayIdx() % 16);
	else
		scale = 2.3f - 0.05 * (bossAni->GetNowPlayIdx() % 16);

	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == false)
		{
			if (createMissileAni && isCreateMissileAni == true)
			{
				createMissileAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
				if (createMissileAni->GetNowPlayIdx() == createMissileAni->GetFrameCount() - 1)
				{
					isCreateMissileAni = false;
					isMissileAni = true;
					missile1Ani->Start();
				}
			}

			if (missile1Ani && isMissileAni == true)
			{
				missile1Ani->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

				if (missile1Ani->GetNowPlayIdx() == missile1Ani->GetFrameCount() - 1)
				{
					bossMissile[i].SetIsFire(true);
					bossMissile[i].SetAngle(atan2f(-(DataCollector::GetSingleton()->GetPlayer()->GetPlayerPos().y - pos.y), DataCollector::GetSingleton()->GetPlayer()->GetPlayerPos().x - pos.x));
					bossMissile[i].SetPos({ pos.x, pos.y });
					isMissileAni = false;
				}
			}

			continue;
		}
	}


	
}
void Boss_Monoeyes::Pattern2()
{
}
Boss_Monoeyes::Boss_Monoeyes()
{
}


Boss_Monoeyes::~Boss_Monoeyes()
{
}

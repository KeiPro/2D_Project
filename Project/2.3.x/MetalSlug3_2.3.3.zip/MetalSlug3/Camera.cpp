#include "Camera.h"
#include "Player.h"

void Camera::Init(int _addValue)
{
	addValue = _addValue;
	disBaseLineToPlayer = 0;
	speed = 7;

	//baseLineTop = { GAME_SIZE_X / 3, 0 };
	//baseLineBottom = { GAME_SIZE_X / 3, GAME_SIZE_Y };

	baseLineTop = { DataCollector::GetSingleton()->GetEditorAddValue() + 300, 0 };
	baseLineBottom = { DataCollector::GetSingleton()->GetEditorAddValue() + 300, GAME_SIZE_Y };

	color = RGB(255, 0, 0);
	hPen = CreatePen(PS_SOLID, 2, color);
}

void Camera::Render(HDC hdc, int currentY)
{
	hOldPen = (HPEN)SelectObject(hdc, hPen);
	MoveToEx(hdc, baseLineTop.x, baseLineTop.y , NULL);
	LineTo(hdc, baseLineBottom.x, baseLineBottom.y );
	SelectObject(hdc, hOldPen);
}

HRESULT Camera::Init()
{
	return S_OK;
}

void Camera::Release()
{
	DeleteObject(hPen);
}

void Camera::Update()
{
	if (player->GetPlayerRelativePos().x > baseLineTop.x + 5)
	{
		disBaseLineToPlayer = player->GetPlayerRelativePos().x - baseLineTop.x;
		cameraSpeed = (disBaseLineToPlayer * speed * TimeManager::GetSingleton()->GetDeltaTime());
		//player->SetPlayerPosX((player->GetPlayerPos().x) - (int)cameraSpeed);

		goUICount = 0;
		DataCollector::GetSingleton()->SetIsGoUIOn(false);
	}
	else
	{
		if (DataCollector::GetSingleton()->GetCurrentPrintPos().x == 14000)
			return;

		goUICount += TimeManager::GetSingleton()->GetDeltaTime();

		if (goUICount > 5)
		{
			DataCollector::GetSingleton()->SetIsGoUIOn(true);
		}

		cameraSpeed = 0;
	}
}

Camera::Camera()
{
}


Camera::~Camera()
{
}

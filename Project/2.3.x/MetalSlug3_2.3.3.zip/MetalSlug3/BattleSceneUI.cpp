#include "BattleSceneUI.h"
#include "GoUI.h"
#include "UI_MissileType.h"
#include "UI_Timer.h"
#include "FontUI.h"


HRESULT BattleSceneUI::Init()
{
	goUI = new GoUI();
	goUI->Init();

	uiMissileType = new UI_MissileType();
	uiMissileType->Init();

	uiTimer = new UI_Timer();
	uiTimer->Init();

	fontUI = new FontUI();
	fontUI->Init();

	return S_OK;
}

void BattleSceneUI::Release()
{
	if (goUI)
	{
		goUI->Release();
		SAFE_DELETE(goUI);
	}

	if (uiMissileType)
	{
		uiMissileType->Release();
		SAFE_DELETE(uiMissileType);
	}

	if (uiTimer)
	{
		uiTimer->Release();
		SAFE_DELETE(uiTimer);
	}

	if (fontUI)
	{
		fontUI->Release();
		SAFE_DELETE(fontUI);
	}
}

void BattleSceneUI::Update()
{
	if (goUI && DataCollector::GetSingleton()->GetIsGoUIOn() == true)
	{
		goUI->Update();
	}

	if (uiMissileType)
		uiMissileType->Update();

	if (uiTimer)
		uiTimer->Update();

	if (fontUI)
		fontUI->Update();
}

void BattleSceneUI::Render(HDC hdc)
{
	if (goUI && DataCollector::GetSingleton()->GetIsGoUIOn() == true)
	{
		goUI->Render(hdc);
	}

	if (uiMissileType)
		uiMissileType->Render(hdc);

	if (uiTimer)
		uiTimer->Render(hdc);

	if (fontUI)
		fontUI->Render(hdc);
}

BattleSceneUI::BattleSceneUI()
{
}


BattleSceneUI::~BattleSceneUI()
{
}

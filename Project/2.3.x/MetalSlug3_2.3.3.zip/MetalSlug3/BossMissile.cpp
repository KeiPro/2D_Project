#include "BossMissile.h"
#include "Animation.h"
#include "Image.h"

HRESULT BossMissile::Init()
{
	missile1Img = ImageManager::GetSingleton()->FindImage("B_Missile1");

	pos = { 0, 0 };
	speed = 1000.0f;
	angle = 0.0f;
	damage = 1;
	rc = { 0, 0, 0, 0 };
	isFire = false;

	return S_OK;
}

void BossMissile::Release()
{

}

void BossMissile::Update()
{
	if (isFire == true)
	{
		pos.x += speed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
	}


	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	rc = GetRectToCenter(relativePos.x, relativePos.y, 40, 40);
}

void BossMissile::Render(HDC hdc)
{
	Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

	if (missile1Img)
		missile1Img->FrameRender(hdc, relativePos.x, relativePos.y, 3, 0, 2.0f);
}

BossMissile::BossMissile()
{

}


BossMissile::~BossMissile()
{
}

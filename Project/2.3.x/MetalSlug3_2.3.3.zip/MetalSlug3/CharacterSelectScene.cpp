#include "CharacterSelectScene.h"



HRESULT CharacterSelectScene::Init()
{
	//characterSelectImg ImageManager::GetSin
	//ImageManager::GetSingleton()->AddImage();


	return S_OK;
}

void CharacterSelectScene::Release()
{
}

void CharacterSelectScene::Update()
{
}

void CharacterSelectScene::Render(HDC hdc)
{
}

CharacterSelectScene::CharacterSelectScene()
{
}


CharacterSelectScene::~CharacterSelectScene()
{
}

#include "FontUI.h"
#include "Image.h"
#include "Player.h"

HRESULT FontUI::Init()
{
	image = ImageManager::GetSingleton()->AddImage("Life", "Image/UI/Life.bmp", 102, 32, true, RGB(255, 204, 204));
	lifeImg = ImageManager::GetSingleton()->FindImage("UI_Number");
		
	pos = { 50, 30 };

	return S_OK;
}

void FontUI::Release()
{
}

void FontUI::Update()
{
	
}

void FontUI::Render(HDC hdc)
{
	if (image)
		image->Render(hdc, pos.x + image->GetWidth() / 2, pos.y + image->GetHeight() / 2);

	if (lifeImg)
		lifeImg->FrameRender(hdc, pos.x + 140, pos.y + 16, DataCollector::GetSingleton()->GetPlayer()->GetLife(), 0);

}

FontUI::FontUI()
{
}


FontUI::~FontUI()
{
}

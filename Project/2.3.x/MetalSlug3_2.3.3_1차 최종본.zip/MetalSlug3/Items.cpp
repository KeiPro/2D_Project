#include "Items.h"
#include "Image.h"
#include "Player.h"

HRESULT Items::Init(FPOINT _pos)
{
	return S_OK;
}

void Items::Release()
{
}

void Items::Update()
{
}

void Items::Render(HDC hdc)
{
}

Items::Items()
{
}


Items::~Items()
{
}

HRESULT HeavyMissileItems::Init(FPOINT _pos)
{
	missileType = MissileType::Player_Heavy;
	image = ImageManager::GetSingleton()->AddImage("MissileItem", "Image/Items/MissileType.bmp", 0, 0, 66, 20, 3, 1, true, RGB(0, 251, 0));
	//pos = { 400, 500 };
	pos = _pos;
	
	isColl = false;
	
	return S_OK;
}

void HeavyMissileItems::Release()
{
}

void HeavyMissileItems::Update()
{
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() -
	DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	rc = GetRectToCenter(relativePos.x, relativePos.y, 60, 60);

	if (isColl == false && CheckRectCollision(DataCollector::GetSingleton()->GetPlayer()->GetRC(), rc))
	{
		isColl = true;
		DataCollector::GetSingleton()->GetPlayer()->SetGunState(GunState::HEAVY);
		DataCollector::GetSingleton()->SetGunState(GunState::HEAVY);
	}
}

void HeavyMissileItems::Render(HDC hdc)
{
	if (image && isColl == false)
		image->FrameRender(hdc, relativePos.x, relativePos.y, 0, 0, 2.5f);
}

HRESULT FlameMissileItems::Init(FPOINT _pos)
{
	missileType = MissileType::Player_Flame;
	image = ImageManager::GetSingleton()->AddImage("MissileItem", "Image/Items/MissileType.bmp", 0, 0, 66, 20, 3, 1, true, RGB(0, 251, 0));
	//pos = { 400, 500 };
	pos = _pos;

	isColl = false;


	return S_OK;
}

void FlameMissileItems::Release()
{
}

void FlameMissileItems::Update()
{
	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() -
	DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	rc = GetRectToCenter(relativePos.x, relativePos.y, 60, 60);

	if (isColl == false && CheckRectCollision(DataCollector::GetSingleton()->GetPlayer()->GetRC(), rc))
	{
		isColl = true;
		DataCollector::GetSingleton()->GetPlayer()->SetGunState(GunState::FLAME);
		DataCollector::GetSingleton()->SetGunState(GunState::FLAME);
	}
}

void FlameMissileItems::Render(HDC hdc)
{
	if (image && isColl == false)
		image->FrameRender(hdc, relativePos.x, relativePos.y, 1, 0, 2.5f);
}

HRESULT RocketMissileItems::Init(FPOINT _pos)
{
	missileType = MissileType::Player_Rocket;
	image = ImageManager::GetSingleton()->AddImage("MissileItem", "Image/Items/MissileType.bmp", 0, 0, 66, 20, 3, 1, true, RGB(0, 251, 0));

	pos = _pos;

	return S_OK;
}

void RocketMissileItems::Release()
{
}

void RocketMissileItems::Update()
{
}

void RocketMissileItems::Render(HDC hdc)
{
}

#include "Missile.h"
#include "Image.h"
#include "Animation.h"

HRESULT Missile::Init()
{

	return S_OK;
}

void Missile::Release()
{
}

void Missile::Update()
{

}

void Missile::Render(HDC hdc)
{
}

Missile::Missile()
{
}


Missile::~Missile()
{

}


//�⺻ �̻���
HRESULT DefaultMissile::Init()
{
	missileImg = ImageManager::GetSingleton()->AddImage("DefaultMissile", "Image/Missile/DefaultBullet.bmp", 9, 5, true, RGB(0, 248, 0));
	//pixelCollEffImg = ImageManager::GetSingleton()->AddImage("bullet_Coll", "Image/Missile/bullet_Coll.bmp", 0, 0, 160, 27, 10, true, RGB(115, 155, 115));

	//Object::SetMissile(this);
	//Object::Init(PixelColl_ID::BULLET);

	//pixelCollEffAni = new Animation();
	//pixelCollEffAni->Init(pixelCollEffImg->GetWidth(), pixelCollEffImg->GetHeight(), pixelCollEffImg->GetFrameWidth(), pixelCollEffImg->GetFrameHeight());
	//pixelCollEffAni->SetPlayFrame(false, false);
	//pixelCollEffAni->SetUpdateTime(FPS);
	//�Ʒ����� ��ŸƮ �ϰ��־ ���⿡ ��ŸƮ �ȳ���.

	pos = {0, 0};
	speed = 1000.0f;
	angle = 0.0f;
	damage = 1;
	rc = { 0, 0, 0, 0 };
	isFire = false;

	return S_OK;
}

void DefaultMissile::Release()
{
	//if (pixelCollEffAni)
	//{
	//	SAFE_DELETE(pixelCollEffAni);
	//}

	//Object::Release();
}

void DefaultMissile::Update()
{
	if (missileImg && isFire/* && isCollision == false*/)
	{
		pos.x += speed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
	}

	//if (pixelCollEffAni && (isCollision == true) )
	//{
	//	pixelCollEffAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

	//	if (pixelCollEffAni->GetNowPlayIdx() == pixelCollEffAni->GetFrameCount() - 1)
	//		isCollision = false;
	//}
	//	

	rc = GetRectToCenter(pos.x + 7, pos.y + 3, 20, 20);

	//Object::Update();
}

void DefaultMissile::Render(HDC hdc)
{
	//Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

	if (missileImg && isFire)
	{
		if (missileImg)
			missileImg->Render(hdc, pos.x, pos.y, 2.0f);
	}

	//if (pixelCollEffImg)
	//{
	//	if(isCollision == true)
	//		pixelCollEffImg->AnimationRender(hdc, pos.x, pos.y, pixelCollEffAni, 1.0f);
	//}
}

//void DefaultMissile::EffectStart()
//{
//	pixelCollEffAni->Start();
//}


//��� �ӽŰ� �̻���
HRESULT HeavyMissile::Init()
{
	missileImg = ImageManager::GetSingleton()->AddImage("HeavyMissile", "Image/Missile/HeavyBullet.bmp", 33, 12, true, RGB(0, 248, 0));
	heavyUpImg = ImageManager::GetSingleton()->AddImage("HeavyUpMissile", "Image/Missile/HeavyBullet_Up.bmp", 12, 33, true, RGB(0, 248, 0));
	heavyDownImg = ImageManager::GetSingleton()->AddImage("HeavyDownMissile", "Image/Missile/HeavyBullet_Down.bmp", 12, 33, true, RGB(0, 248, 0));
	
	pos = { 0, 0 };
	speed = 1000.0f;
	angle = 0.0f;
	damage = 2;
	rc = { 0, 0, 0, 0 };
	isFire = false;

	return S_OK;
}

void HeavyMissile::Release()
{
}

void HeavyMissile::Update()
{
	if (missileImg && isFire)
	{
		pos.x += speed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
	}

	if (angle == 0.0f)
		rc = GetRectToCenter(pos.x + 20, pos.y + 20, 40, 20);
	else if (angle == 90.0f)
		rc = GetRectToCenter(pos.x + 15, pos.y + 20, 20, 50);
	else if (angle == 180.0f)
		rc = GetRectToCenter(pos.x, pos.y + 20, 40, 20);
	else if (angle == 270.0f)
		rc = GetRectToCenter(pos.x + 15, pos.y + 20, 20, 50);
}

void HeavyMissile::Render(HDC hdc)
{
	//Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

	if (missileImg && isFire)
	{
		if (missileImg)
		{
			if (angle == 0.0f)
				missileImg->Render(hdc, pos.x, pos.y, 2.5f);
			else if (angle == 90.0f)
				heavyUpImg->Render(hdc, pos.x, pos.y, 2.5f);
			else if (angle == 180.0f)
				missileImg->ReverseRender(hdc, pos.x - 10, pos.y + 20, 0, 0, missileImg->GetWidth(), missileImg->GetHeight(), 2.5f);
			else if (angle == 270.0f)
				heavyDownImg->Render(hdc, pos.x, pos.y, 2.5f);
		}
	}
}

//�÷��� �� �̻���
HRESULT FlameMissile::Init()
{
	missileImg = ImageManager::GetSingleton()->AddImage("FlameMissile", "Image/Missile/FlameShot.bmp", 0, 0, 720, 320, 9, 4, true, RGB(0, 248, 0) );
	ani = new Animation();
	ani->Init(missileImg->GetWidth(), missileImg->GetHeight(), missileImg->GetFrameWidth(), missileImg->GetFrameHeight());
	ani->SetPlayFrame(false, false);
	ani->SetUpdateTime(FPS);
	ani->Start();

	pos = { 0, 0 };
	speed = 500.0f;
	angle = 0.0f;
	damage = 20;
	rc = { 0, 0, 0, 0 };
	isFire = false;


	return S_OK;
}

void FlameMissile::Release()
{
	if (ani)
		SAFE_DELETE(ani);
}

void FlameMissile::Update()
{
	if (missileImg && isFire)
	{
		pos.x += speed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= 2.0f;
		speed -= 20;

		ani->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}

	rc = GetRectToCenter(pos.x + 20, pos.y + 20, 100, 100);
}

void FlameMissile::Render(HDC hdc)
{
	//Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

	if (missileImg && isFire)
	{
		if (missileImg)
		{
			if (angle == 0.0f)
				missileImg->AnimationRender(hdc, pos.x, pos.y, ani, 3.0f);
			else if(angle == 90.0f)
				missileImg->AnimationRender(hdc, pos.x, pos.y, ani, 3.0f);
			else if ( angle == 180.0f )
				missileImg->AnimationReverseRender(hdc, pos.x, pos.y, ani, 3.0f);
			else if( angle == 270.0f)
				missileImg->AnimationRender(hdc, pos.x, pos.y, ani, 3.0f);
		}
	}
}


//���� ���� �̻���
HRESULT RocketMissile::Init()
{
	missileImg = ImageManager::GetSingleton()->AddImage("RocketMissile", "Image/Missile/RocketBullet.bmp", 55, 18, true, RGB(0, 248, 0));

	pos = { 0, 0 };
	speed = 1000.0f;
	angle = 0.0f;
	damage = 5;
	rc = { 0, 0, 0, 0 };
	isFire = false;

	t = 0;

	cpData0[0] = { DataCollector::GetSingleton()->GetEditorAddValue() + GAME_SIZE_X / 2.0f , GAME_SIZE_Y / 2.0f - 20 };
	cpData0[1] = { DataCollector::GetSingleton()->GetEditorAddValue() + GAME_SIZE_X / 2.0f , GAME_SIZE_Y / 2.0f + 20 };
	cpData0[2] = { DataCollector::GetSingleton()->GetEditorAddValue() + GAME_SIZE_X / 3.0f , GAME_SIZE_Y / 2.0f + 20 };

	cpData1[0] = { 0.0f, GAME_SIZE_Y };
	cpData1[1] = { GAME_SIZE_X, GAME_SIZE_Y };
	cpData1[2] = { GAME_SIZE_X / 2.0f, GAME_SIZE_Y / 2.0f};

	/*cp[0] = {};*/
	//cp[0] = {  };
	//cp[1] = { 0.0f, GAME_SIZE_Y };

	cp[2] = { DataCollector::GetSingleton()->GetEditorAddValue() + (float)GAME_SIZE_X, (float)GAME_SIZE_Y - 200 };



	return S_OK;
}

void RocketMissile::Release()
{
}

void RocketMissile::Update()
{
	if (missileImg && isFire)
	{
		if (t < 1)
		{
			t += TimeManager::GetSingleton()->GetDeltaTime() * 0.6f;
		}
		else
		{
			t = 1;
		}

		cp[0] = cpData0[randX];
		cp[1] = cpData1[randY];

		pos.x = pos.x * pow((1 - t), 3) + 3 * cp[0].x * t * pow((1 - t), 2) + 3 * cp[1].x * pow(t, 2) * (1 - t) + cp[2].x *  pow(t, 3);
		pos.y = pos.y * pow((1 - t), 3) + 3 * cp[0].y * t * pow((1 - t), 2) + 3 * cp[1].y * pow(t, 2) * (1 - t) + cp[2].y *  pow(t, 3);

		//cp[2].x -= 2;
		//cp[2].y += 2;

		/*pos.x += speed * cosf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();
		pos.y -= speed * sinf(DEGREE_TO_RADIAN(angle)) * TimeManager::GetSingleton()->GetDeltaTime();*/
	}
}

void RocketMissile::Render(HDC hdc)
{
	if (missileImg && isFire)
	{
		if (missileImg)
		{
			if (angle == 0.0f)
				missileImg->Render(hdc, pos.x, pos.y - 10, 2.3f);
			else if ( angle == 180.0f )
				missileImg->ReverseRender(hdc, pos.x - 20, pos.y + 5, 0, 0, missileImg->GetWidth(), missileImg->GetHeight(), 2.3f);
		}
	}
}
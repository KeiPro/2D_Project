#include "DefaultGun.h"
#include "Image.h"
#include "Missile.h"
#include "Animation.h"
#include "EnemyMgr.h"
#include "Boss_Monoeyes.h"

void DefaultGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* defaultMissile = missileStack.top();
		defaultMissile->SetIsFire(true);
		defaultMissile->SetPos(firePos);
		defaultMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(defaultMissile);
	}
}

void DefaultGun::InitMissile()
{
	Missile* tmpMissile;

	while (missileVec.size() != 0)
	{
		tmpMissile = missileVec.back();
		tmpMissile->SetIsFire(false);
		missileStack.push(tmpMissile);
		missileVec.pop_back();
	}
}

void DefaultGun::Update()
{
	for (vector<Missile*>::iterator m_it = missileVec.begin(); m_it != missileVec.end(); m_it++)
	{
		(*m_it)->Update();

		if ((*m_it)->GetPos().x >= GAME_SIZE_X || (*m_it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10 ||
			(*m_it)->GetPos().y <= -50 || (*m_it)->GetPos().y >= GAME_SIZE_Y + 50)
		{
			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);

			if (m_it == missileVec.end())
				break;
		}

		if (CheckRectCollision((*m_it)->GetRect(), DataCollector::GetSingleton()->GetBossMonoeye()->GetRect()))
		{
			DataCollector::GetSingleton()->GetBossMonoeye()
				->SetLife(DataCollector::GetSingleton()->GetBossMonoeye()->GetLife() - (*m_it)->GetDamage());

			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);

			if (m_it == missileVec.end())
				break;
		}

		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetBrainEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());
					it->EffectStarting(rand() % 3);

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;

		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetFatEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());
					it->EffectStarting(rand() % 3);

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;
	}
}

void DefaultGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void DefaultGun::Release()
{
	missileVec.clear();

	vector<Missile *>().swap(missileVec);
}

//�⺻ �Ѿ��� 50������ ����.
DefaultGun::DefaultGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		DefaultMissile* defaultMissile = new DefaultMissile();
		defaultMissile->Init();
		missileStack.push(defaultMissile);
	}
}


DefaultGun::~DefaultGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void HeavyMachinGun::Attack(FPOINT firePos, float fireAngle, int _heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* heavyMissile = missileStack.top();
		heavyMissile->SetIsFire(true);
		switch (_heavyMissile)
		{
			case 0: heavyMissile->SetPos({ firePos.x, firePos.y - 20 }); break;
			case 1: heavyMissile->SetPos({ firePos.x, firePos.y - 15}); break;
			case 2: heavyMissile->SetPos({ firePos.x, firePos.y  }); break;
		}
		
		heavyMissile->SetAngle(fireAngle);

		missileStack.pop();
		missileVec.push_back(heavyMissile);
	}
}

void HeavyMachinGun::InitMissile()
{
	Missile* tmpMissile;

	while (missileVec.size() != 0)
	{
		tmpMissile = missileVec.back();
		tmpMissile->SetIsFire(false);
		missileStack.push(tmpMissile);
		missileVec.pop_back();
	}
}

void HeavyMachinGun::Update()
{
	for (vector<Missile*>::iterator m_it = missileVec.begin(); m_it != missileVec.end(); m_it++)
	{
		(*m_it)->Update();

		if ((*m_it)->GetPos().x >= GAME_SIZE_X || (*m_it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10 ||
			(*m_it)->GetPos().y <= -50 || (*m_it)->GetPos().y >= GAME_SIZE_Y + 50)
		{
			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);

			if (m_it == missileVec.end())
				break;
		}

		if (CheckRectCollision((*m_it)->GetRect(), DataCollector::GetSingleton()->GetBossMonoeye()->GetRect()))
		{
			DataCollector::GetSingleton()->GetBossMonoeye()
				->SetLife(DataCollector::GetSingleton()->GetBossMonoeye()->GetLife() - (*m_it)->GetDamage());

			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);

			if (m_it == missileVec.end())
				break;
		}


		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetBrainEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());
					it->EffectStarting(rand() % 3);

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;


		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetFatEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());
					it->EffectStarting(rand() % 3);

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;
	}
}

void HeavyMachinGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void HeavyMachinGun::Release()
{
	missileVec.clear();

	vector<Missile *>().swap(missileVec);
}

HeavyMachinGun::HeavyMachinGun()
{
	missileVec.reserve(50);

	for (int i = 0; i < 50; i++)
	{
		HeavyMissile* heavyMissile = new HeavyMissile();
		heavyMissile->Init();
		missileStack.push(heavyMissile);
	}

	//collision = DataCollector::GetSingleton()->GetCollision();
	//collision->SetHeavyMissile(&missileVec);
	//collision->SetHeavyStack(&missileStack);
}

HeavyMachinGun::~HeavyMachinGun()
{
	for (int i = 0; i < 50; i++)
	{
		if (missileStack.empty()) break;

		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void FlameShotGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		Missile* flameMissile = missileStack.top();
		flameMissile->SetIsFire(true);
		flameMissile->SetPos(firePos);
		flameMissile->SetAngle(fireAngle);
		missileStack.pop();
		missileVec.push_back(flameMissile);
	}
}

void FlameShotGun::InitMissile()
{
	Missile* tmpMissile;

	while (missileVec.size() != 0)
	{
		tmpMissile = missileVec.back();
		tmpMissile->SetIsFire(false);
		missileStack.push(tmpMissile);
		missileVec.pop_back();
	}
}

void FlameShotGun::Update()
{
	for (vector<Missile*>::iterator m_it = missileVec.begin(); m_it != missileVec.end(); m_it++)
	{
		(*m_it)->Update();

		if (CheckRectCollision((*m_it)->GetRect(), DataCollector::GetSingleton()->GetBossMonoeye()->GetRect()))
		{
			if (DataCollector::GetSingleton()->GetBossMonoeye()->GetIsFlameColl() == false)
			{
				DataCollector::GetSingleton()->GetBossMonoeye()->SetIsFlameColl(true);

				DataCollector::GetSingleton()->GetBossMonoeye()
					->SetLife(DataCollector::GetSingleton()->GetBossMonoeye()->GetLife() - (*m_it)->GetDamage());
			}
		}

		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetBrainEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
						it->SetFlameDie(true);
					}
					break;
				}
			}
		}

		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetFatEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
						it->SetFlameDie(true);
					}
					break;
				}
			}
		}

		FlameMissile* _flameMissile = (FlameMissile*)(*m_it);

		// �ִϸ��̼� ������ �����ӱ��� �������� ��� Stack�� �ٽ� �����Ѵ�.
		if (_flameMissile->GetAni()->GetNowPlayIdx() == _flameMissile->GetAni()->GetFrameCount() - 1)
		{
			_flameMissile->GetAni()->Start();
			_flameMissile->SetSpeed(500.0f);
			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);
		}

		if (m_it == missileVec.end())
			break;
	}
}

void FlameShotGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void FlameShotGun::Release()
{
	missileVec.clear();

	vector<Missile *>().swap(missileVec);
}

FlameShotGun::FlameShotGun()
{
	missileVec.reserve(10);

	for (int i = 0; i < 10; i++)
	{
		FlameMissile* flameMissile = new FlameMissile();
		flameMissile->Init();
		missileStack.push(flameMissile);
	}

	//collision = DataCollector::GetSingleton()->GetCollision();
	//collision->SetFlameMissile(&missileVec);
	//collision->SetFlameStack(&missileStack);
}

FlameShotGun::~FlameShotGun()
{
	for (int i = 0; i < 10; i++)
	{
		if (missileStack.empty()) break;
		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

void RocketLauncherGun::Attack(FPOINT firePos, float fireAngle, int heavyMissile)
{
	if (!missileStack.empty())
	{
		RocketMissile* rocketMissile = (RocketMissile *)(missileStack.top());
		rocketMissile->SetIsFire(true);
		rocketMissile->SetPos(firePos);
		rocketMissile->SetAngle(fireAngle);
		rocketMissile->SetTime(0);
		rocketMissile->SetRandX(rand()%3);
		rocketMissile->SetRandY(rand()%3);

		rocketMissile->SetId();
		missileStack.pop();
		missileVec.push_back(rocketMissile);
	}
}

void RocketLauncherGun::InitMissile()
{
	//for (vector<Missile*>::iterator it = missileVec.begin(); it != missileVec.end(); it++)
	//{
	//	Missile* tmpMissile = *it;
	//	(*it)->SetIsFire(false);
	//	missileStack.push(tmpMissile);
	//	it = missileVec.erase(it);

	//	//if (it == missileVec.end())
	//	//	break;
	//}
	Missile* tmpMissile;

	while (missileVec.size() != 0)
	{
		tmpMissile = missileVec.back();
		tmpMissile->SetIsFire(false);
		missileStack.push(tmpMissile);
		missileVec.pop_back();
	}
}

void RocketLauncherGun::Update()
{
	for (vector<Missile*>::iterator m_it = missileVec.begin(); m_it != missileVec.end(); m_it++)
	{
		(*m_it)->Update();

		if ((*m_it)->GetPos().x >= GAME_SIZE_X || (*m_it)->GetPos().x <= DataCollector::GetSingleton()->GetEditorAddValue() - 10 ||
			(*m_it)->GetPos().y <= -50 || (*m_it)->GetPos().y >= GAME_SIZE_Y + 50)
		{
			Missile* tmpMissile = *m_it;
			(*m_it)->SetIsFire(false);
			missileStack.push(tmpMissile);
			m_it = missileVec.erase(m_it);

			if (m_it == missileVec.end())
				break;
		}


		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetBrainEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
						it->SetFlameDie(true);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;

		for (auto& it : *((DataCollector::GetSingleton()->GetEnemyMgr())->GetFatEnemyVec()))
		{
			if ((it)->GetPos().x < DataCollector::GetSingleton()->GetCurrentPrintPos().x + GAME_SIZE_X + 150
				&& (it)->GetPos().x > DataCollector::GetSingleton()->GetCurrentPrintPos().x - 100)
			{
				if ((it->GetIsAlive() == true) && CheckRectCollision((*m_it)->GetRect(), it->GetRect()))
				{
					it->SetHp(it->GetHp() - (*m_it)->GetDamage());
					it->EffectStarting(rand() % 3);

					if (it->GetHp() <= 0)
					{
						it->SetAlive(false);
					}

					Missile* tmpMissile = *m_it;
					(*m_it)->SetIsFire(false);
					missileStack.push(tmpMissile);
					m_it = missileVec.erase(m_it);

					break;
				}
			}
		}

		if (m_it == missileVec.end())
			break;
	}
}

void RocketLauncherGun::Render(HDC hdc)
{
	for (auto& it : missileVec)
	{
		it->Render(hdc);
	}
}

void RocketLauncherGun::Release()
{
	missileVec.clear();

	vector<Missile *>().swap(missileVec);
}

RocketLauncherGun::RocketLauncherGun()
{
	missileVec.reserve(30);

	for (int i = 0; i < 30; i++)
	{
		RocketMissile* rocketMissile = new RocketMissile();
		rocketMissile->Init();
		missileStack.push(rocketMissile);
	}

	//collision = DataCollector::GetSingleton()->GetCollision();
	//collision->SetRocketMissile(&missileVec);
	//collision->SetRocketStack(&missileStack);

}

RocketLauncherGun::~RocketLauncherGun()
{
	for (int i = 0; i < 30; i++)
	{
		if (missileStack.empty()) break;
		missileStack.pop();
	}

	missileVec.clear();
	vector<Missile*>().swap(missileVec);
}

﻿#pragma once

#include <iostream>
#include <Windows.h>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <stack>
#include <string>
#include <ctime>
//#include <list>

using namespace std;

#include "KeyManager.h"
#include "ImageManager.h"
#include "TimeManager.h"
#include "SoundManager.h"
#include "SceneManager.h"


//#ifdef UNICODE
//#pragma comment(linker, "/entry:wWinMainCRTStartup /subsystem:console")
//#else
//#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")
//#endif

// enum, struct, .h, #define
//enum BOX
//{
//	BOX_First,
//	BOX_Second,
//	BOX_End
//};

typedef struct tagFPOINT
{
	float x;
	float y;
} FPOINT, *PFPOINT;

//typedef struct tagArguments
//{
//	const char* sceneName;
//	const char* loadingName;
//
//} ARGUMENT_INFO;

typedef struct SET_RECT_INFO
{
	RECT rc;
	int value;
	bool isCollision;
}RECT_INFO;

enum class PlayerState
{
	Start,
	Idle,
	Walk,
	Shooting,
	Idle_Jump,
	Up,
	Jump_Down,
	Shooting_Up,
	Shooting_Down
};

enum class PlayerLookDir
{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	LEFT_UP,
	LEFT_DOWN,	
	RIGHT_UP,
	RIGHT_DOWN
};

enum class EnemyState
{
	START,
	IDLE,
	WALK,
	ATTACK,
	DIE,
	FLAME_DIE
};

enum class EnemyLookDir
{
	LEFT,
	RIGHT
};

enum class GunState
{
	DEFAULT,
	HEAVY,
	FLAME,
	ROCKET
};

enum class PixelColl_ID
{
	PLAYER,
	ENEMY,
	NPC,
	BULLET
};

enum class MissileType
{
	Player_Default,
	Player_Heavy,
	Player_Flame,
	Player_Rocket,
	Enemy_Default
};

#define FPS			30.0f
#define WINSIZE_X	GetSystemMetrics(SM_CXSCREEN)
#define WINSIZE_Y	GetSystemMetrics(SM_CYSCREEN)
#define WINSTART_X	0
#define WINSTART_Y	0
#define GAME_SIZE_X 800
#define GAME_SIZE_Y 600

#define WINSIZE_TILE_MAP_X	GetSystemMetrics(SM_CXSCREEN)
#define WINSIZE_TILE_MAP_Y	GetSystemMetrics(SM_CYSCREEN)

#define PI			3.141592

#define SAFE_DELETE(p)		{ if (p) { delete p; p = NULL; }}
#define SAFE_ARR_DELETE(p)	{ if (p) { delete [] p; p = NULL; }}

#define DEGREE_TO_RADIAN(x)	( x * PI / 180 )
#define RADIAN_TO_DEGREE(x) (int)( x * 180 / PI )

#define IDC_EDITBOX_TEXT 1000
#define IDC_EDITBOX_OK 100
#define IDC_EDITBOX_CANCLE 101

extern HWND g_hWnd;
extern HWND g_hNewWnd;
extern HWND g_hEdit;
extern HINSTANCE g_hInstance;
extern POINT	g_ptMouse;
extern HWND g_button_ok, g_button_cancle;
//extern float	g_wheelMouse;

#include "macroFunction.h"
#include "DataCollector.h"
#include "Boss_Monoeyes.h"
#include "Animation.h"
#include "Image.h"
#include "BossMissile.h"
#include "Player.h"

HRESULT Boss_Monoeyes::Init()
{
	bossImg = ImageManager::GetSingleton()->AddImage("MonoEyes", "Image/Boss/Boss_Monoeye.bmp", 70, 172, true, RGB(0, 251, 0));
	
	pattern = 1;

	createMissileImg = ImageManager::GetSingleton()->AddImage("B_CreateMissile", "Image/Boss/Boss_CreateMissile.bmp", 0, 0, 640, 80, 8, 1, true, RGB(248, 0, 248));
	missile1Img = ImageManager::GetSingleton()->AddImage("B_Missile1", "Image/Boss/Boss_Missile1.bmp", 0, 0, 200, 50, 4, 1, true, RGB(248, 0, 248));

	createMissileAni = new Animation();
	createMissileAni->Init(createMissileImg->GetWidth(), createMissileImg->GetHeight(), createMissileImg->GetFrameWidth(), createMissileImg->GetFrameHeight());
	createMissileAni->SetPlayFrame(false, false);
	createMissileAni->SetUpdateTime(FPS / 4);
	createMissileAni->Start();

	missile1Ani = new Animation();
	missile1Ani->Init(missile1Img->GetWidth(), missile1Img->GetHeight(), missile1Img->GetFrameWidth(), missile1Img->GetFrameHeight());
	missile1Ani->SetPlayFrame(false, false);
	missile1Ani->SetUpdateTime(FPS / 2);
	
	isUp = true;
	pos = { 14500, 800 };
	//pos = {600, 100};
	isReverseRender = false;
	scale = 2.0f;
	speed = (100.0f);
	isCreateMissileAni = false;
	isMissileAni = false;
	isFlameColl = false;

	life = 300;

	fireRate = 0;
	fireDelay = 30;
	
	isFire = false;

	bossMissile = new BossMissile[5];

	for(int i = 0 ; i < 5 ; i++)
		bossMissile[i].Init();


	return S_OK;
}

void Boss_Monoeyes::Release()
{
	//if (bossAni)
	//	SAFE_DELETE(bossAni);

	if (missile1Ani)
		SAFE_DELETE(missile1Ani);

	if (createMissileAni)
		SAFE_DELETE(createMissileAni);

	for (int i = 0; i < 5; i++)
	{
		if (bossMissile) 
		{
			bossMissile[i].Release();
			SAFE_ARR_DELETE(bossMissile);
		}
	}
}

void Boss_Monoeyes::Update()
{
	if (life <= 0) return;

	if (isFlameColl == true)
	{
		frame++;
		if (frame > 10)
		{
			frame = 0;
			isFlameColl = false;
		}
	}

	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
		pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };

	rect = GetRectToCenter(relativePos.x + 70, relativePos.y + 180, 70, 360);

	if (isUp == true)
	{
		pos.y -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else
	{
		pos.y += speed * TimeManager::GetSingleton()->GetDeltaTime();
	} 

	if (relativePos.y < 100)
	{
		isUp = false;
	}
	else if (relativePos.y > 200)
	{
		isUp = true;
	}
	
	fireRate++;
	if (fireRate > fireDelay)
	{
		isCreateMissileAni = true;
		fireRate = 0;
	}

	Pattern1();

	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == true)
		{
			bossMissile[i].Update();
		}
	}
}

void Boss_Monoeyes::Render(HDC hdc)
{
	if (life <= 0) return;

	//Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);

	if (bossImg)
	{
		bossImg->Render(hdc, relativePos.x, relativePos.y, scale);
	}

	if (createMissileImg && isCreateMissileAni == true)
		createMissileImg->AnimationRender(hdc, relativePos.x, relativePos.y + 40, createMissileAni, 2.0f);

	if (missile1Img && isMissileAni == true)
		missile1Img->AnimationRender(hdc, relativePos.x, relativePos.y + 40, missile1Ani, 2.0f);
	
	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == true)
		{
			bossMissile[i].Render(hdc);
		}
	}
}

void Boss_Monoeyes::Pattern0()
{

}

void Boss_Monoeyes::Pattern1()
{
	for (int i = 0; i < 5; i++)
	{
		if (bossMissile[i].GetIsFire() == false)
		{
			if (createMissileAni && isCreateMissileAni == true)
			{
				createMissileAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
				if (createMissileAni->GetNowPlayIdx() == createMissileAni->GetFrameCount() - 1)
				{
					isCreateMissileAni = false;
					isMissileAni = true;
					missile1Ani->Start();
				}
			}

			if (missile1Ani && isMissileAni == true)
			{
				missile1Ani->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

				if (missile1Ani->GetNowPlayIdx() == missile1Ani->GetFrameCount() - 1)
				{
					bossMissile[i].SetIsFire(true);
					bossMissile[i].SetAngle(atan2f(-(DataCollector::GetSingleton()->GetPlayer()->GetPlayerRelativePos().y - relativePos.y), DataCollector::GetSingleton()->GetPlayer()->GetPlayerRelativePos().x - relativePos.x ));
					bossMissile[i].SetPos({ pos.x, pos.y + 40});
					isMissileAni = false;
					createMissileAni->Start();
				}
			}

			continue;
		}
	}


	
}
void Boss_Monoeyes::Pattern2()
{
}
Boss_Monoeyes::Boss_Monoeyes()
{
}


Boss_Monoeyes::~Boss_Monoeyes()
{
}

#include "Pow.h"
#include "Image.h"
#include "Animation.h"
#include "Player.h"
#include "Items.h"

HRESULT Pow::Init(FPOINT _pos)
{
	return S_OK;
}

HRESULT Pow::Init(FPOINT _pos, int missileNum)
{	
	Object::SetNPC(this);
	Object::Init(PixelColl_ID::NPC);
	
	walkImg = ImageManager::GetSingleton()->AddImage("Pow_Walk", "Image/Pow/Pow_Walk.bmp", 0, 0, 650, 50, 13, 1, true, RGB(9, 194, 255));
	byeImg = ImageManager::GetSingleton()->AddImage("Pow_Bye", "Image/Pow/Pow_bye.bmp", 0, 0, 660, 50, 12, 1, true, RGB(9, 194, 255));
	giveItemImg = ImageManager::GetSingleton()->AddImage("Pow_GiveItem", "Image/Pow/Pow_GiveItem.bmp", 0, 0, 770, 40, 11, 1, true, RGB(9, 194, 255));
	runImg = ImageManager::GetSingleton()->AddImage("Pow_Run", "Image/Pow/Pow_Run.bmp", 0, 0, 560, 45, 8, 1, true, RGB(9, 194, 255));

	switch (missileNum)
	{
	case 1:
		items = new HeavyMissileItems();
		break;

	case 2:
		items = new FlameMissileItems();
		break;

	case 3:
		items = new RocketMissileItems();
		break;
	}

	walkAni = new Animation();
	walkAni->Init(walkImg->GetWidth(), walkImg->GetHeight(), walkImg->GetFrameWidth(), walkImg->GetFrameHeight());
	walkAni->SetPlayFrame(false, true);
	walkAni->SetUpdateTime(FPS / 3);
	walkAni->Start();

	byeAni = new Animation();
	byeAni->Init(byeImg->GetWidth(), byeImg->GetHeight(), byeImg->GetFrameWidth(), byeImg->GetFrameHeight());
	byeAni->SetPlayFrame(false, false);
	byeAni->SetUpdateTime(FPS / 5);
	byeAni->Start();

	giveItemAni = new Animation();
	giveItemAni->Init(giveItemImg->GetWidth(), giveItemImg->GetHeight(), giveItemImg->GetFrameWidth(), giveItemImg->GetFrameHeight());
	giveItemAni->SetPlayFrame(false, false);
	giveItemAni->SetUpdateTime(FPS / 4);
	giveItemAni->Start();

	runAni = new Animation();
	runAni->Init(runImg->GetWidth(), runImg->GetHeight(), runImg->GetFrameWidth(), runImg->GetFrameHeight());
	runAni->SetPlayFrame(false, true);
	runAni->SetUpdateTime(FPS / 3);
	runAni->Start();

	powState = PowState::WALK;

	isLanding = false;
	isAppear = false;
	isColl = false;
	isItemOn = false;

	speed = -80.0f;
	probeY = 50;

	pos = _pos;

	relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
					pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
	pixelRect = GetRectToCenter(pos.x - DataCollector::GetSingleton()->GetCurrentPrintPos().x, pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y + 30, probeY, probeY);
	rect = GetRectToCenter(relativePos.x, relativePos.y, 50, 50);

return S_OK;
}

void Pow::Release()
{
	if (walkAni)
		SAFE_DELETE(walkAni);

	if (byeAni)
		SAFE_DELETE(byeAni);

	if (runAni)
		SAFE_DELETE(runAni);

	if (giveItemAni)
		SAFE_DELETE(giveItemAni);
}

void Pow::Update()
{
	if (isAppear == true)
	{
		if ((isLanding == false && relativePos.x > 10))
		{
			pos.y += 10.0f;
		}

		if (isColl == false && CheckRectCollision(DataCollector::GetSingleton()->GetPlayer()->GetRC(), rect))
		{
			isColl = true;
			powState = PowState::GIVE_ITEM;
		}

		switch (powState)
		{
		case PowState::WALK:

			if (walkAni) walkAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();

			break;
		case PowState::BYE:

			if (byeAni->GetNowPlayIdx() > byeAni->GetFrameCount() - 3)
			{
				if (byeAni) byeAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 0.5);
			}
			else
			{
				if (byeAni) byeAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
			}

			if (byeAni->GetNowPlayIdx() == byeAni->GetFrameCount() - 1)
			{
				powState = PowState::RUN;
				speed = -200;
			}

			break;
		case PowState::GIVE_ITEM:

			if (giveItemAni->GetNowPlayIdx() > giveItemAni->GetFrameCount() - 3)
			{
				if (giveItemAni) giveItemAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime() * 0.5f);

				isItemOn = true;
				items->Init({ pos.x - 35, pos.y });
			}
			else
			{
				if (giveItemAni) giveItemAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
			}

			if (giveItemAni->GetNowPlayIdx() == giveItemAni->GetFrameCount() - 1)
			{
				powState = PowState::BYE;
			}

			break;
		case PowState::RUN:

			if (runAni) runAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());

			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();

			break;
		default:
			break;
		}

		relativePos = { pos.x + DataCollector::GetSingleton()->GetEditorAddValue() - DataCollector::GetSingleton()->GetCurrentPrintPos().x,
					pos.y - DataCollector::GetSingleton()->GetCurrentPrintPos().y };
		pixelRect = GetRectToCenter(relativePos.x, relativePos.y + 30, probeY, probeY);
		rect = GetRectToCenter(relativePos.x, relativePos.y, 50, 100);
	}
	
	if (items && isItemOn == true)
		if (items->GetIsColl() == false)
			items->Update();

	Object::Update();
}

void Pow::Render(HDC hdc)
{
	//Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
	//Rectangle(hdc, pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom);
	
	switch (powState)
	{
	case PowState::WALK:

		if (walkImg) walkImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, walkAni, 2.5f);

		break;
	case PowState::BYE:

		if (byeImg) byeImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, byeAni, 2.5f);

		break;
	case PowState::GIVE_ITEM:

		if (giveItemImg) giveItemImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, giveItemAni, 2.5f);

		break;
	case PowState::RUN:

		if (runImg) runImg->AnimationRender(hdc, relativePos.x, relativePos.y - 30, runAni, 2.5f);

		break;
	default:
		break;
	}

	if (items && isItemOn == true)
		if (items->GetIsColl() == false)
			items->Render(hdc);
}

Pow::Pow()
{
}


Pow::~Pow()
{
}

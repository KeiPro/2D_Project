#include "UI_MissileType.h"
#include "Image.h"

HRESULT UI_MissileType::Init()
{
	image = ImageManager::GetSingleton()->AddImage("UI_DefaultMissile", "Image/UI/MissileType_Default.bmp", 0, 0, 34, 30, 1, 1, true, RGB(255, 255, 255));
	missileType = ImageManager::GetSingleton()->AddImage("UI_MissileType", "Image/UI/MissileType.bmp", 0, 0, 72, 30, 3, 1, true, RGB(255, 255, 255));

	return S_OK;
}

void UI_MissileType::Release()
{
}

void UI_MissileType::Update()
{

}

void UI_MissileType::Render(HDC hdc)
{
	if (image)
		image->FrameRender(hdc, 100, GAME_SIZE_Y - 50, 0, 0, 2.3f);

	switch (DataCollector::GetSingleton()->GetGunState())
	{
	case GunState::DEFAULT:
		
		break;

	case GunState::HEAVY:

		if (missileType)
			missileType->FrameRender(hdc, 100, GAME_SIZE_Y - 50, 0, 0, 2.3f);

		break;

	case GunState::FLAME:

		if (missileType)
			missileType->FrameRender(hdc, 100, GAME_SIZE_Y - 50, 1, 0, 2.3f);

		break;

	case GunState::ROCKET:

		if (missileType)
			missileType->FrameRender(hdc, 100, GAME_SIZE_Y - 50, 2, 0, 2.3f);

		break;

	default:

		break;
	}
}

UI_MissileType::UI_MissileType()
{
}


UI_MissileType::~UI_MissileType()
{
}

#include "UI_Timer.h"
#include "Image.h"


HRESULT UI_Timer::Init()
{
	tensDigitImg = ImageManager::GetSingleton()->AddImage("UI_Number", "Image/UI/Number.bmp", 0, 0, 320, 32, 10, 1, true, RGB(255, 204, 204));
	onesDigitImg = ImageManager::GetSingleton()->FindImage("UI_Number");
	
	timer = 60;
	frame = 0;

	return S_OK;
}

void UI_Timer::Release()
{
}

void UI_Timer::Update()
{
	frame++;

	if (frame >= FPS * 3)
	{
		timer--;
		frame = 0;
	}
}

void UI_Timer::Render(HDC hdc)
{
	if (tensDigitImg)
	{
		tensDigitImg->FrameRender(hdc, GAME_SIZE_X / 2 - 30, 50, (timer / 10), 0, 2.0f);
	}

	if (onesDigitImg)
	{
		onesDigitImg->FrameRender(hdc, GAME_SIZE_X / 2 + 30, 50, (timer % 10), 0, 2.0f);
	}
}

UI_Timer::UI_Timer()
{
}


UI_Timer::~UI_Timer()
{
}

#include "CameraRect.h"


void CameraRect::Init()
{
	cameraYRectVec.reserve(20);
	cameraYRectVec.clear();
}

void CameraRect::Release()
{
	cameraYRectVec.clear();
	cameraYRectVec.capacity();

	vector<RECT_INFO*>().swap(cameraYRectVec);
	cameraYRectVec.capacity();
}

CameraRect::CameraRect()
{
}


CameraRect::~CameraRect()
{
}

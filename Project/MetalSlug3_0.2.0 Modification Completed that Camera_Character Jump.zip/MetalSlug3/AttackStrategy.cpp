#include "AttackStrategy.h"

void AttackStrategy::Attack(FPOINT pos, float angle, int _heavyMissile)
{
}

AttackStrategy::AttackStrategy()
{
}


AttackStrategy::~AttackStrategy()
{
}

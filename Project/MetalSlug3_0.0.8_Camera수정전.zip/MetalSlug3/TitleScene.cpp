#include "TitleScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT TitleScene::Init()
{



	return S_OK;
}

void TitleScene::Release()
{
	//SAFE_DELETE(testAni);
}

void TitleScene::Update()
{
	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	{
		//SceneManager::GetSingleton()->ChangeScene("BattleScene");	
		SceneManager::GetSingleton()->ChangeScene("EditorScene");
	}

	//testAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	//testAni_leg->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void TitleScene::Render(HDC hdc)
{
	//leg_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2 - 10, WINSIZE_Y / 2 + 40, testAni_leg);
	//body_AnimationImage->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y / 2, testAni);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}
